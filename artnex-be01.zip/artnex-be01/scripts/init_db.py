#!/usr/bin/env python3
"""
데이터베이스 초기화 스크립트
PostgreSQL 데이터베이스 및 사용자 생성, Alembic 마이그레이션 실행
"""

import sys
import os
from pathlib import Path

# Add app directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
import psycopg2
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

from app.core.config import settings


def create_database():
    """Create PostgreSQL database and user if they don't exist"""

    # Parse connection string
    db_url = settings.DATABASE_URL
    if "asyncpg" in db_url:
        db_url = db_url.replace("postgresql+asyncpg://", "postgresql://")

    # Extract connection params
    # postgresql://user:pass@host:port/dbname
    from urllib.parse import urlparse
    parsed = urlparse(db_url)

    db_user = parsed.username
    db_password = parsed.password
    db_host = parsed.hostname or 'localhost'
    db_port = parsed.port or 5432
    db_name = parsed.path.lstrip('/')

    print(f"📦 Database initialization started")
    print(f"  Host: {db_host}")
    print(f"  Port: {db_port}")
    print(f"  Database: {db_name}")
    print(f"  User: {db_user}")

    # Connect to PostgreSQL default database to create new database
    try:
        conn = psycopg2.connect(
            host=db_host,
            port=db_port,
            user="postgres",
            password="",  # Try without password first
            database="postgres"
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cur = conn.cursor()

        # Check if database exists
        cur.execute(
            f"SELECT 1 FROM pg_database WHERE datname = %s",
            (db_name,)
        )

        if cur.fetchone() is None:
            print(f"\n✏️  Creating database '{db_name}'...")
            cur.execute(sql.SQL("CREATE DATABASE {}").format(
                sql.Identifier(db_name)
            ))
            print(f"✅ Database '{db_name}' created")
        else:
            print(f"✅ Database '{db_name}' already exists")

        # Check if user exists
        cur.execute(
            f"SELECT 1 FROM pg_user WHERE usename = %s",
            (db_user,)
        )

        if cur.fetchone() is None:
            print(f"\n✏️  Creating user '{db_user}'...")
            cur.execute(
                sql.SQL("CREATE USER {} WITH PASSWORD %s").format(
                    sql.Identifier(db_user)
                ),
                (db_password,)
            )
            print(f"✅ User '{db_user}' created")
        else:
            print(f"✅ User '{db_user}' already exists")

        # Grant privileges
        print(f"\n✏️  Granting privileges to user '{db_user}'...")
        cur.execute(
            sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}").format(
                sql.Identifier(db_name),
                sql.Identifier(db_user)
            )
        )
        cur.execute(
            sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO {}").format(
                sql.Identifier(db_user)
            )
        )
        cur.execute(
            sql.SQL("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO {}").format(
                sql.Identifier(db_user)
            )
        )
        print(f"✅ Privileges granted")

        cur.close()
        conn.close()
        print(f"\n✅ PostgreSQL setup completed\n")
        return True

    except Exception as e:
        print(f"\n❌ Error creating database: {e}")
        print(f"\n⚠️  This might be normal if PostgreSQL requires different authentication.")
        print(f"   Trying alternative authentication method...\n")
        return False


def run_migrations():
    """Run Alembic migrations"""
    print("🔄 Running Alembic migrations...\n")

    from alembic.config import Config
    from alembic import command

    # Load alembic config
    alembic_cfg = Config("alembic.ini")

    # Set sqlalchemy.url from environment
    db_url = settings.DATABASE_URL
    if "asyncpg" in db_url:
        db_url = db_url.replace("postgresql+asyncpg://", "postgresql://")
    alembic_cfg.set_main_option("sqlalchemy.url", db_url)

    try:
        # Run upgrade to head
        print("📝 Upgrading database to latest schema...")
        command.upgrade(alembic_cfg, "head")
        print("✅ Migrations completed successfully\n")
        return True
    except Exception as e:
        print(f"❌ Migration error: {e}\n")
        return False


def verify_schema():
    """Verify database schema"""
    print("🔍 Verifying database schema...\n")

    try:
        db_url = settings.DATABASE_URL
        if "asyncpg" in db_url:
            db_url = db_url.replace("postgresql+asyncpg://", "postgresql://")

        engine = create_engine(db_url, echo=False)

        with engine.connect() as conn:
            # Get list of tables
            result = conn.execute(text("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = 'public'
                ORDER BY table_name
            """))

            tables = result.fetchall()
            expected_tables = [
                'users', 'brands', 'brand_kpis', 'skus', 'tracked_contents',
                'content_keywords', 'brand_personas', 'competitors',
                'user_subscriptions', 'payments',
                'guide_resources', 'user_activities', 'projects', 'tasks',
                'contracts', 'brand_reports', 'alembic_version'
            ]

            found_tables = [t[0] for t in tables]

            print(f"📊 Database tables ({len(found_tables)}):")
            for table in found_tables:
                symbol = "✅" if table in expected_tables or table == 'alembic_version' else "⚠️ "
                print(f"  {symbol} {table}")

            # Check for expected tables
            missing = set(expected_tables) - set(found_tables) - {'alembic_version'}
            if missing:
                print(f"\n⚠️  Missing tables: {missing}")
                return False
            else:
                print(f"\n✅ All expected tables found!")
                return True

    except Exception as e:
        print(f"❌ Verification error: {e}")
        return False


def main():
    """Main initialization function"""
    print("="*60)
    print("🚀 ArtNex Database Initialization")
    print("="*60 + "\n")

    # Step 1: Create database
    db_created = create_database()

    # Step 2: Run migrations
    migrations_done = run_migrations()

    if migrations_done:
        # Step 3: Verify schema
        schema_valid = verify_schema()

        if schema_valid:
            print("\n" + "="*60)
            print("✅ Database initialization completed successfully!")
            print("="*60)
            return 0

    print("\n" + "="*60)
    print("⚠️  Database initialization completed with warnings")
    print("="*60)
    return 1


if __name__ == "__main__":
    sys.exit(main())
