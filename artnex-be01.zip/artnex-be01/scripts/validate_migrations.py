#!/usr/bin/env python
"""
Validate Alembic migrations without database connection
"""
import ast
import sys
from pathlib import Path


def validate_migration_file(filepath: Path) -> bool:
    """Validate a single migration file"""
    try:
        with open(filepath, 'r') as f:
            code = f.read()

        # Check syntax
        ast.parse(code)

        # Check required components
        required = ['revision', 'down_revision', 'upgrade', 'downgrade']
        for req in required:
            if req not in code:
                print(f"❌ {filepath.name}: Missing '{req}'")
                return False

        print(f"✓ {filepath.name}: Valid")
        return True

    except SyntaxError as e:
        print(f"❌ {filepath.name}: Syntax error - {e}")
        return False
    except Exception as e:
        print(f"❌ {filepath.name}: Error - {e}")
        return False


def main():
    """Validate all migrations"""
    migrations_dir = Path('alembic/versions')

    if not migrations_dir.exists():
        print(f"❌ Migrations directory not found: {migrations_dir}")
        return 1

    migration_files = sorted(migrations_dir.glob('*.py'))

    if not migration_files:
        print("⚠️  No migration files found")
        return 1

    print(f"Validating {len(migration_files)} migration files...\n")

    valid_count = 0
    for filepath in migration_files:
        if filepath.name == '__init__.py':
            continue

        if validate_migration_file(filepath):
            valid_count += 1

    print(f"\n{'='*50}")
    print(f"Results: {valid_count}/{len([f for f in migration_files if f.name != '__init__.py'])} migrations valid")

    if valid_count == len([f for f in migration_files if f.name != '__init__.py']):
        print("✅ All migrations are valid!")
        return 0
    else:
        print("❌ Some migrations have errors")
        return 1


if __name__ == '__main__':
    sys.exit(main())
