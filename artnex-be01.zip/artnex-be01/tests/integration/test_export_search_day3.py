"""Integration tests for Day 3: CSV Export and Content Search Engine"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Brand, TrackedContent


@pytest.mark.asyncio
async def test_export_csv_basic(
    client: TestClient, db_session: AsyncSession, test_brand: Brand, auth_token: str
):
    """Test basic CSV export functionality"""
    # Create test content
    for i in range(3):
        content = TrackedContent(
            brand_id=test_brand.id,
            content_id=f"export_vid_{i}",
            platform="youtube",
            title=f"Test Video {i}",
            url=f"https://youtube.com/watch?v=export_{i}",
            creator_name="Test Creator",
            views=1000 * (i + 1),
        )
        db_session.add(content)
    await db_session.commit()

    response = client.get(
        "/api/v1/export/tracked-content/csv",
        params={"brand_id": test_brand.id},
        headers={"Authorization": f"Bearer {auth_token}"},
    )

    assert response.status_code == 200
    assert "text/csv" in response.headers["content-type"]
    assert "attachment" in response.headers["content-disposition"]
    assert "Test Video 0" in response.text


@pytest.mark.asyncio
async def test_semantic_search_with_relevance(
    client: TestClient, db_session: AsyncSession, test_brand: Brand, auth_token: str
):
    """Test that semantic search returns results sorted by relevance"""
    # Create content: one highly relevant, one less relevant
    content1 = TrackedContent(
        brand_id=test_brand.id,
        content_id="search_vid_1",
        platform="youtube",
        title="How to Make Machine Learning Models",
        url="https://youtube.com/watch?v=search_1",
        creator_name="AI Expert",
        views=10000,
        popularity_index=85.0,
    )
    content2 = TrackedContent(
        brand_id=test_brand.id,
        content_id="search_vid_2",
        platform="youtube",
        title="Travel Vlog to Paris",
        url="https://youtube.com/watch?v=search_2",
        creator_name="Travel Channel",
        views=1000,
        popularity_index=45.0,
    )
    db_session.add_all([content1, content2])
    await db_session.commit()

    response = client.get(
        "/api/v1/search/semantic",
        params={
            "brand_id": test_brand.id,
            "query": "machine learning AI models tutorial",
            "limit": 10,
        },
        headers={"Authorization": f"Bearer {auth_token}"},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert len(data["data"]) > 0
    assert data["data"][0]["title"] == "How to Make Machine Learning Models"
    if len(data["data"]) >= 2:
        assert data["data"][0]["relevance_score"] >= data["data"][1]["relevance_score"]
