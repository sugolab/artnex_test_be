"""Integration tests for dashboard workflow"""
import pytest
from fastapi.testclient import TestClient


class TestDashboardFlow:
    """Test dashboard workflow"""

    def test_health_check(self, client: TestClient):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"

    def test_root_endpoint(self, client: TestClient):
        """Test root endpoint"""
        response = client.get("/")
        assert response.status_code == 200
        assert "app" in response.json()
        assert "version" in response.json()

    def test_api_health_check(self, client: TestClient):
        """Test API health check"""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"

    def test_get_dashboard_without_auth(self, client: TestClient):
        """Test dashboard endpoint without authentication"""
        response = client.get("/api/v1/dashboard")
        assert response.status_code == 403

    def test_get_dashboard_with_invalid_token(self, client: TestClient):
        """Test dashboard endpoint with invalid token"""
        headers = {"Authorization": "Bearer invalid_token"}
        response = client.get("/api/v1/dashboard", headers=headers)
        assert response.status_code == 401

    def test_get_guides(self, client: TestClient, auth_token: str):
        """Test guides endpoint"""
        headers = {"Authorization": f"Bearer {auth_token}"}
        response = client.get("/api/v1/guides", headers=headers)
        assert response.status_code == 200
        assert "success" in response.json()
        assert "data" in response.json()

    def test_get_payment_plans(self, client: TestClient, auth_token: str):
        """Test payment plans endpoint"""
        headers = {"Authorization": f"Bearer {auth_token}"}
        response = client.get("/api/v1/payments/plans/all", headers=headers)
        assert response.status_code == 200
        assert response.json()["success"] is True
        assert len(response.json()["data"]) >= 0  # Check if it returns a list

    def test_upgrade_subscription(self, client: TestClient, auth_token: str):
        """Test subscription upgrade"""
        headers = {"Authorization": f"Bearer {auth_token}"}

        upgrade_data = {"subscription_plan": "premium"}
        response = client.post("/api/v1/payments/upgrade", headers=headers, json=upgrade_data)

        assert response.status_code == 200
        assert response.json()["success"] is True
        assert "transaction_id" in response.json()["data"]

    def test_get_current_subscription(self, client: TestClient, auth_token: str):
        """Test get current subscription"""
        headers = {"Authorization": f"Bearer {auth_token}"}
        response = client.get("/api/v1/payments/subscription/current", headers=headers)

        assert response.status_code == 200
        assert response.json()["success"] is True
        assert "plan" in response.json()["data"]
