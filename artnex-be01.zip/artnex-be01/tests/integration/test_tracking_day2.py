"""Integration tests for Day 2: Filtering logic and Popularity Index calculation"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Brand, TrackedContent, User
from app.services.kpi_service import KPIService


@pytest.mark.asyncio
async def test_advanced_search_with_multiple_filters(
    client: TestClient, db_session: AsyncSession, test_brand: Brand, auth_token: str
):
    """Test advanced search with multiple filters"""
    # Create test content with various metrics
    contents = [
        TrackedContent(
            brand_id=test_brand.id,
            content_id=f"vid_{i}",
            platform="youtube",
            title=f"Test Video {i}",
            url=f"https://youtube.com/watch?v={i}",
            creator_name=f"Creator {i}",
            views=1000 * (i + 1),
            likes=100 * (i + 1),
            comments=10 * (i + 1),
            shares=5 * (i + 1),
            engagement_rate=float((100 * (i + 1) + 10 * (i + 1) + 5 * (i + 1)) / (1000 * (i + 1)) * 100),
            popularity_index=float((i + 1) * 10),
            is_influencer=i > 2,
        )
        for i in range(5)
    ]
    db_session.add_all(contents)
    await db_session.commit()

    # Test filtering by views
    response = client.get(
        "/api/v1/tracking/search",
        params={
            "brand_id": test_brand.id,
            "min_views": 3000,
            "page": 1,
            "page_size": 10,
        },
        headers={"Authorization": f"Bearer {auth_token}"},
    )

    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert len(data["data"]["results"]) == 3 # Should find videos 2, 3, 4 (views 3k, 4k, 5k)


@pytest.mark.asyncio
async def test_sorting_by_popularity_index(
    client: TestClient, db_session: AsyncSession, test_brand: Brand, auth_token: str
):
    """Test sorting by popularity index"""
    # Create content with specific popularity indices
    contents = [
        TrackedContent(
            brand_id=test_brand.id,
            content_id=f"sort_vid_{i}",
            platform="youtube",
            title=f"Test Video {i}",
            url=f"https://youtube.com/watch?v=sort_{i}",
            creator_name="Test Creator",
            views=1000,
            likes=100,
            comments=10,
            shares=5,
            engagement_rate=11.5,
            popularity_index=float(50 - (i * 10)),  # 50, 40, 30
            is_influencer=False,
        )
        for i in range(3)
    ]
    db_session.add_all(contents)
    await db_session.commit()

    # Test descending sort by popularity
    response = client.get(
        "/api/v1/tracking/search",
        params={
            "brand_id": test_brand.id,
            "sort_by": "popularity_index",
            "sort_order": "desc",
        },
        headers={"Authorization": f"Bearer {auth_token}"},
    )

    assert response.status_code == 200
    data = response.json()
    results = data["data"]["results"]
    assert len(results) == 3
    assert results[0]["popularity_index"] == 50.0
    assert results[1]["popularity_index"] == 40.0
    assert results[2]["popularity_index"] == 30.0


@pytest.mark.asyncio
async def test_kpi_calculation_accuracy(db_session: AsyncSession, test_brand: Brand):
    """Test KPI calculation accuracy"""
    # Create content with known metrics
    content = TrackedContent(
        brand_id=test_brand.id,
        content_id="kpi_test_vid_1",
        platform="youtube",
        title="Test Video",
        url="https://youtube.com/watch?v=kpi_test",
        creator_name="Test Creator",
        views=1000,
        likes=200,
        comments=50,
        shares=10,
    )
    db_session.add(content)
    await db_session.commit()

    kpi_service = KPIService(db_session)

    engagement_rate = await kpi_service.calculate_engagement_rate(content)
    expected_engagement = (200 + 50 + 10) / 1000 * 100
    assert engagement_rate == pytest.approx(expected_engagement, rel=0.01)

    popularity = await kpi_service.calculate_popularity_index(content)
    expected_popularity = (
        (1000 / 10000) * 0.4 + (200 / 1000) * 0.3 + (50 / 100) * 0.2 + (10 / 50) * 0.1
    ) * 100
    assert popularity == pytest.approx(expected_popularity, rel=0.01)
