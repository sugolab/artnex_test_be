import os
from dotenv import load_dotenv

# Set TESTING environment variable for conditional config loading
os.environ["TESTING"] = "1"

# Load .env before any other imports that might load settings
load_dotenv()

# Force reload of app.core.config to pick up TESTING env var
import importlib
import app.core.config
importlib.reload(app.core.config)
from app.core.config import settings

"""
Pytest configuration and fixtures
"""
import asyncio
from typing import AsyncGenerator

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.core.config import settings
from app.core.database import get_db
from app.main import app
from app.models import User, Brand
from app.core.security import create_access_token, hash_password
from fastapi.testclient import TestClient

# Use the actual database settings from the .env file
engine = create_async_engine(settings.DATABASE_URL, echo=False)
TestingSessionLocal = sessionmaker(
    autocommit=False, autoflush=False, bind=engine, class_=AsyncSession
)


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for each test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

# This fixture will be used by tests to get a DB session
@pytest.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    async with TestingSessionLocal() as session:
        yield session


# This fixture overrides the main `get_db` dependency for the test client
async def override_get_db() -> AsyncGenerator[AsyncSession, None]:
    async with TestingSessionLocal() as session:
        yield session


@pytest.fixture()
def client() -> TestClient:
    """
    Get a TestClient instance that uses the override_get_db fixture to override
    the get_db dependency that is injected into routes.
    """
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def test_user_data() -> dict:
    """Test user data"""
    return {
        "email": "test@example.com",
        "username": "testuser",
        "password": "testpassword123",
        "full_name": "Test User",
    }


@pytest.fixture
def test_brand_data() -> dict:
    """Test brand data"""
    return {
        "name": "Test Brand",
        "category": "Beauty",
        "slogan": "Test Slogan",
        "mission": "Test Mission",
        "vision": "Test Vision",
        "keywords": ["keyword1", "keyword2"],
        "website": "https://example.com",
    }


@pytest.fixture(scope="function")
async def test_user(db_session: AsyncSession) -> User:
    """
    Create and return a user in the database.
    """
    user = User(
        email="test-user-conftest@example.com",
        username="testuser_conftest",
        password_hash=hash_password("testpassword123"),
        full_name="Test User Conftest",
        is_active=True,
    )
    db_session.add(user)
    await db_session.commit()
    await db_session.refresh(user)
    return user


@pytest.fixture(scope="function")
def auth_token(test_user: User) -> str:
    """
    Create and return a valid JWT token for the test_user.
    """
    return create_access_token(data={"sub": str(test_user.id)})


@pytest.fixture(scope="function")
async def test_brand(db_session: AsyncSession, test_user: User) -> Brand:
    """
    Create and return a brand in the database, linked to the test_user.
    """
    brand = Brand(user_id=test_user.id, name="Test Brand", category="Testing")
    db_session.add(brand)
    await db_session.commit()
    await db_session.refresh(brand)
    return brand