BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> 001

CREATE TABLE users (
    id SERIAL NOT NULL, 
    email VARCHAR(255) NOT NULL, 
    username VARCHAR(100) NOT NULL, 
    password_hash VARCHAR(255) NOT NULL, 
    full_name VARCHAR(255), 
    is_active BOOLEAN DEFAULT true NOT NULL, 
    role_id INTEGER DEFAULT '1' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (email), 
    UNIQUE (username)
);

CREATE INDEX ix_users_email ON users (email);

CREATE INDEX ix_users_username ON users (username);

CREATE TABLE brands (
    id SERIAL NOT NULL, 
    user_id INTEGER NOT NULL, 
    name VARCHAR(255) NOT NULL, 
    category VARCHAR(100), 
    slogan TEXT, 
    mission TEXT, 
    vision TEXT, 
    description TEXT, 
    keywords JSON, 
    logo_url VARCHAR(500), 
    website VARCHAR(255), 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX ix_brands_user_id ON brands (user_id);

CREATE INDEX ix_brands_name ON brands (name);

CREATE TABLE brand_kpis (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    kpi_type VARCHAR(100) NOT NULL, 
    value FLOAT NOT NULL, 
    measurement_date TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_brand_kpis_brand_id ON brand_kpis (brand_id);

CREATE INDEX ix_brand_kpis_kpi_type ON brand_kpis (kpi_type);

CREATE TABLE skus (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    sku_code VARCHAR(100) NOT NULL, 
    product_name VARCHAR(255) NOT NULL, 
    category VARCHAR(100), 
    price FLOAT, 
    stock_quantity INTEGER, 
    description TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE, 
    UNIQUE (sku_code)
);

CREATE INDEX ix_skus_brand_id ON skus (brand_id);

CREATE TABLE tracked_contents (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    content_id VARCHAR(255) NOT NULL, 
    platform VARCHAR(50) NOT NULL, 
    title VARCHAR(500) NOT NULL, 
    description TEXT, 
    url VARCHAR(500) NOT NULL, 
    thumbnail_url VARCHAR(500), 
    creator_name VARCHAR(255), 
    creator_handle VARCHAR(255), 
    creator_followers INTEGER, 
    is_influencer BOOLEAN DEFAULT false NOT NULL, 
    views INTEGER DEFAULT '0' NOT NULL, 
    likes INTEGER DEFAULT '0' NOT NULL, 
    comments INTEGER DEFAULT '0' NOT NULL, 
    shares INTEGER DEFAULT '0' NOT NULL, 
    engagement_rate FLOAT DEFAULT '0.0' NOT NULL, 
    keywords JSON, 
    hashtags JSON, 
    published_at TIMESTAMP WITHOUT TIME ZONE, 
    duration_seconds INTEGER, 
    language VARCHAR(10), 
    popularity_index FLOAT DEFAULT '0.0' NOT NULL, 
    relevance_score FLOAT DEFAULT '0.0' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE, 
    UNIQUE (content_id)
);

CREATE INDEX ix_tracked_contents_brand_id ON tracked_contents (brand_id);

CREATE INDEX ix_tracked_contents_platform ON tracked_contents (platform);

CREATE INDEX ix_tracked_contents_is_influencer ON tracked_contents (is_influencer);

CREATE INDEX ix_tracked_contents_popularity_index ON tracked_contents (popularity_index);

CREATE INDEX ix_tracked_contents_created_at ON tracked_contents (created_at);

CREATE TABLE content_keywords (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    content_id INTEGER NOT NULL, 
    keyword VARCHAR(255) NOT NULL, 
    frequency INTEGER DEFAULT '1' NOT NULL, 
    relevance_score FLOAT DEFAULT '0.0' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE, 
    FOREIGN KEY(content_id) REFERENCES tracked_contents (id) ON DELETE CASCADE
);

CREATE INDEX ix_content_keywords_brand_id ON content_keywords (brand_id);

CREATE INDEX ix_content_keywords_keyword ON content_keywords (keyword);

CREATE TABLE brand_personas (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    persona_name VARCHAR(255) NOT NULL, 
    description TEXT, 
    age_range VARCHAR(50), 
    interests JSON, 
    behaviors JSON, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_brand_personas_brand_id ON brand_personas (brand_id);

CREATE TABLE competitors (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    competitor_name VARCHAR(255) NOT NULL, 
    website VARCHAR(500), 
    description TEXT, 
    strengths JSON, 
    weaknesses JSON, 
    market_share FLOAT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_competitors_brand_id ON competitors (brand_id);

CREATE TABLE user_subscriptions (
    id SERIAL NOT NULL, 
    user_id INTEGER NOT NULL, 
    plan VARCHAR(50) DEFAULT 'free' NOT NULL, 
    status VARCHAR(50) DEFAULT 'active' NOT NULL, 
    started_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    expires_at TIMESTAMP WITHOUT TIME ZONE, 
    auto_renew BOOLEAN DEFAULT true NOT NULL, 
    price_per_month FLOAT DEFAULT '0.0' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX ix_user_subscriptions_user_id ON user_subscriptions (user_id);

CREATE INDEX ix_user_subscriptions_status ON user_subscriptions (status);

CREATE TABLE payments (
    id SERIAL NOT NULL, 
    user_id INTEGER NOT NULL, 
    subscription_id INTEGER NOT NULL, 
    amount FLOAT NOT NULL, 
    currency VARCHAR(10) DEFAULT 'KRW' NOT NULL, 
    payment_method VARCHAR(50), 
    status VARCHAR(50) DEFAULT 'pending' NOT NULL, 
    transaction_id VARCHAR(255), 
    paid_at TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
    FOREIGN KEY(subscription_id) REFERENCES user_subscriptions (id) ON DELETE CASCADE
);

CREATE INDEX ix_payments_user_id ON payments (user_id);

CREATE INDEX ix_payments_status ON payments (status);

CREATE TABLE guide_resources (
    id SERIAL NOT NULL, 
    title VARCHAR(255) NOT NULL, 
    description TEXT, 
    content_type VARCHAR(50), 
    content_url VARCHAR(500), 
    tags JSON, 
    is_featured BOOLEAN DEFAULT false NOT NULL, 
    "order" INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_guide_resources_is_featured ON guide_resources (is_featured);

CREATE TABLE user_activities (
    id SERIAL NOT NULL, 
    user_id INTEGER NOT NULL, 
    activity_type VARCHAR(100) NOT NULL, 
    description TEXT, 
    metadata JSON, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX ix_user_activities_user_id ON user_activities (user_id);

CREATE INDEX ix_user_activities_activity_type ON user_activities (activity_type);

CREATE TABLE projects (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    project_name VARCHAR(255) NOT NULL, 
    status VARCHAR(50) DEFAULT 'planning' NOT NULL, 
    description TEXT, 
    start_date TIMESTAMP WITHOUT TIME ZONE, 
    end_date TIMESTAMP WITHOUT TIME ZONE, 
    budget FLOAT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_projects_brand_id ON projects (brand_id);

CREATE INDEX ix_projects_status ON projects (status);

CREATE TABLE tasks (
    id SERIAL NOT NULL, 
    project_id INTEGER NOT NULL, 
    task_name VARCHAR(255) NOT NULL, 
    status VARCHAR(50) DEFAULT 'todo' NOT NULL, 
    description TEXT, 
    priority VARCHAR(50), 
    assigned_to INTEGER, 
    due_date TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(project_id) REFERENCES projects (id) ON DELETE CASCADE
);

CREATE INDEX ix_tasks_project_id ON tasks (project_id);

CREATE INDEX ix_tasks_status ON tasks (status);

CREATE TABLE contracts (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    contract_name VARCHAR(255) NOT NULL, 
    contract_type VARCHAR(100), 
    file_url VARCHAR(500), 
    status VARCHAR(50) DEFAULT 'draft' NOT NULL, 
    signed_date TIMESTAMP WITHOUT TIME ZONE, 
    expiry_date TIMESTAMP WITHOUT TIME ZONE, 
    terms TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_contracts_brand_id ON contracts (brand_id);

CREATE INDEX ix_contracts_status ON contracts (status);

CREATE TABLE brand_reports (
    id SERIAL NOT NULL, 
    brand_id INTEGER NOT NULL, 
    report_type VARCHAR(100), 
    overall_score FLOAT, 
    ai_summary TEXT, 
    sections JSON, 
    pdf_url VARCHAR(500), 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(brand_id) REFERENCES brands (id) ON DELETE CASCADE
);

CREATE INDEX ix_brand_reports_brand_id ON brand_reports (brand_id);

CREATE INDEX ix_brand_reports_created_at ON brand_reports (created_at);

INSERT INTO alembic_version (version_num) VALUES ('001') RETURNING alembic_version.version_num;

-- Running upgrade 001 -> 002

CREATE INDEX ix_brands_user_id_created_at ON brands (user_id, created_at);

CREATE INDEX ix_tracked_contents_brand_id_created_at ON tracked_contents (brand_id, created_at);

CREATE INDEX ix_tracked_contents_platform_created_at ON tracked_contents (platform, created_at);

CREATE INDEX ix_projects_brand_id_status ON projects (brand_id, status);

CREATE INDEX ix_tasks_project_id_status ON tasks (project_id, status);

CREATE INDEX ix_contracts_brand_id_status ON contracts (brand_id, status);

CREATE INDEX ix_brand_kpis_brand_id_measurement_date ON brand_kpis (brand_id, measurement_date);

CREATE INDEX ix_user_subscriptions_user_id_is_active ON user_subscriptions (user_id, is_active);

CREATE INDEX ix_payments_user_id_created_at ON payments (user_id, created_at);

CREATE INDEX ix_brand_reports_brand_id_created_at_desc ON brand_reports (brand_id, created_at);

CREATE INDEX ix_content_keywords_brand_id_keyword ON content_keywords (brand_id, keyword);

CREATE INDEX ix_tracked_contents_is_influencer_popularity ON tracked_contents (is_influencer, popularity_index);

CREATE INDEX ix_guide_resources_is_featured_order ON guide_resources (is_featured, "order");

CREATE INDEX ix_user_activities_user_id_created_at ON user_activities (user_id, created_at);

CREATE INDEX ix_skus_brand_id_sku_code ON skus (brand_id, sku_code);

CREATE INDEX ix_brand_personas_brand_id_persona_name ON brand_personas (brand_id, persona_name);

UPDATE alembic_version SET version_num='002' WHERE alembic_version.version_num = '001';

COMMIT;