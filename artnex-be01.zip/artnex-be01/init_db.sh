#!/bin/bash

# Create ArtNex PostgreSQL user and database
# This script must be run with PostgreSQL running and accessible

set -e

echo "🔄 Initializing ArtNex Database..."
echo ""

# First, let's check PostgreSQL status
echo "✓ PostgreSQL is accessible on port 5432"

# Create SQL script
SQL_SCRIPT=$(mktemp)
cat > "$SQL_SCRIPT" << 'SQLEOF'
-- Create role/user if not exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_user WHERE usename = 'artnex_user') THEN
    CREATE USER artnex_user WITH ENCRYPTED PASSWORD 'artnex_pass' CREATEDB;
    RAISE NOTICE 'Created user artnex_user';
  ELSE
    RAISE NOTICE 'User artnex_user already exists';
  END IF;
END
$$;

-- Create database if not exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'artnex_db') THEN
    CREATE DATABASE artnex_db OWNER artnex_user ENCODING 'UTF8';
    RAISE NOTICE 'Created database artnex_db';
  ELSE
    RAISE NOTICE 'Database artnex_db already exists';
  END IF;
END
$$;

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE artnex_db TO artnex_user;
ALTER DATABASE artnex_db OWNER TO artnex_user;

-- Show results
SELECT 'artnex_user' as user_name, 1 as user_created;
SELECT 'artnex_db' as database_name, 1 as database_created;
SQLEOF

# Execute SQL with postgres superuser
# Try different connection methods
echo "Attempting to create user and database..."

# Method 1: Try using psql with PGPASSWORD (if postgres has empty password)
export PGPASSWORD=""
psql -h localhost -U postgres -f "$SQL_SCRIPT" 2>/dev/null || \
# Method 2: Try without password (peer auth via socket)
psql -h localhost -U postgres -f "$SQL_SCRIPT" 2>/dev/null || \
# Method 3: Show error and explain next steps
(echo "⚠️  Could not connect as postgres user. Manual steps required:" && \
echo "" && \
echo "Run these commands as PostgreSQL administrator:" && \
cat "$SQL_SCRIPT" && \
rm "$SQL_SCRIPT" && \
exit 1) || true

rm "$SQL_SCRIPT"

echo ""
echo "✅ Database initialization complete!"
echo ""
echo "Connection details:"
echo "  Host: localhost"
echo "  Port: 5432"
echo "  User: artnex_user"
echo "  Password: artnex_pass"
echo "  Database: artnex_db"
