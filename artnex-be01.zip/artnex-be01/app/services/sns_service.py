"""SNS (Social Network Service) API integration service"""
import logging
import random
from datetime import datetime, timedelta
from typing import List, Optional

from app.core.config import settings
from app.models.tracking import TrackedContent
from app.repositories.tracking_repository import TrackedContentRepository

logger = logging.getLogger(__name__)


class SNSService:
    """Service for SNS API integration and content tracking"""

    def __init__(self):
        self.youtube_api_key = settings.YOUTUBE_API_KEY

    async def search_youtube_content(
        self, keyword: str, max_results: int = 50
    ) -> List[dict]:
        """
        Search for content on YouTube using Data API

        Args:
            keyword: Search keyword
            max_results: Maximum results to return

        Returns:
            List of video data
        """
        try:
            if not self.youtube_api_key or self.youtube_api_key == "test-key":
                logger.warning("YouTube API key not configured, returning mock data")
                return self._get_mock_youtube_results(keyword, max_results)

            # Import here to avoid issues if google-api-python-client is not installed
            from googleapiclient.discovery import build

            youtube = build("youtube", "v3", developerKey=self.youtube_api_key)

            request = youtube.search().list(
                q=keyword,
                part="snippet",
                type="video",
                maxResults=min(max_results, 50),
                order="relevance",
            )

            response = request.execute()

            results = []
            for item in response.get("items", []):
                video_data = {
                    "platform": "youtube",
                    "content_id": item["id"]["videoId"],
                    "title": item["snippet"]["title"],
                    "description": item["snippet"]["description"],
                    "url": f"https://www.youtube.com/watch?v={item['id']['videoId']}",
                    "thumbnail_url": item["snippet"]["thumbnails"]["medium"]["url"],
                    "creator_name": item["snippet"]["channelTitle"],
                    "published_at": item["snippet"]["publishedAt"],
                }
                results.append(video_data)

            logger.info(f"Found {len(results)} YouTube videos for keyword: {keyword}")
            return results

        except Exception as e:
            logger.error(f"Error searching YouTube: {e}")
            return self._get_mock_youtube_results(keyword, max_results)

    async def get_youtube_statistics(self, video_id: str) -> Optional[dict]:
        """
        Get detailed statistics for a YouTube video

        Args:
            video_id: YouTube video ID

        Returns:
            Video statistics (views, likes, comments)
        """
        try:
            if not self.youtube_api_key or self.youtube_api_key == "test-key":
                logger.warning("YouTube API key not configured, returning mock stats")
                return self._get_mock_youtube_stats(video_id)

            from googleapiclient.discovery import build

            youtube = build("youtube", "v3", developerKey=self.youtube_api_key)

            request = youtube.videos().list(
                part="statistics,contentDetails",
                id=video_id,
            )

            response = request.execute()

            if not response.get("items"):
                return None

            item = response["items"][0]
            stats = item["statistics"]
            duration = item["contentDetails"]["duration"]

            return {
                "views": int(stats.get("viewCount", 0)),
                "likes": int(stats.get("likeCount", 0)),
                "comments": int(stats.get("commentCount", 0)),
                "duration": duration,
            }

        except Exception as e:
            logger.error(f"Error getting YouTube statistics: {e}")
            return self._get_mock_youtube_stats(video_id)

    def _get_mock_youtube_results(self, keyword: str, max_results: int) -> List[dict]:
        """Get mock YouTube search results for testing"""
        return [
            {
                "platform": "youtube",
                "content_id": f"video_{i}",
                "title": f"{keyword} - Video {i+1}",
                "description": f"Sample video about {keyword} #{i+1}",
                "url": f"https://www.youtube.com/watch?v=video_{i}",
                "thumbnail_url": "https://via.placeholder.com/320x180",
                "creator_name": f"Channel {i+1}",
                "published_at": "2025-10-20T10:00:00Z",
            }
            for i in range(min(max_results, 10))
        ]

    def _get_mock_youtube_stats(self, video_id: str) -> dict:
        """Get mock YouTube statistics for testing"""
        import random

        return {
            "views": random.randint(1000, 100000),
            "likes": random.randint(50, 5000),
            "comments": random.randint(10, 1000),
            "duration": "PT10M30S",  # ISO 8601 duration format
        }

    async def track_content(
        self, db, brand_id: int, content_data: dict
    ) -> TrackedContent:
        """
        Track content in database

        Args:
            db: Database session
            brand_id: Brand ID
            content_data: Content information

        Returns:
            TrackedContent object
        """
        try:
            tracking_repo = TrackedContentRepository(db)

            # Check if content already exists
            existing = await tracking_repo.get_by_platform_id(content_data["content_id"])
            if existing:
                return existing

            # Create new tracked content
            tracked = await tracking_repo.create(brand_id, content_data)
            logger.info(f"Tracked content: {tracked.title}")
            return tracked

        except Exception as e:
            logger.error(f"Error tracking content: {e}")
            raise

    async def sync_creator_followers(
        self, db, creator_handle: str
    ) -> Optional[int]:
        """
        Sync creator follower count (mock implementation)

        Args:
            db: Database session
            creator_handle: Creator handle

        Returns:
            Follower count
        """
        try:
            # In production, this would call the actual API
            # For now, return a mock value
            import random

            followers = random.randint(1000, 1000000)
            logger.info(f"Updated followers for {creator_handle}: {followers}")
            return followers

        except Exception as e:
            logger.error(f"Error syncing creator followers: {e}")
            return None

    def is_influencer(self, follower_count: Optional[int]) -> bool:
        """
        Determine if a creator is an influencer

        Args:
            follower_count: Number of followers

        Returns:
            True if influencer (>100k followers)
        """
        if not follower_count:
            return False
        return follower_count >= 100000

    # ==================== TikTok API Methods ====================

    async def search_tiktok_content(
        self, keyword: str, max_results: int = 50
    ) -> List[dict]:
        """
        Search for content on TikTok

        Args:
            keyword: Search keyword
            max_results: Maximum results to return

        Returns:
            List of TikTok video data
        """
        try:
            # TikTok API integration (mock for MVP)
            logger.info(f"Searching TikTok for keyword: {keyword}")
            return self._get_mock_tiktok_results(keyword, max_results)

        except Exception as e:
            logger.error(f"Error searching TikTok: {e}")
            return self._get_mock_tiktok_results(keyword, max_results)

    async def get_tiktok_statistics(self, video_id: str) -> Optional[dict]:
        """
        Get detailed statistics for a TikTok video

        Args:
            video_id: TikTok video ID

        Returns:
            Video statistics (views, likes, comments, shares)
        """
        try:
            logger.info(f"Fetching TikTok statistics for video: {video_id}")
            return self._get_mock_tiktok_stats(video_id)

        except Exception as e:
            logger.error(f"Error getting TikTok statistics: {e}")
            return self._get_mock_tiktok_stats(video_id)

    def _get_mock_tiktok_results(self, keyword: str, max_results: int) -> List[dict]:
        """Get mock TikTok search results for testing"""
        return [
            {
                "platform": "tiktok",
                "content_id": f"tiktok_video_{i}",
                "title": f"{keyword} - TikTok #{i+1}",
                "description": f"TikTok video about {keyword} #{i+1} #trending",
                "url": f"https://www.tiktok.com/@user/video/tiktok_video_{i}",
                "thumbnail_url": "https://via.placeholder.com/540x960",
                "creator_name": f"@tiktok_creator_{i}",
                "creator_handle": f"creator_{i}",
                "published_at": (
                    datetime.utcnow() - timedelta(days=random.randint(0, 30))
                ).isoformat()
                + "Z",
                "hashtags": ["#trending", f"#{keyword.lower().replace(' ', '')}", f"#creator{i}"],
                "video_duration": random.randint(15, 60),  # seconds
            }
            for i in range(min(max_results, 10))
        ]

    def _get_mock_tiktok_stats(self, video_id: str) -> dict:
        """Get mock TikTok statistics for testing"""
        return {
            "views": random.randint(5000, 500000),
            "likes": random.randint(100, 50000),
            "comments": random.randint(10, 5000),
            "shares": random.randint(5, 2000),
            "bookmarks": random.randint(10, 3000),
            "engagement_rate": round(random.uniform(1.0, 15.0), 2),
        }

    # ==================== Instagram API Methods ====================

    async def search_instagram_content(
        self, keyword: str, max_results: int = 50
    ) -> List[dict]:
        """
        Search for content on Instagram

        Args:
            keyword: Search keyword
            max_results: Maximum results to return

        Returns:
            List of Instagram post data
        """
        try:
            logger.info(f"Searching Instagram for keyword: {keyword}")
            return self._get_mock_instagram_results(keyword, max_results)

        except Exception as e:
            logger.error(f"Error searching Instagram: {e}")
            return self._get_mock_instagram_results(keyword, max_results)

    def _get_mock_instagram_results(self, keyword: str, max_results: int) -> List[dict]:
        """Get mock Instagram search results for testing"""
        return [
            {
                "platform": "instagram",
                "content_id": f"insta_post_{i}",
                "title": f"{keyword} Instagram Post #{i+1}",
                "description": f"Beautiful {keyword} content on Instagram #{i+1}",
                "url": f"https://www.instagram.com/p/insta_post_{i}/",
                "thumbnail_url": "https://via.placeholder.com/540x540",
                "creator_name": f"@insta_creator_{i}",
                "creator_handle": f"insta_user_{i}",
                "published_at": (
                    datetime.utcnow() - timedelta(days=random.randint(0, 60))
                ).isoformat()
                + "Z",
                "hashtags": ["#instagram", f"#{keyword.lower().replace(' ', '')}", "#instagood"],
                "post_type": random.choice(["photo", "carousel", "reel"]),
            }
            for i in range(min(max_results, 10))
        ]

    async def get_instagram_statistics(self, post_id: str) -> Optional[dict]:
        """Get detailed statistics for an Instagram post"""
        return {
            "likes": random.randint(100, 50000),
            "comments": random.randint(5, 2000),
            "shares": random.randint(0, 500),
            "saves": random.randint(10, 5000),
            "engagement_rate": round(random.uniform(0.5, 10.0), 2),
        }

    # ==================== Multi-Platform Methods ====================

    async def search_multi_platform(
        self, keyword: str, platforms: Optional[List[str]] = None, max_results: int = 50
    ) -> dict:
        """
        Search across multiple platforms simultaneously

        Args:
            keyword: Search keyword
            platforms: List of platforms (youtube, tiktok, instagram)
            max_results: Maximum results per platform

        Returns:
            Dict with results organized by platform
        """
        if platforms is None:
            platforms = ["youtube", "tiktok", "instagram"]

        results = {}

        for platform in platforms:
            try:
                if platform.lower() == "youtube":
                    results["youtube"] = await self.search_youtube_content(keyword, max_results)
                elif platform.lower() == "tiktok":
                    results["tiktok"] = await self.search_tiktok_content(keyword, max_results)
                elif platform.lower() == "instagram":
                    results["instagram"] = await self.search_instagram_content(
                        keyword, max_results
                    )
            except Exception as e:
                logger.error(f"Error searching {platform}: {e}")
                results[platform] = []

        return results

    async def get_platform_statistics(
        self, platform: str, content_id: str
    ) -> Optional[dict]:
        """
        Get statistics for content across different platforms

        Args:
            platform: Platform name (youtube, tiktok, instagram)
            content_id: Content ID on the platform

        Returns:
            Statistics dict
        """
        if platform.lower() == "youtube":
            return await self.get_youtube_statistics(content_id)
        elif platform.lower() == "tiktok":
            return await self.get_tiktok_statistics(content_id)
        elif platform.lower() == "instagram":
            return await self.get_instagram_statistics(content_id)
        else:
            logger.warning(f"Unknown platform: {platform}")
            return None

    def get_trending_algorithm(self, content: dict) -> float:
        """
        Calculate trending score based on content metrics

        Args:
            content: Content dict with metrics

        Returns:
            Trending score (0-100)
        """
        views = content.get("views", 0)
        likes = content.get("likes", 0)
        comments = content.get("comments", 0)
        shares = content.get("shares", 0)

        # Normalize metrics
        views_norm = min(views / 100000, 1.0)  # Normalize by 100k views
        likes_norm = min(likes / 5000, 1.0)  # Normalize by 5k likes
        comments_norm = min(comments / 500, 1.0)  # Normalize by 500 comments
        shares_norm = min(shares / 200, 1.0)  # Normalize by 200 shares

        # Weighted scoring
        score = (views_norm * 0.4 + likes_norm * 0.3 + comments_norm * 0.2 + shares_norm * 0.1) * 100

        return round(min(score, 100.0), 2)
