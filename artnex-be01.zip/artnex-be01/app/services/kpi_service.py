"""KPI calculation service"""
import logging
from typing import List, Optional

import numpy as np
from scipy.stats import zscore
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.brand import BrandKPI
from app.models.tracking import TrackedContent
from app.repositories.brand_repository import BrandRepository
from app.repositories.tracking_repository import TrackedContentRepository

logger = logging.getLogger(__name__)


class KPIService:
    """Service for KPI calculation and analytics"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.brand_repo = BrandRepository(db)
        self.tracking_repo = TrackedContentRepository(db)

    async def calculate_popularity_index(self, content: TrackedContent) -> float:
        """
        Calculate popularity index using engagement metrics

        Formula:
        Popularity Index = (Views * 0.4 + Likes * 0.3 + Comments * 0.2 + Shares * 0.1) / 1000

        Args:
            content: TrackedContent object

        Returns:
            Popularity index score (0-100)
        """
        try:
            # Normalize metrics
            views_normalized = min(content.views / 10000, 1.0)  # Cap at 10k views
            likes_normalized = min(content.likes / 1000, 1.0)  # Cap at 1k likes
            comments_normalized = min(content.comments / 100, 1.0)  # Cap at 100 comments
            shares_normalized = min(content.shares / 50, 1.0)  # Cap at 50 shares

            # Weighted calculation
            popularity_index = (
                views_normalized * 0.4
                + likes_normalized * 0.3
                + comments_normalized * 0.2
                + shares_normalized * 0.1
            ) * 100

            return min(popularity_index, 100.0)  # Cap at 100

        except Exception as e:
            logger.error(f"Error calculating popularity index: {e}")
            return 0.0

    async def calculate_engagement_rate(self, content: TrackedContent) -> float:
        """
        Calculate engagement rate

        Formula: (Likes + Comments + Shares) / Views * 100

        Args:
            content: TrackedContent object

        Returns:
            Engagement rate as percentage
        """
        try:
            if content.views == 0:
                return 0.0

            total_engagement = content.likes + content.comments + content.shares
            engagement_rate = (total_engagement / content.views) * 100

            return min(engagement_rate, 100.0)  # Cap at 100%

        except Exception as e:
            logger.error(f"Error calculating engagement rate: {e}")
            return 0.0

    async def calculate_brand_kpi(
        self, brand_id: int, kpi_type: str
    ) -> Optional[float]:
        """
        Calculate brand-level KPI

        Args:
            brand_id: Brand ID
            kpi_type: KPI type (followers, engagement_rate, popularity_index, etc.)

        Returns:
            Calculated KPI value
        """
        try:
            if kpi_type == "average_engagement_rate":
                contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=1000)
                if not contents:
                    return 0.0

                engagement_rates = [content.engagement_rate for content in contents]
                return float(np.mean(engagement_rates))

            elif kpi_type == "average_popularity_index":
                contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=1000)
                if not contents:
                    return 0.0

                popularity_indices = [content.popularity_index for content in contents]
                return float(np.mean(popularity_indices))

            elif kpi_type == "total_views":
                contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=10000)
                return float(sum(content.views for content in contents))

            elif kpi_type == "total_followers":
                contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=1000)
                if not contents:
                    return 0.0

                follower_counts = [
                    content.creator_followers or 0 for content in contents
                ]
                return float(sum(follower_counts))

            elif kpi_type == "influencer_count":
                contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=10000)
                influencer_count = sum(1 for content in contents if content.is_influencer)
                return float(influencer_count)

            elif kpi_type == "content_count":
                count = await self.tracking_repo.count_by_brand_id(brand_id)
                return float(count)

            return None

        except Exception as e:
            logger.error(f"Error calculating KPI {kpi_type}: {e}")
            return None

    async def get_brand_performance_metrics(self, brand_id: int) -> dict:
        """
        Get comprehensive performance metrics for a brand

        Args:
            brand_id: Brand ID

        Returns:
            Dictionary with various KPIs
        """
        try:
            contents = await self.tracking_repo.get_by_brand_id(brand_id, limit=1000)

            if not contents:
                return {
                    "total_content": 0,
                    "total_views": 0,
                    "average_engagement_rate": 0.0,
                    "average_popularity_index": 0.0,
                    "influencer_count": 0,
                }

            # Calculate metrics
            total_views = sum(content.views for content in contents)
            engagement_rates = [content.engagement_rate for content in contents]
            popularity_indices = [content.popularity_index for content in contents]
            influencer_count = sum(1 for content in contents if content.is_influencer)

            return {
                "total_content": len(contents),
                "total_views": total_views,
                "average_engagement_rate": float(np.mean(engagement_rates)),
                "max_engagement_rate": float(np.max(engagement_rates)),
                "min_engagement_rate": float(np.min(engagement_rates)),
                "average_popularity_index": float(np.mean(popularity_indices)),
                "max_popularity_index": float(np.max(popularity_indices)),
                "influencer_count": influencer_count,
                "average_views_per_content": float(total_views / len(contents)),
            }

        except Exception as e:
            logger.error(f"Error getting performance metrics: {e}")
            return {}

    async def detect_trending_topics(
        self, brand_id: int, limit: int = 10
    ) -> List[dict]:
        """
        Detect trending topics using Z-score analysis

        Args:
            brand_id: Brand ID
            limit: Number of trending topics to return

        Returns:
            List of trending topics with scores
        """
        try:
            from app.repositories.tracking_repository import ContentKeywordRepository

            keyword_repo = ContentKeywordRepository(self.db)
            keywords = await keyword_repo.get_top_by_brand(brand_id, limit=100)

            if not keywords:
                return []

            # Extract frequencies
            frequencies = np.array([keyword.frequency for keyword in keywords])

            # Calculate Z-scores
            z_scores = zscore(frequencies)

            # Get trending keywords (Z-score > 1.5)
            trending = [
                {
                    "keyword": keyword.keyword,
                    "frequency": keyword.frequency,
                    "z_score": float(z_scores[i]),
                    "relevance_score": keyword.relevance_score,
                }
                for i, keyword in enumerate(keywords)
                if z_scores[i] > 1.5
            ]

            return sorted(trending, key=lambda x: x["z_score"], reverse=True)[:limit]

        except Exception as e:
            logger.error(f"Error detecting trending topics: {e}")
            return []

    async def calculate_growth_rate(
        self, brand_id: int, days: int = 30
    ) -> Optional[float]:
        """
        Calculate growth rate for engagement

        Args:
            brand_id: Brand ID
            days: Time period in days

        Returns:
            Growth rate as percentage
        """
        try:
            # Get content from first half and second half
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, days=days, limit=10000
            )

            if len(contents) < 2:
                return 0.0

            mid_point = len(contents) // 2
            first_half = contents[:mid_point]
            second_half = contents[mid_point:]

            # Calculate average engagement
            first_half_engagement = np.mean(
                [c.engagement_rate for c in first_half]
            )
            second_half_engagement = np.mean(
                [c.engagement_rate for c in second_half]
            )

            if first_half_engagement == 0:
                return 0.0

            # Calculate growth
            growth_rate = (
                (second_half_engagement - first_half_engagement) / first_half_engagement
            ) * 100

            return float(growth_rate)

        except Exception as e:
            logger.error(f"Error calculating growth rate: {e}")
            return 0.0
