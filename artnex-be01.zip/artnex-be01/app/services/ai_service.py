"""AI service for GPT-based recommendations and analysis"""
import json
import logging
from typing import List, Optional

from openai import AsyncOpenAI

from app.core.config import settings

logger = logging.getLogger(__name__)


class AIService:
    """AI service for GPT-powered features"""

    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = "gpt-4-turbo-preview"
        self.fallback_enabled = True

    async def generate_ai_banner_message(self, brand_count: int, keywords: Optional[List[str]] = None) -> str:
        """
        Generate AI banner message for dashboard

        Args:
            brand_count: Number of user brands
            keywords: Optional brand keywords for context

        Returns:
            AI-generated banner message
        """
        try:
            if brand_count == 0:
                prompt = "제조업 중심의 브랜드 마케팅 SaaS 플랫폼에서 사용자를 환영하는 짧은 한 문장의 배너 메시지를 만들어줘. 사용자는 아직 브랜드를 등록하지 않았다. 격려하고 행동을 촉진하는 내용이어야 한다. 최대 50글자."
            else:
                context = f"사용자가 이미 {brand_count}개의 브랜드를 보유하고 있다."
                if keywords:
                    context += f" 주요 키워드: {', '.join(keywords[:3])}"

                prompt = f"{context}\n제조업 중심의 브랜드 마케팅 SaaS 플랫폼에서 다음 단계 행동을 제안하는 짧은 한 문장의 배너 메시지를 만들어줘. 격려하고 구체적이어야 한다. 최대 50글자."

            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "당신은 제조업 중심 브랜드 마케팅 플랫폼의 AI 어시스턴트입니다. 사용자를 격려하고 다음 단계를 제안하는 메시지를 생성합니다.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.7,
                max_tokens=100,
            )

            message = response.choices[0].message.content.strip()
            logger.info(f"Generated AI banner message for user with {brand_count} brands")
            return message

        except Exception as e:
            logger.error(f"Error generating AI banner message: {e}")
            # Return fallback messages
            if brand_count == 0:
                return "🚀 첫 번째 브랜드를 생성하여 AI 기반 마케팅 자동화를 시작하세요!"
            else:
                return f"💡 {brand_count}개 브랜드의 성장을 위해 인사이트 분석을 시작해보세요!"

    async def recommend_brand_strategies(self, brand_name: str, category: str, keywords: Optional[List[str]] = None) -> dict:
        """
        Recommend marketing strategies for a brand

        Args:
            brand_name: Brand name
            category: Brand category
            keywords: Brand keywords

        Returns:
            Dictionary with recommendations
        """
        try:
            keywords_text = ", ".join(keywords) if keywords else "미정"

            prompt = f"""
브랜드 정보:
- 이름: {brand_name}
- 카테고리: {category}
- 주요 키워드: {keywords_text}

이 브랜드를 위한 마케팅 전략을 JSON 형식으로 추천해주세요.
응답 형식:
{{
    "strategy_1": "전략 설명",
    "strategy_2": "전략 설명",
    "strategy_3": "전략 설명"
}}
최대 3가지 전략을 제안하세요.
"""

            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "당신은 제조업 중심 브랜드 마케팅 전문가입니다. 각 브랜드에 최적화된 마케팅 전략을 추천합니다.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.8,
                max_tokens=500,
            )

            result_text = response.choices[0].message.content.strip()

            # Try to parse JSON
            try:
                result = json.loads(result_text)
            except json.JSONDecodeError:
                # If JSON parsing fails, return as-is
                result = {"strategies": result_text}

            logger.info(f"Generated recommendations for brand: {brand_name}")
            return result

        except Exception as e:
            logger.error(f"Error generating recommendations: {e}")
            return {
                "strategy_1": "SNS 마케팅 강화 (TikTok, Instagram 등에서 트렌디한 콘텐츠 제작)",
                "strategy_2": "인플루언서 협업 (해당 카테고리 관련 마이크로 인플루언서와 협업)",
                "strategy_3": "데이터 기반 타게팅 (고객 세그먼트별 개인화된 캠페인)",
            }

    async def analyze_market_keywords(self, keywords: List[str], industry: str) -> dict:
        """
        Analyze market keywords for an industry

        Args:
            keywords: Keywords to analyze
            industry: Industry name

        Returns:
            Market analysis results
        """
        try:
            keywords_text = ", ".join(keywords)

            prompt = f"""
산업: {industry}
키워드: {keywords_text}

이 산업의 해당 키워드들에 대한 시장 분석을 JSON 형식으로 제공하세요.
응답 형식:
{{
    "trend": "트렌드 설명",
    "market_size": "시장 규모 추정",
    "competition_level": "경쟁 수준 (high/medium/low)",
    "recommendations": ["추천 1", "추천 2"]
}}
"""

            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "당신은 시장 분석 전문가입니다. 키워드와 산업에 기반한 정확한 시장 분석을 제공합니다.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.7,
                max_tokens=600,
            )

            result_text = response.choices[0].message.content.strip()

            try:
                result = json.loads(result_text)
            except json.JSONDecodeError:
                result = {"analysis": result_text}

            logger.info(f"Analyzed keywords for {industry}: {keywords_text}")
            return result

        except Exception as e:
            logger.error(f"Error analyzing keywords: {e}")
            return {
                "trend": "해당 키워드는 최근 성장하는 트렌드입니다",
                "market_size": "중상 규모 시장",
                "competition_level": "medium",
                "recommendations": ["소셜 미디어 강화", "고객 경험 개선", "데이터 분석"],
            }
