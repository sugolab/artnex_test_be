"""Brand service"""
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.brand import Brand
from app.repositories.brand_repository import BrandRepository


class BrandService:
    """Brand service for brand operations"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.brand_repo = BrandRepository(db)

    async def create_brand(self, user_id: int, brand_data: dict) -> Brand:
        """
        Create new brand

        Args:
            user_id: User ID
            brand_data: Brand data

        Returns:
            Created Brand
        """
        # Validate brand data
        if "name" not in brand_data or not brand_data["name"]:
            raise ValueError("Brand name is required")

        brand = await self.brand_repo.create(user_id, brand_data)
        return brand

    async def get_brand(self, brand_id: int, user_id: int, include_kpis: bool = True) -> Optional[Brand]:
        """
        Get brand by ID

        Args:
            brand_id: Brand ID
            user_id: User ID (for authorization)
            include_kpis: Include KPIs

        Returns:
            Brand or None
        """
        brand = await self.brand_repo.get_by_id(brand_id, include_kpis=include_kpis)

        if not brand:
            return None

        # Check authorization
        if brand.user_id != user_id:
            raise PermissionError("Not authorized to access this brand")

        return brand

    async def get_user_brands(
        self, user_id: int, skip: int = 0, limit: int = 10
    ) -> tuple[List[Brand], int]:
        """
        Get user's brands

        Args:
            user_id: User ID
            skip: Skip count
            limit: Limit

        Returns:
            Tuple of (brands, total_count)
        """
        brands = await self.brand_repo.get_by_user_id(user_id, skip=skip, limit=limit)
        total = await self.brand_repo.count_by_user_id(user_id)
        return brands, total

    async def search_user_brands(
        self, user_id: int, query: str = "", category: Optional[str] = None, skip: int = 0, limit: int = 10
    ) -> tuple[List[Brand], int]:
        """
        Search user's brands

        Args:
            user_id: User ID
            query: Search query
            category: Category filter
            skip: Skip count
            limit: Limit

        Returns:
            Tuple of (brands, total_count)
        """
        brands, total = await self.brand_repo.search(
            user_id, query=query, category=category, skip=skip, limit=limit
        )
        return brands, total

    async def update_brand(self, brand_id: int, user_id: int, brand_data: dict) -> Optional[Brand]:
        """
        Update brand

        Args:
            brand_id: Brand ID
            user_id: User ID (for authorization)
            brand_data: Brand update data

        Returns:
            Updated Brand or None
        """
        brand = await self.brand_repo.get_by_id(brand_id)

        if not brand:
            return None

        # Check authorization
        if brand.user_id != user_id:
            raise PermissionError("Not authorized to update this brand")

        updated_brand = await self.brand_repo.update(brand_id, brand_data)
        return updated_brand

    async def delete_brand(self, brand_id: int, user_id: int) -> bool:
        """
        Delete brand

        Args:
            brand_id: Brand ID
            user_id: User ID (for authorization)

        Returns:
            True if deleted, False otherwise
        """
        brand = await self.brand_repo.get_by_id(brand_id)

        if not brand:
            return False

        # Check authorization
        if brand.user_id != user_id:
            raise PermissionError("Not authorized to delete this brand")

        return await self.brand_repo.delete(brand_id)

    async def get_brand_categories(self) -> List[str]:
        """
        Get available brand categories

        Returns:
            List of categories
        """
        return [
            "Beauty",
            "Fashion",
            "Food & Beverage",
            "Technology",
            "Home & Garden",
            "Sports",
            "Health & Wellness",
            "Other",
        ]
