"""Dashboard service"""
from datetime import datetime
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.brand import Brand
from app.repositories.brand_repository import BrandRepository
from app.repositories.user_repository import UserRepository
from app.repositories.activity_repository import ActivityRepository, GuideResourceRepository
from app.schemas.brand import BrandSearchResponse, BrandShortcutResponse
from app.schemas.dashboard import DashboardResponse, DashboardSummary, GuideResource, UserActivityResponse
from app.services.ai_service import AIService


class DashboardService:
    """Dashboard service for aggregating dashboard data"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.brand_repo = BrandRepository(db)
        self.user_repo = UserRepository(db)
        self.activity_repo = ActivityRepository(db)
        self.guide_repo = GuideResourceRepository(db)

    async def get_dashboard_summary(self, user_id: int) -> DashboardSummary:
        """
        Get dashboard summary

        Args:
            user_id: User ID

        Returns:
            DashboardSummary
        """
        # Count total brands
        total_brands = await self.brand_repo.count_by_user_id(user_id)

        # Get subscription status (mock)
        subscription_status = "premium"  # Mock: can be extended with Subscription model
        subscription_expires_at = None

        return DashboardSummary(
            total_brands=total_brands,
            active_campaigns=0,  # Will be updated with campaign model
            pending_reports=0,  # Will be updated with report model
            subscription_status=subscription_status,
            subscription_expires_at=subscription_expires_at,
        )

    async def get_brand_shortcuts(self, user_id: int, limit: int = 5) -> List[BrandShortcutResponse]:
        """
        Get brand shortcuts for dashboard

        Args:
            user_id: User ID
            limit: Maximum number of shortcuts

        Returns:
            List of BrandShortcutResponse
        """
        brands = await self.brand_repo.get_recent_brands(user_id, days=30, limit=limit)

        shortcuts = []
        for brand in brands:
            # Get latest KPI
            latest_kpi = None
            latest_kpi_value = None
            latest_kpi_type = None

            if brand.kpis:
                latest_kpi = max(brand.kpis, key=lambda x: x.measurement_date)
                latest_kpi_value = latest_kpi.value
                latest_kpi_type = latest_kpi.kpi_type

            shortcut = BrandShortcutResponse(
                id=brand.id,
                name=brand.name,
                category=brand.category or "Uncategorized",
                logo_url=brand.logo_url,
                latest_kpi_value=latest_kpi_value,
                latest_kpi_type=latest_kpi_type,
                last_updated=brand.updated_at,
            )
            shortcuts.append(shortcut)

        return shortcuts

    async def search_brands(
        self, user_id: int, query: str = "", category: Optional[str] = None, page: int = 1, page_size: int = 10
    ) -> tuple[List[BrandSearchResponse], int]:
        """
        Search brands

        Args:
            user_id: User ID
            query: Search query
            category: Brand category filter
            page: Page number
            page_size: Items per page

        Returns:
            Tuple of (results, total_count)
        """
        skip = (page - 1) * page_size
        brands, total = await self.brand_repo.search(
            user_id, query=query, category=category, skip=skip, limit=page_size
        )

        results = []
        for brand in brands:
            # Calculate relevance score (mock)
            relevance_score = 1.0
            if query:
                # Simple relevance calculation based on match
                if query.lower() in brand.name.lower():
                    relevance_score = 0.95
                elif query.lower() in (brand.slogan or "").lower():
                    relevance_score = 0.85

            result = BrandSearchResponse(
                id=brand.id,
                name=brand.name,
                category=brand.category or "Uncategorized",
                slogan=brand.slogan,
                logo_url=brand.logo_url,
                relevance_score=relevance_score,
            )
            results.append(result)

        return results, total

    def get_recommended_brands(self) -> List[BrandSearchResponse]:
        """
        Get AI recommended brands (mock - will be replaced with GPT)

        Returns:
            List of recommended brands
        """
        return [
            BrandSearchResponse(
                id=1,
                name="Recommended Brand 1",
                category="Fashion",
                slogan="Quality & Style",
                logo_url=None,
                relevance_score=0.9,
            ),
            BrandSearchResponse(
                id=2,
                name="Recommended Brand 2",
                category="Beauty",
                slogan="Natural & Pure",
                logo_url=None,
                relevance_score=0.85,
            ),
        ]

    async def get_guide_resources(self) -> List[GuideResource]:
        """
        Get guide resources from database

        Returns:
            List of guide resources
        """
        guides = await self.guide_repo.get_all_active()

        return [
            GuideResource(
                id=guide.id,
                title=guide.title,
                description=guide.description,
                resource_type=guide.resource_type,
                resource_url=guide.resource_url,
                category=guide.category,
                order=guide.order,
            )
            for guide in guides
        ]

    async def get_recent_activities(self, user_id: int, limit: int = 10) -> List[UserActivityResponse]:
        """
        Get recent user activities from database

        Args:
            user_id: User ID
            limit: Maximum number of activities

        Returns:
            List of recent activities
        """
        activities = await self.activity_repo.get_user_activities(user_id, days=30, limit=limit)

        return [
            UserActivityResponse(
                id=activity.id,
                activity_type=activity.activity_type,
                description=activity.description,
                timestamp=activity.created_at,
                metadata=activity.metadata,
            )
            for activity in activities
        ]

    async def get_ai_banner_message(self, user_id: int) -> str:
        """Get AI banner message with GPT integration"""
        try:
            ai_service = AIService()

            # Get user's brand count and keywords
            total_brands = await self.brand_repo.count_by_user_id(user_id)

            keywords = None
            if total_brands > 0:
                brands = await self.brand_repo.get_by_user_id(user_id, skip=0, limit=1)
                if brands and brands[0].keywords:
                    keywords = brands[0].keywords

            # Generate AI message
            message = await ai_service.generate_ai_banner_message(total_brands, keywords)
            return message
        except Exception as e:
            # Fallback messages
            if total_brands == 0:
                return "🚀 Start by creating your first brand to unlock AI-powered insights!"
            else:
                return "💡 Explore insights and analytics to grow your brands!"

    async def build_dashboard(self, user_id: int) -> DashboardResponse:
        """
        Build complete dashboard response

        Args:
            user_id: User ID

        Returns:
            Complete DashboardResponse
        """
        summary = await self.get_dashboard_summary(user_id)
        brand_shortcuts = await self.get_brand_shortcuts(user_id)
        recommended_brands = self.get_recommended_brands()
        guides = await self.get_guide_resources()
        recent_activities = await self.get_recent_activities(user_id)
        ai_banner_message = await self.get_ai_banner_message(user_id)

        return DashboardResponse(
            user_id=user_id,
            summary=summary,
            brand_shortcuts=brand_shortcuts,
            recommended_brands=recommended_brands,
            guides=guides,
            recent_activities=recent_activities,
            ai_banner_message=ai_banner_message,
        )
