"""Enhanced tracking service with filtering, caching, and KPI integration"""
import json
import logging
from datetime import datetime, timedelta
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.tracking import TrackedContent
from app.repositories.tracking_repository import TrackedContentRepository, ContentKeywordRepository
from app.services.kpi_service import KPIService
from app.utils.cache import RedisCache

logger = logging.getLogger(__name__)


class TrackingService:
    """Service for content tracking with advanced filtering and caching"""

    def __init__(self, db: AsyncSession, cache: Optional[RedisCache] = None):
        self.db = db
        self.tracking_repo = TrackedContentRepository(db)
        self.keyword_repo = ContentKeywordRepository(db)
        self.kpi_service = KPIService(db)
        self.cache = cache

    async def search_with_filters(
        self,
        brand_id: int,
        query: str = "",
        platform: Optional[str] = None,
        min_views: int = 0,
        max_views: Optional[int] = None,
        min_engagement_rate: float = 0.0,
        max_engagement_rate: float = 100.0,
        min_popularity_index: float = 0.0,
        max_popularity_index: float = 100.0,
        is_influencer: Optional[bool] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        sort_by: str = "popularity_index",
        sort_order: str = "desc",
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[List[TrackedContent], int]:
        """
        Advanced search with comprehensive filtering options

        Args:
            brand_id: Brand ID
            query: Search query (title/description)
            platform: Platform filter (youtube, tiktok, instagram, etc.)
            min_views: Minimum views
            max_views: Maximum views
            min_engagement_rate: Minimum engagement rate
            max_engagement_rate: Maximum engagement rate
            min_popularity_index: Minimum popularity index
            max_popularity_index: Maximum popularity index
            is_influencer: Filter by influencer status
            date_from: Filter from date
            date_to: Filter to date
            sort_by: Sort field (views, engagement_rate, popularity_index, etc.)
            sort_order: Sort order (asc, desc)
            skip: Pagination skip
            limit: Pagination limit

        Returns:
            Tuple of (filtered contents, total count)
        """
        # Generate cache key
        cache_key = self._generate_search_cache_key(
            brand_id, query, platform, min_views, skip, limit
        )

        # Check cache
        if self.cache:
            cached_result = await self.cache.get(cache_key)
            if cached_result:
                data = json.loads(cached_result)
                return data["contents"], data["total"]

        try:
            # Build filters
            contents, total = await self.tracking_repo.search(
                brand_id=brand_id,
                query=query,
                platform=platform,
                min_views=min_views,
                skip=skip,
                limit=limit,
            )

            # Apply additional filters in-memory for more complex criteria
            filtered = []
            for content in contents:
                if not self._apply_content_filters(
                    content,
                    max_views=max_views,
                    min_engagement_rate=min_engagement_rate,
                    max_engagement_rate=max_engagement_rate,
                    min_popularity_index=min_popularity_index,
                    max_popularity_index=max_popularity_index,
                    is_influencer=is_influencer,
                    date_from=date_from,
                    date_to=date_to,
                ):
                    continue
                filtered.append(content)

            # Sort
            filtered = self._sort_contents(filtered, sort_by, sort_order)

            # Cache result
            if self.cache:
                cache_data = {
                    "contents": [c.to_dict() if hasattr(c, "to_dict") else c.__dict__ for c in filtered],
                    "total": len(filtered),
                }
                await self.cache.set(cache_key, json.dumps(cache_data), ttl=3600)

            return filtered, len(filtered)

        except Exception as e:
            logger.error(f"Error in advanced search: {e}")
            return [], 0

    async def get_trending_with_metrics(
        self,
        brand_id: int,
        platform: Optional[str] = None,
        limit: int = 10,
    ) -> List[dict]:
        """
        Get trending content with detailed metrics

        Args:
            brand_id: Brand ID
            platform: Platform filter
            limit: Number of results

        Returns:
            List of trending content with metrics
        """
        cache_key = f"trending:{brand_id}:{platform or 'all'}:{limit}"

        if self.cache:
            cached = await self.cache.get(cache_key)
            if cached:
                return json.loads(cached)

        try:
            trending_contents = await self.tracking_repo.get_trending(
                brand_id, platform, limit
            )

            results = []
            for content in trending_contents:
                results.append({
                    "id": content.id,
                    "title": content.title,
                    "platform": content.platform,
                    "creator_name": content.creator_name,
                    "views": content.views,
                    "likes": content.likes,
                    "comments": content.comments,
                    "shares": content.shares,
                    "engagement_rate": round(content.engagement_rate, 2),
                    "popularity_index": round(content.popularity_index, 2),
                    "is_influencer": content.is_influencer,
                    "url": content.url,
                    "thumbnail_url": content.thumbnail_url,
                    "published_at": content.published_at.isoformat() if content.published_at else None,
                })

            if self.cache:
                await self.cache.set(cache_key, json.dumps(results), ttl=3600)

            return results

        except Exception as e:
            logger.error(f"Error getting trending content: {e}")
            return []

    async def get_influencer_analysis(
        self,
        brand_id: int,
        limit: int = 20,
    ) -> dict:
        """
        Get influencer analysis and metrics

        Args:
            brand_id: Brand ID
            limit: Number of influencers to analyze

        Returns:
            Dictionary with influencer metrics
        """
        cache_key = f"influencer_analysis:{brand_id}:{limit}"

        if self.cache:
            cached = await self.cache.get(cache_key)
            if cached:
                return json.loads(cached)

        try:
            influencer_contents = await self.tracking_repo.get_by_influencer(
                brand_id, limit
            )

            if not influencer_contents:
                return {
                    "total_influencers": 0,
                    "total_reach": 0,
                    "average_engagement_rate": 0.0,
                    "top_influencers": [],
                }

            # Calculate metrics
            unique_creators = {}
            for content in influencer_contents:
                creator_key = content.creator_handle or content.creator_name
                if creator_key not in unique_creators:
                    unique_creators[creator_key] = {
                        "creator_name": content.creator_name,
                        "creator_handle": content.creator_handle,
                        "followers": content.creator_followers or 0,
                        "content_count": 0,
                        "total_views": 0,
                        "total_engagement": 0,
                    }
                unique_creators[creator_key]["content_count"] += 1
                unique_creators[creator_key]["total_views"] += content.views
                unique_creators[creator_key]["total_engagement"] += (
                    content.likes + content.comments + content.shares
                )

            # Sort by reach
            top_influencers = sorted(
                unique_creators.values(),
                key=lambda x: x["followers"],
                reverse=True,
            )[:5]

            total_reach = sum(c["followers"] for c in unique_creators.values())
            avg_engagement = (
                sum(c["total_engagement"] for c in unique_creators.values()) /
                sum(c["total_views"] for c in unique_creators.values() if c["total_views"] > 0)
                * 100
            ) if sum(c["total_views"] for c in unique_creators.values()) > 0 else 0

            result = {
                "total_influencers": len(unique_creators),
                "total_reach": total_reach,
                "average_engagement_rate": round(avg_engagement, 2),
                "top_influencers": top_influencers,
            }

            if self.cache:
                await self.cache.set(cache_key, json.dumps(result), ttl=3600)

            return result

        except Exception as e:
            logger.error(f"Error analyzing influencers: {e}")
            return {}

    async def track_content(
        self,
        brand_id: int,
        platform: str,
        content_id: str,
        title: str,
        url: str,
        creator_name: Optional[str] = None,
        creator_handle: Optional[str] = None,
        views: int = 0,
        likes: int = 0,
        comments: int = 0,
        shares: int = 0,
        thumbnail_url: Optional[str] = None,
        published_at: Optional[datetime] = None,
    ) -> Optional[TrackedContent]:
        """
        Track new content with KPI calculation

        Args:
            brand_id: Brand ID
            platform: Platform (youtube, tiktok, instagram, etc.)
            content_id: Platform-specific content ID
            title: Content title
            url: Content URL
            creator_name: Creator name
            creator_handle: Creator handle
            views: View count
            likes: Like count
            comments: Comment count
            shares: Share count
            thumbnail_url: Thumbnail URL
            published_at: Publication date

        Returns:
            Created TrackedContent object
        """
        try:
            # Check for duplicate
            existing = await self.tracking_repo.get_by_platform_id(content_id)
            if existing:
                # Update existing content
                update_data = {
                    "views": views,
                    "likes": likes,
                    "comments": comments,
                    "shares": shares,
                    "engagement_rate": await self.kpi_service.calculate_engagement_rate(
                        TrackedContent(
                            views=views,
                            likes=likes,
                            comments=comments,
                            shares=shares,
                        )
                    ),
                }
                # Calculate popularity index
                temp_content = TrackedContent(
                    views=views,
                    likes=likes,
                    comments=comments,
                    shares=shares,
                )
                update_data["popularity_index"] = await self.kpi_service.calculate_popularity_index(
                    temp_content
                )
                return await self.tracking_repo.update(existing.id, update_data)

            # Determine if influencer
            is_influencer = False
            if creator_name:
                # Simple heuristic: use follower count if available, else assume influencer if views > threshold
                # This should be enhanced with actual influencer detection
                is_influencer = views > 50000

            # Create new content
            content_data = {
                "content_id": content_id,
                "platform": platform,
                "title": title,
                "url": url,
                "creator_name": creator_name,
                "creator_handle": creator_handle,
                "views": views,
                "likes": likes,
                "comments": comments,
                "shares": shares,
                "thumbnail_url": thumbnail_url,
                "published_at": published_at or datetime.utcnow(),
                "is_influencer": is_influencer,
            }

            # Calculate KPIs
            temp_content = TrackedContent(**content_data)
            content_data["engagement_rate"] = await self.kpi_service.calculate_engagement_rate(
                temp_content
            )
            content_data["popularity_index"] = await self.kpi_service.calculate_popularity_index(
                temp_content
            )

            # Create content
            created = await self.tracking_repo.create(brand_id, content_data)

            # Clear cache
            await self._clear_brand_cache(brand_id)

            return created

        except Exception as e:
            logger.error(f"Error tracking content: {e}")
            return None

    def _generate_search_cache_key(
        self,
        brand_id: int,
        query: str,
        platform: Optional[str],
        min_views: int,
        skip: int,
        limit: int,
    ) -> str:
        """Generate cache key for search"""
        return f"search:{brand_id}:{query}:{platform}:{min_views}:{skip}:{limit}"

    def _apply_content_filters(
        self,
        content: TrackedContent,
        max_views: Optional[int] = None,
        min_engagement_rate: float = 0.0,
        max_engagement_rate: float = 100.0,
        min_popularity_index: float = 0.0,
        max_popularity_index: float = 100.0,
        is_influencer: Optional[bool] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
    ) -> bool:
        """Apply content filters"""
        if max_views and content.views > max_views:
            return False

        if content.engagement_rate < min_engagement_rate or content.engagement_rate > max_engagement_rate:
            return False

        if content.popularity_index < min_popularity_index or content.popularity_index > max_popularity_index:
            return False

        if is_influencer is not None and content.is_influencer != is_influencer:
            return False

        if date_from and content.published_at and content.published_at < date_from:
            return False

        if date_to and content.published_at and content.published_at > date_to:
            return False

        return True

    def _sort_contents(
        self,
        contents: List[TrackedContent],
        sort_by: str = "popularity_index",
        sort_order: str = "desc",
    ) -> List[TrackedContent]:
        """Sort contents by specified field"""
        reverse = sort_order.lower() == "desc"

        if sort_by == "views":
            return sorted(contents, key=lambda c: c.views, reverse=reverse)
        elif sort_by == "engagement_rate":
            return sorted(contents, key=lambda c: c.engagement_rate, reverse=reverse)
        elif sort_by == "likes":
            return sorted(contents, key=lambda c: c.likes, reverse=reverse)
        elif sort_by == "comments":
            return sorted(contents, key=lambda c: c.comments, reverse=reverse)
        elif sort_by == "shares":
            return sorted(contents, key=lambda c: c.shares, reverse=reverse)
        elif sort_by == "published_at":
            return sorted(contents, key=lambda c: c.published_at or datetime.utcnow(), reverse=reverse)
        else:  # Default to popularity_index
            return sorted(contents, key=lambda c: c.popularity_index, reverse=reverse)

    async def _clear_brand_cache(self, brand_id: int) -> None:
        """Clear all cache entries for a brand"""
        if not self.cache:
            return

        try:
            # Clear common cache patterns
            patterns = [
                f"search:{brand_id}:*",
                f"trending:{brand_id}:*",
                f"influencer_analysis:{brand_id}:*",
                f"metrics:{brand_id}:*",
            ]

            for pattern in patterns:
                await self.cache.delete(pattern)

        except Exception as e:
            logger.error(f"Error clearing brand cache: {e}")
