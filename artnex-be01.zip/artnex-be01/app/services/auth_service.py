"""Authentication service"""
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (
    create_access_token,
    create_refresh_token,
    hash_password,
    verify_password,
)
from app.models.user import User
from app.repositories.user_repository import UserRepository


class AuthService:
    """Authentication service"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.user_repo = UserRepository(db)

    async def register(
        self, email: str, username: str, password: str, full_name: Optional[str] = None
    ) -> tuple[User, str, str]:
        """
        Register new user

        Args:
            email: User email
            username: Username
            password: Plain password
            full_name: Full name

        Returns:
            Tuple of (User, access_token, refresh_token)
        """
        # Check if user already exists
        existing_user = await self.user_repo.get_by_email(email)
        if existing_user:
            raise ValueError("Email already registered")

        existing_username = await self.user_repo.get_by_username(username)
        if existing_username:
            raise ValueError("Username already taken")

        # Create new user
        hashed_password = hash_password(password)
        user_data = {
            "email": email,
            "username": username,
            "password_hash": hashed_password,
            "full_name": full_name,
            "is_active": True,
            "role_id": 1,  # Default user role
        }

        user = await self.user_repo.create(user_data)

        # Generate tokens
        access_token = create_access_token({"sub": user.id})
        refresh_token = create_refresh_token({"sub": user.id})

        return user, access_token, refresh_token

    async def login(self, email: str, password: str) -> tuple[User, str, str]:
        """
        Login user

        Args:
            email: User email
            password: Plain password

        Returns:
            Tuple of (User, access_token, refresh_token)
        """
        # Get user
        user = await self.user_repo.get_by_email(email)
        if not user:
            raise ValueError("Invalid email or password")

        # Verify password
        if not verify_password(password, user.password_hash):
            raise ValueError("Invalid email or password")

        if not user.is_active:
            raise ValueError("User account is inactive")

        # Generate tokens
        access_token = create_access_token({"sub": user.id})
        refresh_token = create_refresh_token({"sub": user.id})

        return user, access_token, refresh_token

    async def get_user(self, user_id: int) -> Optional[User]:
        """Get user by ID"""
        return await self.user_repo.get_by_id(user_id)
