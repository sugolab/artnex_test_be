"""Advanced content search service with keyword extraction and search optimization"""
import json
import logging
import re
from typing import List, Optional, Set

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.tracking import ContentKeyword, TrackedContent
from app.repositories.tracking_repository import (
    ContentKeywordRepository,
    TrackedContentRepository,
)
from app.utils.cache import RedisCache

logger = logging.getLogger(__name__)


class SearchService:
    """Service for advanced content search with keyword extraction and optimization"""

    def __init__(self, db: AsyncSession, cache: Optional[RedisCache] = None):
        self.db = db
        self.tracking_repo = TrackedContentRepository(db)
        self.keyword_repo = ContentKeywordRepository(db)
        self.cache = cache

        # Common stop words to filter out
        self.stop_words = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
            "of", "with", "by", "from", "as", "is", "was", "are", "be", "been",
            "have", "has", "had", "do", "does", "did", "will", "would", "could",
            "should", "may", "might", "must", "can", "this", "that", "these",
            "those", "i", "you", "he", "she", "it", "we", "they", "what", "which",
            "who", "when", "where", "why", "how", "all", "each", "every", "both",
            "few", "more", "some", "such", "no", "nor", "not", "only", "own",
            "same", "so", "than", "too", "very", "just"
        }

    async def extract_keywords(
        self,
        content: TrackedContent,
        max_keywords: int = 10,
    ) -> List[str]:
        """
        Extract keywords from content title and description

        Args:
            content: TrackedContent object
            max_keywords: Maximum number of keywords to extract

        Returns:
            List of extracted keywords
        """
        try:
            # Combine title and description
            text = f"{content.title} {content.description or ''}".lower()

            # Remove special characters and split into words
            words = re.findall(r"\b[a-z0-9]+\b", text)

            # Filter stop words and short words
            keywords = [
                w for w in words
                if w not in self.stop_words and len(w) > 2
            ]

            # Count frequency
            keyword_freq = {}
            for kw in keywords:
                keyword_freq[kw] = keyword_freq.get(kw, 0) + 1

            # Sort by frequency and get top keywords
            sorted_keywords = sorted(
                keyword_freq.items(),
                key=lambda x: x[1],
                reverse=True,
            )[:max_keywords]

            return [kw[0] for kw in sorted_keywords]

        except Exception as e:
            logger.error(f"Error extracting keywords: {e}")
            return []

    async def index_content_keywords(
        self,
        brand_id: int,
        content: TrackedContent,
        max_keywords: int = 10,
    ) -> List[ContentKeyword]:
        """
        Extract and index keywords for content

        Args:
            brand_id: Brand ID
            content: TrackedContent object
            max_keywords: Maximum number of keywords

        Returns:
            List of created ContentKeyword objects
        """
        try:
            keywords = await self.extract_keywords(content, max_keywords)
            created_keywords = []

            for keyword in keywords:
                # Calculate relevance score based on content metrics
                relevance_score = self._calculate_relevance_score(
                    keyword, content
                )

                kw_obj = await self.keyword_repo.create(
                    brand_id=brand_id,
                    content_id=content.id,
                    keyword_data={
                        "keyword": keyword,
                        "frequency": keywords.count(keyword),
                        "relevance_score": relevance_score,
                    },
                )
                created_keywords.append(kw_obj)

            return created_keywords

        except Exception as e:
            logger.error(f"Error indexing keywords: {e}")
            return []

    async def semantic_search(
        self,
        brand_id: int,
        query: str,
        limit: int = 20,
    ) -> List[dict]:
        """
        Perform semantic search using keyword matching

        Args:
            brand_id: Brand ID
            query: Search query
            limit: Maximum results to return

        Returns:
            List of matching contents with relevance scores
        """
        try:
            cache_key = f"semantic_search:{brand_id}:{query}:{limit}"

            if self.cache:
                cached = await self.cache.get(cache_key)
                if cached:
                    return json.loads(cached)

            # Extract query keywords
            query_keywords = await self.extract_keywords(
                TrackedContent(
                    brand_id=brand_id,
                    content_id="",
                    platform="",
                    title=query,
                    url="",
                    views=0,
                    likes=0,
                    comments=0,
                    shares=0,
                    engagement_rate=0.0,
                    popularity_index=0.0,
                ),
                max_keywords=5,
            )

            if not query_keywords:
                return []

            # Get all content for brand
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, limit=10000
            )

            # Score each content based on keyword matches
            scored_contents = []
            for content in contents:
                score = self._calculate_content_relevance(
                    content, query_keywords
                )
                if score > 0:
                    scored_contents.append({
                        "content_id": content.id,
                        "title": content.title,
                        "platform": content.platform,
                        "creator_name": content.creator_name,
                        "views": content.views,
                        "engagement_rate": round(content.engagement_rate, 2),
                        "popularity_index": round(content.popularity_index, 2),
                        "relevance_score": round(score, 2),
                        "url": content.url,
                    })

            # Sort by relevance score
            scored_contents.sort(key=lambda x: x["relevance_score"], reverse=True)
            results = scored_contents[:limit]

            # Cache results
            if self.cache:
                await self.cache.set(
                    cache_key, json.dumps(results), ttl=3600
                )

            return results

        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []

    async def search_by_hashtags(
        self,
        brand_id: int,
        hashtags: List[str],
        limit: int = 20,
    ) -> List[dict]:
        """
        Search content by hashtags

        Args:
            brand_id: Brand ID
            hashtags: List of hashtags to search for
            limit: Maximum results

        Returns:
            List of matching contents
        """
        try:
            # Get all content for brand
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, limit=10000
            )

            matched = []
            for content in contents:
                if not content.description:
                    continue

                # Count hashtag matches in description
                matches = 0
                for hashtag in hashtags:
                    clean_tag = hashtag.lstrip("#").lower()
                    if clean_tag in content.description.lower():
                        matches += 1

                if matches > 0:
                    matched.append({
                        "content_id": content.id,
                        "title": content.title,
                        "platform": content.platform,
                        "views": content.views,
                        "engagement_rate": round(content.engagement_rate, 2),
                        "matched_hashtags": matches,
                        "url": content.url,
                    })

            # Sort by match count
            matched.sort(key=lambda x: x["matched_hashtags"], reverse=True)
            return matched[:limit]

        except Exception as e:
            logger.error(f"Error searching hashtags: {e}")
            return []

    async def trending_keywords(
        self,
        brand_id: int,
        limit: int = 20,
    ) -> List[dict]:
        """
        Get trending keywords for a brand

        Args:
            brand_id: Brand ID
            limit: Number of keywords to return

        Returns:
            List of trending keywords with frequency
        """
        try:
            cache_key = f"trending_keywords:{brand_id}:{limit}"

            if self.cache:
                cached = await self.cache.get(cache_key)
                if cached:
                    return json.loads(cached)

            # Get top keywords
            keywords = await self.keyword_repo.get_top_by_brand(brand_id, limit * 2)

            if not keywords:
                return []

            # Build result
            results = [
                {
                    "keyword": kw.keyword,
                    "frequency": kw.frequency,
                    "relevance_score": round(kw.relevance_score, 2),
                }
                for kw in keywords[:limit]
            ]

            # Cache results
            if self.cache:
                await self.cache.set(
                    cache_key, json.dumps(results), ttl=3600
                )

            return results

        except Exception as e:
            logger.error(f"Error getting trending keywords: {e}")
            return []

    async def related_search(
        self,
        brand_id: int,
        content_id: int,
        limit: int = 10,
    ) -> List[dict]:
        """
        Find related content based on shared keywords

        Args:
            brand_id: Brand ID
            content_id: Content ID to find related items for
            limit: Maximum results

        Returns:
            List of related contents
        """
        try:
            # Get keywords for the source content
            keywords = await self.keyword_repo.get_by_content_id(content_id)

            if not keywords:
                return []

            # Extract keyword strings
            keyword_strings = {kw.keyword for kw in keywords}

            # Find other content with same keywords
            all_contents = await self.tracking_repo.get_by_brand_id(
                brand_id, limit=10000
            )

            related = []
            for content in all_contents:
                if content.id == content_id:
                    continue

                content_keywords = await self.keyword_repo.get_by_content_id(
                    content.id
                )
                content_keyword_set = {kw.keyword for kw in content_keywords}

                # Calculate overlap
                overlap = len(keyword_strings & content_keyword_set)

                if overlap > 0:
                    related.append({
                        "content_id": content.id,
                        "title": content.title,
                        "platform": content.platform,
                        "views": content.views,
                        "shared_keywords": overlap,
                        "engagement_rate": round(content.engagement_rate, 2),
                        "url": content.url,
                    })

            # Sort by overlap count
            related.sort(key=lambda x: x["shared_keywords"], reverse=True)
            return related[:limit]

        except Exception as e:
            logger.error(f"Error finding related content: {e}")
            return []

    def _calculate_relevance_score(
        self,
        keyword: str,
        content: TrackedContent,
    ) -> float:
        """Calculate relevance score for a keyword in content"""
        score = 0.0

        # Higher score if keyword is in title
        if keyword in (content.title or "").lower():
            score += 0.5

        # Score based on content popularity
        popularity_factor = min(content.popularity_index / 100, 1.0)
        score += popularity_factor * 0.3

        # Score based on engagement
        engagement_factor = min(content.engagement_rate / 30, 1.0)  # 30% = max
        score += engagement_factor * 0.2

        return min(score, 1.0)  # Cap at 1.0

    def _calculate_content_relevance(
        self,
        content: TrackedContent,
        query_keywords: List[str],
    ) -> float:
        """Calculate overall relevance score for content against query keywords"""
        if not query_keywords:
            return 0.0

        content_text = f"{content.title} {content.description or ''}".lower()

        # Count keyword matches
        matches = sum(1 for kw in query_keywords if kw in content_text)

        if matches == 0:
            return 0.0

        # Base score on match count
        match_score = (matches / len(query_keywords)) * 0.7

        # Boost by popularity and engagement
        popularity_boost = (content.popularity_index / 100) * 0.2
        engagement_boost = (min(content.engagement_rate / 30, 1.0)) * 0.1

        return match_score + popularity_boost + engagement_boost
