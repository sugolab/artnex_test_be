"""Export service for generating CSV and other format exports"""
import csv
import io
import json
import logging
from datetime import datetime
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.tracking import TrackedContent
from app.repositories.tracking_repository import TrackedContentRepository

logger = logging.getLogger(__name__)


class ExportService:
    """Service for exporting tracked content to various formats"""

    def __init__(self, db: AsyncSession):
        self.db = db
        self.tracking_repo = TrackedContentRepository(db)

    async def export_to_csv(
        self,
        brand_id: int,
        platform: Optional[str] = None,
        include_metrics: bool = True,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
    ) -> tuple[str, bytes]:
        """
        Export tracked content to CSV format

        Args:
            brand_id: Brand ID
            platform: Optional platform filter
            include_metrics: Include KPI metrics in export
            date_from: Optional start date filter
            date_to: Optional end date filter

        Returns:
            Tuple of (filename, csv_bytes)
        """
        try:
            # Fetch content
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, platform=platform, limit=10000
            )

            # Filter by date if provided
            if date_from or date_to:
                contents = [
                    c for c in contents
                    if self._is_in_date_range(c.published_at, date_from, date_to)
                ]

            # Create CSV
            output = io.StringIO()
            writer = csv.writer(output)

            # Write header
            header = self._get_csv_header(include_metrics)
            writer.writerow(header)

            # Write data
            for content in contents:
                row = self._content_to_csv_row(content, include_metrics)
                writer.writerow(row)

            # Get bytes
            csv_bytes = output.getvalue().encode("utf-8")

            # Generate filename
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"tracked_content_{brand_id}_{timestamp}.csv"

            return filename, csv_bytes

        except Exception as e:
            logger.error(f"Error exporting to CSV: {e}")
            raise

    async def export_to_json(
        self,
        brand_id: int,
        platform: Optional[str] = None,
        include_metrics: bool = True,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
    ) -> tuple[str, str]:
        """
        Export tracked content to JSON format

        Args:
            brand_id: Brand ID
            platform: Optional platform filter
            include_metrics: Include KPI metrics in export
            date_from: Optional start date filter
            date_to: Optional end date filter

        Returns:
            Tuple of (filename, json_string)
        """
        try:
            # Fetch content
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, platform=platform, limit=10000
            )

            # Filter by date if provided
            if date_from or date_to:
                contents = [
                    c for c in contents
                    if self._is_in_date_range(c.published_at, date_from, date_to)
                ]

            # Build data
            data = {
                "export_timestamp": datetime.utcnow().isoformat(),
                "brand_id": brand_id,
                "total_items": len(contents),
                "contents": [
                    self._content_to_dict(content, include_metrics)
                    for content in contents
                ],
            }

            # Convert to JSON
            json_string = json.dumps(data, indent=2, default=str)

            # Generate filename
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"tracked_content_{brand_id}_{timestamp}.json"

            return filename, json_string

        except Exception as e:
            logger.error(f"Error exporting to JSON: {e}")
            raise

    async def export_summary_report(
        self,
        brand_id: int,
        platform: Optional[str] = None,
    ) -> tuple[str, str]:
        """
        Export summary report with aggregated statistics

        Args:
            brand_id: Brand ID
            platform: Optional platform filter

        Returns:
            Tuple of (filename, csv_bytes)
        """
        try:
            # Fetch content
            contents = await self.tracking_repo.get_by_brand_id(
                brand_id, platform=platform, limit=10000
            )

            if not contents:
                return self._create_empty_report()

            # Calculate statistics
            stats = self._calculate_statistics(contents)

            # Create CSV
            output = io.StringIO()
            writer = csv.writer(output)

            # Write summary section
            writer.writerow(["TRACKED CONTENT SUMMARY REPORT"])
            writer.writerow([f"Generated: {datetime.utcnow().isoformat()}"])
            writer.writerow([f"Brand ID: {brand_id}"])
            if platform:
                writer.writerow([f"Platform Filter: {platform}"])
            writer.writerow([])

            # Write statistics
            writer.writerow(["STATISTICS"])
            writer.writerow(["Metric", "Value"])
            for key, value in stats.items():
                if isinstance(value, float):
                    writer.writerow([key, f"{value:.2f}"])
                else:
                    writer.writerow([key, value])

            writer.writerow([])

            # Write platform breakdown
            if "platform_breakdown" in stats:
                writer.writerow(["PLATFORM BREAKDOWN"])
                writer.writerow(["Platform", "Count", "Total Views", "Avg Engagement Rate"])
                for platform_name, data in stats["platform_breakdown"].items():
                    writer.writerow([
                        platform_name,
                        data["count"],
                        data["total_views"],
                        f"{data['avg_engagement_rate']:.2f}%",
                    ])

            # Get bytes
            csv_bytes = output.getvalue().encode("utf-8")

            # Generate filename
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"summary_report_{brand_id}_{timestamp}.csv"

            return filename, csv_bytes

        except Exception as e:
            logger.error(f"Error exporting summary report: {e}")
            raise

    def _get_csv_header(self, include_metrics: bool = True) -> List[str]:
        """Get CSV header row"""
        header = [
            "Content ID",
            "Platform",
            "Title",
            "Creator Name",
            "Creator Handle",
            "Creator Followers",
            "URL",
            "Published Date",
            "Views",
            "Likes",
            "Comments",
            "Shares",
        ]

        if include_metrics:
            header.extend([
                "Engagement Rate (%)",
                "Popularity Index",
                "Is Influencer",
            ])

        return header

    def _content_to_csv_row(
        self,
        content: TrackedContent,
        include_metrics: bool = True,
    ) -> List:
        """Convert content object to CSV row"""
        row = [
            content.content_id,
            content.platform,
            content.title,
            content.creator_name or "",
            content.creator_handle or "",
            content.creator_followers or "",
            content.url,
            content.published_at.isoformat() if content.published_at else "",
            content.views,
            content.likes,
            content.comments,
            content.shares,
        ]

        if include_metrics:
            row.extend([
                f"{content.engagement_rate:.2f}",
                f"{content.popularity_index:.2f}",
                "Yes" if content.is_influencer else "No",
            ])

        return row

    def _content_to_dict(
        self,
        content: TrackedContent,
        include_metrics: bool = True,
    ) -> dict:
        """Convert content object to dictionary"""
        data = {
            "id": content.id,
            "content_id": content.content_id,
            "platform": content.platform,
            "title": content.title,
            "creator_name": content.creator_name,
            "creator_handle": content.creator_handle,
            "creator_followers": content.creator_followers,
            "url": content.url,
            "thumbnail_url": content.thumbnail_url,
            "published_at": content.published_at.isoformat() if content.published_at else None,
            "views": content.views,
            "likes": content.likes,
            "comments": content.comments,
            "shares": content.shares,
        }

        if include_metrics:
            data.update({
                "engagement_rate": round(content.engagement_rate, 2),
                "popularity_index": round(content.popularity_index, 2),
                "is_influencer": content.is_influencer,
            })

        return data

    def _calculate_statistics(self, contents: List[TrackedContent]) -> dict:
        """Calculate statistics for contents"""
        if not contents:
            return {}

        total_views = sum(c.views for c in contents)
        total_likes = sum(c.likes for c in contents)
        total_comments = sum(c.comments for c in contents)
        total_shares = sum(c.shares for c in contents)
        engagement_rates = [c.engagement_rate for c in contents]
        popularity_indices = [c.popularity_index for c in contents]

        # Platform breakdown
        platform_breakdown = {}
        for content in contents:
            if content.platform not in platform_breakdown:
                platform_breakdown[content.platform] = {
                    "count": 0,
                    "total_views": 0,
                    "avg_engagement_rate": 0,
                }
            platform_breakdown[content.platform]["count"] += 1
            platform_breakdown[content.platform]["total_views"] += content.views
            platform_breakdown[content.platform]["avg_engagement_rate"] += content.engagement_rate

        for platform in platform_breakdown:
            count = platform_breakdown[platform]["count"]
            if count > 0:
                platform_breakdown[platform]["avg_engagement_rate"] /= count

        return {
            "total_content": len(contents),
            "total_views": total_views,
            "total_likes": total_likes,
            "total_comments": total_comments,
            "total_shares": total_shares,
            "avg_views_per_content": total_views / len(contents) if contents else 0,
            "avg_engagement_rate": sum(engagement_rates) / len(engagement_rates) if engagement_rates else 0,
            "max_engagement_rate": max(engagement_rates) if engagement_rates else 0,
            "min_engagement_rate": min(engagement_rates) if engagement_rates else 0,
            "avg_popularity_index": sum(popularity_indices) / len(popularity_indices) if popularity_indices else 0,
            "max_popularity_index": max(popularity_indices) if popularity_indices else 0,
            "min_popularity_index": min(popularity_indices) if popularity_indices else 0,
            "influencer_count": sum(1 for c in contents if c.is_influencer),
            "platform_breakdown": platform_breakdown,
        }

    def _is_in_date_range(
        self,
        date: Optional[datetime],
        date_from: Optional[datetime],
        date_to: Optional[datetime],
    ) -> bool:
        """Check if date is within range"""
        if not date:
            return True

        if date_from and date < date_from:
            return False

        if date_to and date > date_to:
            return False

        return True

    def _create_empty_report(self) -> tuple[str, str]:
        """Create empty report when no content found"""
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["TRACKED CONTENT EXPORT"])
        writer.writerow(["No content found for the specified filters"])

        csv_string = output.getvalue()
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        filename = f"tracked_content_empty_{timestamp}.csv"

        return filename, csv_string
