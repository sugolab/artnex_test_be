"""
Application configuration using Pydantic Settings
"""
from typing import Optional
import os

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""

    # Basic
    APP_NAME: str = "ArtNex API"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "DEBUG"

    # Database
    DATABASE_URL: str
    DATABASE_SYNC_URL: Optional[str] = None
    SQLALCHEMY_ECHO: bool = False

    # Redis
    REDIS_URL: str

    # Security
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # CORS
    CORS_ORIGINS: list = ["http://localhost:3000", "http://localhost:8080", "http://localhost:8000"]

    # API Keys
    OPENAI_API_KEY: str = ""
    IDEOGRAM_API_KEY: str = ""
    YOUTUBE_API_KEY: str = ""

    # AWS
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "ap-northeast-2"
    AWS_S3_BUCKET: str = "artnex-mvp-files"

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_REQUESTS: int = 100
    RATE_LIMIT_PERIOD: int = 60  # seconds

    # Celery
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"

    # Email (Optional)
    MAIL_FROM: str = "noreply@artnex.com"
    SMTP_HOST: str = ""
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""

    # Sentry (Optional)
    SENTRY_DSN: str = ""

    class Config:
        env_file = ".env.test" if os.getenv("TESTING") else ".env"
        case_sensitive = True


# Global settings instance
settings = Settings()  # type: ignore
