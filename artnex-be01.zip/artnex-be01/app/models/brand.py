"""Brand and Brand KPI models"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, Float, ForeignKey, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models import Base


class Brand(Base):
    """Brand table for managing brands"""

    __tablename__ = "brands"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), index=True)
    category: Mapped[str] = mapped_column(String(100), nullable=True)
    slogan: Mapped[str] = mapped_column(String(500), nullable=True)
    mission: Mapped[str] = mapped_column(Text, nullable=True)
    vision: Mapped[str] = mapped_column(Text, nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    keywords: Mapped[list] = mapped_column(JSON, nullable=True)  # JSON array of keywords
    logo_url: Mapped[str] = mapped_column(String(500), nullable=True)
    website: Mapped[str] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    kpis: Mapped[list["BrandKPI"]] = relationship("BrandKPI", back_populates="brand")

    def __repr__(self) -> str:
        return f"<Brand(id={self.id}, name={self.name}, user_id={self.user_id})>"


class BrandKPI(Base):
    """Brand KPI table for tracking key performance indicators"""

    __tablename__ = "brand_kpis"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)
    kpi_type: Mapped[str] = mapped_column(String(100), index=True)  # e.g., 'followers', 'engagement_rate'
    value: Mapped[float] = mapped_column(Float)
    measurement_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relationships
    brand: Mapped["Brand"] = relationship("Brand", back_populates="kpis")

    def __repr__(self) -> str:
        return f"<BrandKPI(id={self.id}, brand_id={self.brand_id}, kpi_type={self.kpi_type}, value={self.value})>"
