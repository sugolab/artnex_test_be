"""Extended brand information models (personas, competitors)"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, ForeignKey, Text, JSON, Float
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base


class BrandPersona(Base):
    """Brand target audience personas"""

    __tablename__ = "brand_personas"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)

    persona_name: Mapped[str] = mapped_column(String(255))
    age_range: Mapped[str] = mapped_column(String(50), nullable=True)  # e.g., "25-35"
    gender: Mapped[str] = mapped_column(String(50), nullable=True)  # e.g., "Female", "All"
    occupation: Mapped[str] = mapped_column(String(255), nullable=True)
    income_level: Mapped[str] = mapped_column(String(50), nullable=True)  # Low, Medium, High
    interests: Mapped[list] = mapped_column(JSON, nullable=True)
    pain_points: Mapped[list] = mapped_column(JSON, nullable=True)
    motivations: Mapped[list] = mapped_column(JSON, nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)

    is_primary: Mapped[bool] = mapped_column(default=False)
    priority: Mapped[int] = mapped_column(default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<BrandPersona(id={self.id}, persona_name={self.persona_name})>"


class Competitor(Base):
    """Competitor information for brand"""

    __tablename__ = "competitors"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)

    competitor_name: Mapped[str] = mapped_column(String(255), index=True)
    category: Mapped[str] = mapped_column(String(100), nullable=True)
    website: Mapped[str] = mapped_column(String(500), nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)

    # Competitive metrics
    market_share: Mapped[float] = mapped_column(Float, nullable=True)
    pricing: Mapped[str] = mapped_column(String(100), nullable=True)  # e.g., "$10-50"
    key_strengths: Mapped[list] = mapped_column(JSON, nullable=True)
    key_weaknesses: Mapped[list] = mapped_column(JSON, nullable=True)

    # Social metrics (cached)
    social_followers: Mapped[int] = mapped_column(Integer, nullable=True)
    engagement_rate: Mapped[float] = mapped_column(Float, nullable=True)

    threat_level: Mapped[str] = mapped_column(String(50), default="medium")  # low, medium, high
    notes: Mapped[str] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<Competitor(id={self.id}, competitor_name={self.competitor_name})>"
