"""Content tracking models for SNS monitoring"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, Float, ForeignKey, Text, JSON, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base


class TrackedContent(Base):
    """Tracked content from SNS (YouTube, TikTok, etc.)"""

    __tablename__ = "tracked_contents"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)

    # Content Info
    content_id: Mapped[str] = mapped_column(String(255), unique=True, index=True)  # Platform-specific ID
    platform: Mapped[str] = mapped_column(String(50), index=True)  # youtube, tiktok, instagram, etc.
    title: Mapped[str] = mapped_column(String(500))
    description: Mapped[str] = mapped_column(Text, nullable=True)
    url: Mapped[str] = mapped_column(String(500))
    thumbnail_url: Mapped[str] = mapped_column(String(500), nullable=True)

    # Creator Info
    creator_name: Mapped[str] = mapped_column(String(255), nullable=True)
    creator_handle: Mapped[str] = mapped_column(String(255), nullable=True)
    creator_followers: Mapped[int] = mapped_column(Integer, nullable=True)
    is_influencer: Mapped[bool] = mapped_column(Boolean, default=False, index=True)

    # Metrics
    views: Mapped[int] = mapped_column(Integer, default=0)
    likes: Mapped[int] = mapped_column(Integer, default=0)
    comments: Mapped[int] = mapped_column(Integer, default=0)
    shares: Mapped[int] = mapped_column(Integer, default=0)
    engagement_rate: Mapped[float] = mapped_column(Float, default=0.0)

    # Keywords & Tags
    keywords: Mapped[list] = mapped_column(JSON, nullable=True)  # Extracted keywords
    hashtags: Mapped[list] = mapped_column(JSON, nullable=True)  # Platform hashtags

    # Metadata
    published_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    duration_seconds: Mapped[int] = mapped_column(Integer, nullable=True)  # For videos
    language: Mapped[str] = mapped_column(String(10), nullable=True)

    # Tracking
    popularity_index: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    relevance_score: Mapped[float] = mapped_column(Float, default=0.0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<TrackedContent(id={self.id}, platform={self.platform}, title={self.title[:50]})>"


class ContentKeyword(Base):
    """Extracted keywords from tracked content"""

    __tablename__ = "content_keywords"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)
    content_id: Mapped[int] = mapped_column(Integer, ForeignKey("tracked_contents.id", ondelete="CASCADE"))

    keyword: Mapped[str] = mapped_column(String(255), index=True)
    frequency: Mapped[int] = mapped_column(Integer, default=1)
    relevance_score: Mapped[float] = mapped_column(Float, default=0.0)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<ContentKeyword(keyword={self.keyword}, frequency={self.frequency})>"
