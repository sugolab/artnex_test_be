"""Contract models for brand contract management"""
from datetime import datetime
from enum import Enum

from sqlalchemy import String, DateTime, Integer, ForeignKey, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base


class ContractStatus(str, Enum):
    """Contract status enum"""
    DRAFT = "draft"
    PENDING_SIGN = "pending_sign"
    SIGNED = "signed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class Contract(Base):
    """Contract table for managing brand contracts"""

    __tablename__ = "contracts"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)

    title: Mapped[str] = mapped_column(String(255), index=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)

    contract_type: Mapped[str] = mapped_column(String(100), nullable=True)  # e.g., "Partnership", "Service Agreement"
    status: Mapped[str] = mapped_column(String(50), default=ContractStatus.DRAFT, index=True)

    # Contract parties
    party_name: Mapped[str] = mapped_column(String(255), nullable=True)
    party_email: Mapped[str] = mapped_column(String(255), nullable=True)

    # Contract details
    start_date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    end_date: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    value: Mapped[float] = mapped_column(default=0.0)

    # File management
    file_url: Mapped[str] = mapped_column(String(500), nullable=True)
    file_name: Mapped[str] = mapped_column(String(255), nullable=True)

    # Signatures
    signed_by: Mapped[str] = mapped_column(String(255), nullable=True)
    signed_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    signature_url: Mapped[str] = mapped_column(String(500), nullable=True)

    # Notes
    terms: Mapped[str] = mapped_column(Text, nullable=True)
    notes: Mapped[str] = mapped_column(Text, nullable=True)

    # Metadata
    contract_metadata: Mapped[dict] = mapped_column(JSON, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<Contract(id={self.id}, title={self.title}, status={self.status})>"
