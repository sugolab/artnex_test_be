"""SKU (Stock Keeping Unit) and inventory models"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, Float, ForeignKey, Boolean, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models import Base


class SKU(Base):
    """SKU table for product management"""

    __tablename__ = "skus"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)
    sku_code: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    product_name: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text, nullable=True)
    category: Mapped[str] = mapped_column(String(100), nullable=True)
    unit_price: Mapped[float] = mapped_column(Float, nullable=True)
    quantity_in_stock: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<SKU(id={self.id}, sku_code={self.sku_code}, product_name={self.product_name})>"
