"""Brand Report model"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, Float, ForeignKey, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models import Base


class BrandReport(Base):
    """Brand Report table for storing diagnosis and analysis results"""

    __tablename__ = "brand_reports"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    brand_id: Mapped[int] = mapped_column(Integer, ForeignKey("brands.id", ondelete="CASCADE"), index=True)
    report_type: Mapped[str] = mapped_column(String(100), index=True)  # e.g., 'diagnosis', 'analysis'
    overall_score: Mapped[float] = mapped_column(Float, nullable=True)
    ai_summary: Mapped[str] = mapped_column(Text, nullable=True)
    pdf_url: Mapped[str] = mapped_column(String(500), nullable=True)
    sections: Mapped[dict] = mapped_column(JSON, nullable=True)  # Store report sections as JSON
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<BrandReport(id={self.id}, brand_id={self.brand_id}, report_type={self.report_type})>"
