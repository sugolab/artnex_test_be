"""Database models"""
from sqlalchemy.orm import declarative_base

Base = declarative_base()

# Import all models to register them with Base metadata
# This must happen after Base is created
from app.models.user import User
from app.models.brand import Brand, BrandKPI
from app.models.brand_report import BrandReport
from app.models.activity import UserActivity, GuideResource, ActivityType
from app.models.payment import UserSubscription, Payment, SubscriptionPlan, SubscriptionStatus
from app.models.sku import SKU
from app.models.tracking import TrackedContent, ContentKeyword
from app.models.brand_info import BrandPersona, Competitor
from app.models.project import Project, Task, ProjectStatus, TaskStatus
from app.models.contract import Contract, ContractStatus

__all__ = [
    "Base",
    "User",
    "Brand",
    "BrandKPI",
    "BrandReport",
    "UserActivity",
    "GuideResource",
    "ActivityType",
    "UserSubscription",
    "Payment",
    "SubscriptionPlan",
    "SubscriptionStatus",
    "SKU",
    "TrackedContent",
    "ContentKeyword",
    "BrandPersona",
    "Competitor",
    "Project",
    "Task",
    "ProjectStatus",
    "TaskStatus",
    "Contract",
    "ContractStatus",
]
