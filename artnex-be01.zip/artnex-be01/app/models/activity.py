"""Activity and guide resource models"""
from datetime import datetime

from sqlalchemy import String, DateTime, Integer, ForeignKey, Text, JSON, Enum as SQLEnum
from sqlalchemy.orm import Mapped, mapped_column
import enum

from app.models import Base


class ActivityType(str, enum.Enum):
    """Activity types"""

    BRAND_CREATED = "brand_created"
    BRAND_UPDATED = "brand_updated"
    BRAND_DELETED = "brand_deleted"
    REPORT_GENERATED = "report_generated"
    CAMPAIGN_CREATED = "campaign_created"
    CAMPAIGN_UPDATED = "campaign_updated"
    DESIGN_CREATED = "design_created"
    LOGIN = "login"
    OTHER = "other"


class UserActivity(Base):
    """User activity log table"""

    __tablename__ = "user_activities"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    activity_type: Mapped[str] = mapped_column(String(50), index=True)
    description: Mapped[str] = mapped_column(String(500))
    activity_metadata: Mapped[dict] = mapped_column(JSON, nullable=True)  # e.g., {'brand_id': 1, 'report_id': 5}
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    def __repr__(self) -> str:
        return f"<UserActivity(id={self.id}, user_id={self.user_id}, activity_type={self.activity_type})>"


class GuideResource(Base):
    """Guide resource (tutorial, example, documentation) table"""

    __tablename__ = "guide_resources"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String(255), index=True)
    description: Mapped[str] = mapped_column(String(1000))
    resource_type: Mapped[str] = mapped_column(String(50), index=True)  # 'video', 'example', 'guide', 'doc'
    category: Mapped[str] = mapped_column(String(100), index=True)  # 'onboarding', 'branding', 'analytics', etc.
    resource_url: Mapped[str] = mapped_column(String(500))  # S3 URL or external link
    thumbnail_url: Mapped[str] = mapped_column(String(500), nullable=True)
    order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    def __repr__(self) -> str:
        return f"<GuideResource(id={self.id}, title={self.title}, resource_type={self.resource_type})>"
