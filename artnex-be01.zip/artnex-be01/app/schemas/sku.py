"""SKU schemas"""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class SKUBase(BaseModel):
    """Base SKU schema"""

    sku_code: str = Field(..., min_length=1, max_length=100)
    product_name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    category: Optional[str] = Field(None, max_length=100)
    unit_price: Optional[float] = Field(None, ge=0)
    quantity_in_stock: int = Field(default=0, ge=0)


class SKUCreate(SKUBase):
    """SKU creation schema"""

    pass


class SKUUpdate(BaseModel):
    """SKU update schema"""

    sku_code: Optional[str] = None
    product_name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    unit_price: Optional[float] = None
    quantity_in_stock: Optional[int] = None
    is_active: Optional[bool] = None


class SKUResponse(SKUBase):
    """SKU response schema"""

    id: int
    brand_id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class BrandPersonaBase(BaseModel):
    """Base brand persona schema"""

    persona_name: str = Field(..., min_length=1, max_length=255)
    age_range: Optional[str] = None
    gender: Optional[str] = None
    occupation: Optional[str] = None
    income_level: Optional[str] = None
    interests: Optional[List[str]] = None
    pain_points: Optional[List[str]] = None
    motivations: Optional[List[str]] = None
    description: Optional[str] = None
    is_primary: bool = False
    priority: int = Field(default=0, ge=0)


class BrandPersonaCreate(BrandPersonaBase):
    """Create brand persona schema"""

    pass


class BrandPersonaResponse(BrandPersonaBase):
    """Brand persona response schema"""

    id: int
    brand_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CompetitorBase(BaseModel):
    """Base competitor schema"""

    competitor_name: str = Field(..., min_length=1, max_length=255)
    category: Optional[str] = None
    website: Optional[str] = None
    description: Optional[str] = None
    market_share: Optional[float] = None
    pricing: Optional[str] = None
    key_strengths: Optional[List[str]] = None
    key_weaknesses: Optional[List[str]] = None
    social_followers: Optional[int] = None
    engagement_rate: Optional[float] = None
    threat_level: str = Field(default="medium")
    notes: Optional[str] = None


class CompetitorCreate(CompetitorBase):
    """Create competitor schema"""

    pass


class CompetitorResponse(CompetitorBase):
    """Competitor response schema"""

    id: int
    brand_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
