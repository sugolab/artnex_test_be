"""Tracking and content schemas"""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class TrackedContentBase(BaseModel):
    """Base tracked content schema"""

    platform: str = Field(..., max_length=50)
    title: str = Field(..., max_length=500)
    description: Optional[str] = None
    url: str = Field(..., max_length=500)
    thumbnail_url: Optional[str] = None
    creator_name: Optional[str] = None
    creator_handle: Optional[str] = None
    creator_followers: Optional[int] = None


class TrackedContentCreate(TrackedContentBase):
    """Create tracked content schema"""

    content_id: str = Field(..., max_length=255)
    keywords: Optional[List[str]] = None
    hashtags: Optional[List[str]] = None
    published_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    language: Optional[str] = None


class TrackedContentResponse(TrackedContentBase):
    """Tracked content response schema"""

    id: int
    brand_id: int
    content_id: str
    views: int
    likes: int
    comments: int
    shares: int
    engagement_rate: float
    popularity_index: float
    is_influencer: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class TrackedContentDetailResponse(TrackedContentResponse):
    """Detailed tracked content response"""

    keywords: Optional[List[str]] = None
    hashtags: Optional[List[str]] = None
    relevance_score: float


class ContentSearchQuery(BaseModel):
    """Content search query"""

    query: str
    platform: Optional[str] = None
    min_views: int = Field(default=0, ge=0)
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)


class ContentSearchResponse(BaseModel):
    """Content search response"""

    total: int
    page: int
    page_size: int
    results: List[TrackedContentResponse]
