"""Brand schemas for request/response validation"""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class BrandKPIResponse(BaseModel):
    """Brand KPI response schema"""

    id: int
    brand_id: int
    kpi_type: str
    value: float
    measurement_date: datetime

    class Config:
        from_attributes = True


class BrandBase(BaseModel):
    """Base brand schema"""

    name: str = Field(..., min_length=1, max_length=255)
    category: Optional[str] = Field(None, max_length=100)
    slogan: Optional[str] = Field(None, max_length=500)
    mission: Optional[str] = None
    vision: Optional[str] = None
    description: Optional[str] = None
    keywords: Optional[List[str]] = None
    website: Optional[str] = Field(None, max_length=255)


class BrandCreate(BrandBase):
    """Brand creation schema"""

    pass


class BrandUpdate(BaseModel):
    """Brand update schema"""

    name: Optional[str] = None
    category: Optional[str] = None
    slogan: Optional[str] = None
    mission: Optional[str] = None
    vision: Optional[str] = None
    description: Optional[str] = None
    keywords: Optional[List[str]] = None
    website: Optional[str] = None


class BrandResponse(BrandBase):
    """Brand response schema"""

    id: int
    user_id: int
    logo_url: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class BrandDetailResponse(BrandResponse):
    """Brand detail response with KPIs"""

    kpis: List[BrandKPIResponse] = []


class BrandShortcutResponse(BaseModel):
    """Brand shortcut for dashboard"""

    id: int
    name: str
    category: str
    logo_url: Optional[str] = None
    latest_kpi_value: Optional[float] = None
    latest_kpi_type: Optional[str] = None
    last_updated: Optional[datetime] = None


class BrandSearchResponse(BaseModel):
    """Brand search response"""

    id: int
    name: str
    category: str
    slogan: Optional[str] = None
    logo_url: Optional[str] = None
    relevance_score: Optional[float] = None

    class Config:
        from_attributes = True
