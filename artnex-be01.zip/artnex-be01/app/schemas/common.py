"""Common response schemas"""
from typing import Any, Generic, List, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    """Standard API response wrapper"""

    success: bool
    message: str
    data: Optional[T] = None


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated response wrapper"""

    success: bool
    message: str
    total: int
    page: int
    page_size: int
    pages: int
    data: List[T]


class ErrorResponse(BaseModel):
    """Error response"""

    success: bool = False
    message: str
    error_code: Optional[str] = None
    details: Optional[dict] = None
