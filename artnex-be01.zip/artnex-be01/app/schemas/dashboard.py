"""Dashboard schemas"""
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel

from app.schemas.brand import BrandShortcutResponse, BrandSearchResponse


class UserActivityResponse(BaseModel):
    """User activity response"""

    id: Optional[int] = None
    activity_type: str  # 'brand_created', 'report_generated', 'campaign_created', etc.
    description: str
    timestamp: datetime
    metadata: Optional[dict] = None


class GuideResource(BaseModel):
    """Guide resource (tutorial, example, etc.)"""

    id: int
    title: str
    description: str
    resource_type: str  # 'video', 'example', 'guide'
    resource_url: str
    category: str
    order: int = 0


class DashboardSummary(BaseModel):
    """Dashboard summary for quick overview"""

    total_brands: int
    active_campaigns: int
    pending_reports: int
    subscription_status: str  # 'free', 'basic', 'premium', 'enterprise'
    subscription_expires_at: Optional[datetime] = None


class DashboardResponse(BaseModel):
    """Main dashboard response"""

    user_id: int
    summary: DashboardSummary
    brand_shortcuts: List[BrandShortcutResponse]
    recommended_brands: List[BrandSearchResponse]
    guides: List[GuideResource]
    recent_activities: List[UserActivityResponse]
    ai_banner_message: str


class BrandSearchQuery(BaseModel):
    """Brand search query"""

    query: str
    category: Optional[str] = None
    page: int = 1
    page_size: int = 10


class BrandSearchListResponse(BaseModel):
    """Brand search list response"""

    total: int
    page: int
    page_size: int
    results: List[BrandSearchResponse]


class UpgradeRequest(BaseModel):
    """Upgrade subscription request"""

    subscription_plan: str  # 'basic', 'premium', 'enterprise'
    payment_method: Optional[str] = None


class UpgradeResponse(BaseModel):
    """Upgrade response"""

    success: bool
    message: str
    new_subscription_status: str
    transaction_id: Optional[str] = None
