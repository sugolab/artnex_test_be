"""Activity and guide resource repositories"""
from datetime import datetime, timedelta
from typing import List, Optional

from sqlalchemy import and_, desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.activity import GuideResource, UserActivity


class ActivityRepository:
    """User activity repository"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def log_activity(
        self, user_id: int, activity_type: str, description: str, metadata: Optional[dict] = None
    ) -> UserActivity:
        """Log user activity"""
        activity = UserActivity(
            user_id=user_id,
            activity_type=activity_type,
            description=description,
            metadata=metadata,
        )
        self.db.add(activity)
        await self.db.commit()
        await self.db.refresh(activity)
        return activity

    async def get_user_activities(
        self, user_id: int, days: int = 30, limit: int = 10
    ) -> List[UserActivity]:
        """Get recent user activities"""
        since = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(UserActivity)
            .where(and_(UserActivity.user_id == user_id, UserActivity.created_at >= since))
            .order_by(desc(UserActivity.created_at))
            .limit(limit)
        )
        return result.scalars().all()

    async def get_activity_count(self, user_id: int, days: int = 30) -> int:
        """Get count of user activities in last N days"""
        since = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(func.count(UserActivity.id)).where(
                and_(UserActivity.user_id == user_id, UserActivity.created_at >= since)
            )
        )
        return result.scalar() or 0

    async def get_activities_by_type(
        self, user_id: int, activity_type: str, limit: int = 10
    ) -> List[UserActivity]:
        """Get activities by type"""
        result = await self.db.execute(
            select(UserActivity)
            .where(and_(UserActivity.user_id == user_id, UserActivity.activity_type == activity_type))
            .order_by(desc(UserActivity.created_at))
            .limit(limit)
        )
        return result.scalars().all()


class GuideResourceRepository:
    """Guide resource repository"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_all_active(self) -> List[GuideResource]:
        """Get all active guide resources"""
        result = await self.db.execute(
            select(GuideResource)
            .where(GuideResource.is_active == True)
            .order_by(GuideResource.order, GuideResource.created_at)
        )
        return result.scalars().all()

    async def get_by_category(self, category: str) -> List[GuideResource]:
        """Get guide resources by category"""
        result = await self.db.execute(
            select(GuideResource)
            .where(and_(GuideResource.category == category, GuideResource.is_active == True))
            .order_by(GuideResource.order)
        )
        return result.scalars().all()

    async def get_by_type(self, resource_type: str) -> List[GuideResource]:
        """Get guide resources by type"""
        result = await self.db.execute(
            select(GuideResource)
            .where(and_(GuideResource.resource_type == resource_type, GuideResource.is_active == True))
            .order_by(GuideResource.order)
        )
        return result.scalars().all()

    async def get_by_id(self, guide_id: int) -> Optional[GuideResource]:
        """Get guide resource by ID"""
        result = await self.db.execute(select(GuideResource).where(GuideResource.id == guide_id))
        return result.scalar_one_or_none()

    async def create(self, guide_data: dict) -> GuideResource:
        """Create new guide resource"""
        guide = GuideResource(**guide_data)
        self.db.add(guide)
        await self.db.commit()
        await self.db.refresh(guide)
        return guide

    async def get_onboarding_guides(self, limit: int = 5) -> List[GuideResource]:
        """Get onboarding guides for new users"""
        result = await self.db.execute(
            select(GuideResource)
            .where(
                and_(
                    GuideResource.category.in_(["onboarding", "getting_started"]),
                    GuideResource.is_active == True,
                )
            )
            .order_by(GuideResource.order)
            .limit(limit)
        )
        return result.scalars().all()
