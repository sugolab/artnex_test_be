"""SKU repository for inventory management"""
from typing import List, Optional

from sqlalchemy import and_, desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.sku import SKU


class SKURepository:
    """SKU repository for CRUD operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, sku_id: int) -> Optional[SKU]:
        """Get SKU by ID"""
        result = await self.db.execute(select(SKU).where(SKU.id == sku_id))
        return result.scalar_one_or_none()

    async def get_by_code(self, sku_code: str) -> Optional[SKU]:
        """Get SKU by code"""
        result = await self.db.execute(select(SKU).where(SKU.sku_code == sku_code))
        return result.scalar_one_or_none()

    async def get_by_brand_id(
        self, brand_id: int, skip: int = 0, limit: int = 50, active_only: bool = True
    ) -> List[SKU]:
        """Get SKUs by brand ID"""
        filters = [SKU.brand_id == brand_id]
        if active_only:
            filters.append(SKU.is_active == True)

        result = await self.db.execute(
            select(SKU)
            .where(and_(*filters))
            .order_by(desc(SKU.created_at))
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()

    async def count_by_brand_id(self, brand_id: int, active_only: bool = True) -> int:
        """Count SKUs by brand ID"""
        filters = [SKU.brand_id == brand_id]
        if active_only:
            filters.append(SKU.is_active == True)

        result = await self.db.execute(
            select(func.count(SKU.id)).where(and_(*filters))
        )
        return result.scalar() or 0

    async def search(
        self,
        brand_id: int,
        query: str = "",
        category: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[List[SKU], int]:
        """Search SKUs"""
        filters = [SKU.brand_id == brand_id, SKU.is_active == True]

        if query:
            filters.append(
                or_(
                    SKU.sku_code.ilike(f"%{query}%"),
                    SKU.product_name.ilike(f"%{query}%"),
                    SKU.description.ilike(f"%{query}%"),
                )
            )

        if category:
            filters.append(SKU.category == category)

        # Count
        count_result = await self.db.execute(
            select(func.count(SKU.id)).where(and_(*filters))
        )
        total = count_result.scalar() or 0

        # Search
        result = await self.db.execute(
            select(SKU)
            .where(and_(*filters))
            .order_by(SKU.product_name)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all(), total

    async def create(self, brand_id: int, sku_data: dict) -> SKU:
        """Create new SKU"""
        sku = SKU(brand_id=brand_id, **sku_data)
        self.db.add(sku)
        await self.db.commit()
        await self.db.refresh(sku)
        return sku

    async def update(self, sku_id: int, sku_data: dict) -> Optional[SKU]:
        """Update SKU"""
        sku = await self.get_by_id(sku_id)
        if not sku:
            return None

        for key, value in sku_data.items():
            if value is not None:
                setattr(sku, key, value)

        await self.db.commit()
        await self.db.refresh(sku)
        return sku

    async def delete(self, sku_id: int) -> bool:
        """Delete SKU"""
        sku = await self.get_by_id(sku_id)
        if not sku:
            return False

        await self.db.delete(sku)
        await self.db.commit()
        return True
