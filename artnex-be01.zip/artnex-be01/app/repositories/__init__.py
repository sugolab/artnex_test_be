"""Repository layer for database access"""
