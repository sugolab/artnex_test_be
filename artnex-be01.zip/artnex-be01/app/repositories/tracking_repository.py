"""Tracking repository for SNS content monitoring"""
from datetime import datetime, timedelta
from typing import List, Optional

from sqlalchemy import and_, desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.tracking import TrackedContent, ContentKeyword


class TrackedContentRepository:
    """Repository for tracked SNS content"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, content_id: int) -> Optional[TrackedContent]:
        """Get tracked content by ID"""
        result = await self.db.execute(select(TrackedContent).where(TrackedContent.id == content_id))
        return result.scalar_one_or_none()

    async def get_by_platform_id(self, platform_content_id: str) -> Optional[TrackedContent]:
        """Get tracked content by platform-specific ID"""
        result = await self.db.execute(
            select(TrackedContent).where(TrackedContent.content_id == platform_content_id)
        )
        return result.scalar_one_or_none()

    async def get_by_brand_id(
        self,
        brand_id: int,
        platform: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
        days: int = 30,
    ) -> List[TrackedContent]:
        """Get tracked content by brand ID"""
        since = datetime.utcnow() - timedelta(days=days)
        filters = [TrackedContent.brand_id == brand_id, TrackedContent.created_at >= since]

        if platform:
            filters.append(TrackedContent.platform == platform)

        result = await self.db.execute(
            select(TrackedContent)
            .where(and_(*filters))
            .order_by(desc(TrackedContent.views))
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()

    async def count_by_brand_id(self, brand_id: int, days: int = 30) -> int:
        """Count tracked content by brand"""
        since = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(func.count(TrackedContent.id)).where(
                and_(TrackedContent.brand_id == brand_id, TrackedContent.created_at >= since)
            )
        )
        return result.scalar() or 0

    async def search(
        self,
        brand_id: int,
        query: str = "",
        platform: Optional[str] = None,
        min_views: int = 0,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[List[TrackedContent], int]:
        """Search tracked content"""
        filters = [TrackedContent.brand_id == brand_id, TrackedContent.views >= min_views]

        if query:
            filters.append(
                or_(
                    TrackedContent.title.ilike(f"%{query}%"),
                    TrackedContent.description.ilike(f"%{query}%"),
                )
            )

        if platform:
            filters.append(TrackedContent.platform == platform)

        # Count
        count_result = await self.db.execute(
            select(func.count(TrackedContent.id)).where(and_(*filters))
        )
        total = count_result.scalar() or 0

        # Search
        result = await self.db.execute(
            select(TrackedContent)
            .where(and_(*filters))
            .order_by(desc(TrackedContent.popularity_index))
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all(), total

    async def get_trending(
        self, brand_id: int, platform: Optional[str] = None, limit: int = 10
    ) -> List[TrackedContent]:
        """Get trending content by popularity"""
        filters = [TrackedContent.brand_id == brand_id]
        if platform:
            filters.append(TrackedContent.platform == platform)

        result = await self.db.execute(
            select(TrackedContent)
            .where(and_(*filters))
            .order_by(desc(TrackedContent.popularity_index))
            .limit(limit)
        )
        return result.scalars().all()

    async def get_by_influencer(
        self, brand_id: int, limit: int = 50
    ) -> List[TrackedContent]:
        """Get content from influencers"""
        result = await self.db.execute(
            select(TrackedContent)
            .where(
                and_(
                    TrackedContent.brand_id == brand_id,
                    TrackedContent.is_influencer == True,
                )
            )
            .order_by(desc(TrackedContent.views))
            .limit(limit)
        )
        return result.scalars().all()

    async def create(self, brand_id: int, content_data: dict) -> TrackedContent:
        """Create new tracked content"""
        content = TrackedContent(brand_id=brand_id, **content_data)
        self.db.add(content)
        await self.db.commit()
        await self.db.refresh(content)
        return content

    async def update(self, content_id: int, content_data: dict) -> Optional[TrackedContent]:
        """Update tracked content"""
        content = await self.get_by_id(content_id)
        if not content:
            return None

        for key, value in content_data.items():
            if value is not None:
                setattr(content, key, value)

        await self.db.commit()
        await self.db.refresh(content)
        return content

    async def delete(self, content_id: int) -> bool:
        """Delete tracked content"""
        content = await self.get_by_id(content_id)
        if not content:
            return False

        await self.db.delete(content)
        await self.db.commit()
        return True


class ContentKeywordRepository:
    """Repository for content keywords"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_content_id(self, content_id: int) -> List[ContentKeyword]:
        """Get keywords for content"""
        result = await self.db.execute(
            select(ContentKeyword)
            .where(ContentKeyword.content_id == content_id)
            .order_by(desc(ContentKeyword.frequency))
        )
        return result.scalars().all()

    async def get_top_by_brand(self, brand_id: int, limit: int = 20) -> List[ContentKeyword]:
        """Get top keywords for brand"""
        result = await self.db.execute(
            select(ContentKeyword)
            .where(ContentKeyword.brand_id == brand_id)
            .order_by(desc(ContentKeyword.frequency))
            .limit(limit)
        )
        return result.scalars().all()

    async def create(self, brand_id: int, content_id: int, keyword_data: dict) -> ContentKeyword:
        """Create keyword"""
        keyword = ContentKeyword(brand_id=brand_id, content_id=content_id, **keyword_data)
        self.db.add(keyword)
        await self.db.commit()
        await self.db.refresh(keyword)
        return keyword
