"""Brand info repository for personas and competitors"""
from typing import List, Optional

from sqlalchemy import and_, desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.brand_info import BrandPersona, Competitor


class BrandPersonaRepository:
    """Repository for brand personas"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, persona_id: int) -> Optional[BrandPersona]:
        """Get persona by ID"""
        result = await self.db.execute(select(BrandPersona).where(BrandPersona.id == persona_id))
        return result.scalar_one_or_none()

    async def get_by_brand_id(self, brand_id: int) -> List[BrandPersona]:
        """Get all personas for a brand"""
        result = await self.db.execute(
            select(BrandPersona)
            .where(BrandPersona.brand_id == brand_id)
            .order_by(desc(BrandPersona.priority))
        )
        return result.scalars().all()

    async def get_primary_persona(self, brand_id: int) -> Optional[BrandPersona]:
        """Get primary persona for a brand"""
        result = await self.db.execute(
            select(BrandPersona).where(
                and_(BrandPersona.brand_id == brand_id, BrandPersona.is_primary == True)
            )
        )
        return result.scalar_one_or_none()

    async def create(self, brand_id: int, persona_data: dict) -> BrandPersona:
        """Create new persona"""
        persona = BrandPersona(brand_id=brand_id, **persona_data)
        self.db.add(persona)
        await self.db.commit()
        await self.db.refresh(persona)
        return persona

    async def update(self, persona_id: int, persona_data: dict) -> Optional[BrandPersona]:
        """Update persona"""
        persona = await self.get_by_id(persona_id)
        if not persona:
            return None

        for key, value in persona_data.items():
            if value is not None:
                setattr(persona, key, value)

        await self.db.commit()
        await self.db.refresh(persona)
        return persona

    async def delete(self, persona_id: int) -> bool:
        """Delete persona"""
        persona = await self.get_by_id(persona_id)
        if not persona:
            return False

        await self.db.delete(persona)
        await self.db.commit()
        return True


class CompetitorRepository:
    """Repository for competitors"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, competitor_id: int) -> Optional[Competitor]:
        """Get competitor by ID"""
        result = await self.db.execute(select(Competitor).where(Competitor.id == competitor_id))
        return result.scalar_one_or_none()

    async def get_by_brand_id(self, brand_id: int) -> List[Competitor]:
        """Get all competitors for a brand"""
        result = await self.db.execute(
            select(Competitor)
            .where(Competitor.brand_id == brand_id)
            .order_by(desc(Competitor.threat_level))
        )
        return result.scalars().all()

    async def get_by_threat_level(self, brand_id: int, threat_level: str) -> List[Competitor]:
        """Get competitors by threat level"""
        result = await self.db.execute(
            select(Competitor).where(
                and_(Competitor.brand_id == brand_id, Competitor.threat_level == threat_level)
            )
        )
        return result.scalars().all()

    async def create(self, brand_id: int, competitor_data: dict) -> Competitor:
        """Create new competitor"""
        competitor = Competitor(brand_id=brand_id, **competitor_data)
        self.db.add(competitor)
        await self.db.commit()
        await self.db.refresh(competitor)
        return competitor

    async def update(self, competitor_id: int, competitor_data: dict) -> Optional[Competitor]:
        """Update competitor"""
        competitor = await self.get_by_id(competitor_id)
        if not competitor:
            return None

        for key, value in competitor_data.items():
            if value is not None:
                setattr(competitor, key, value)

        await self.db.commit()
        await self.db.refresh(competitor)
        return competitor

    async def delete(self, competitor_id: int) -> bool:
        """Delete competitor"""
        competitor = await self.get_by_id(competitor_id)
        if not competitor:
            return False

        await self.db.delete(competitor)
        await self.db.commit()
        return True
