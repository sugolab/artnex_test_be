"""Brand repository for database operations"""
from datetime import datetime, timedelta
from typing import List, Optional

from sqlalchemy import and_, desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.brand import Brand, BrandKPI


class BrandRepository:
    """Brand repository for CRUD operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, brand_id: int, include_kpis: bool = False) -> Optional[Brand]:
        """Get brand by ID"""
        query = select(Brand).where(Brand.id == brand_id)

        if include_kpis:
            query = query.options(selectinload(Brand.kpis))

        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_by_user_id(
        self, user_id: int, skip: int = 0, limit: int = 10, include_kpis: bool = True
    ) -> List[Brand]:
        """Get brands by user ID with pagination"""
        query = select(Brand).where(Brand.user_id == user_id).offset(skip).limit(limit)

        if include_kpis:
            query = query.options(selectinload(Brand.kpis))

        result = await self.db.execute(query)
        return result.scalars().all()

    async def count_by_user_id(self, user_id: int) -> int:
        """Count brands by user ID"""
        result = await self.db.execute(
            select(func.count(Brand.id)).where(Brand.user_id == user_id)
        )
        return result.scalar() or 0

    async def search(
        self,
        user_id: int,
        query: str = "",
        category: Optional[str] = None,
        skip: int = 0,
        limit: int = 10,
    ) -> tuple[List[Brand], int]:
        """Search brands by query and filters"""
        filters = [Brand.user_id == user_id]

        if query:
            filters.append(
                or_(
                    Brand.name.ilike(f"%{query}%"),
                    Brand.slogan.ilike(f"%{query}%"),
                    Brand.description.ilike(f"%{query}%"),
                )
            )

        if category:
            filters.append(Brand.category == category)

        # Get total count
        count_result = await self.db.execute(
            select(func.count(Brand.id)).where(and_(*filters))
        )
        total = count_result.scalar() or 0

        # Get results
        result = await self.db.execute(
            select(Brand)
            .where(and_(*filters))
            .order_by(desc(Brand.updated_at))
            .offset(skip)
            .limit(limit)
            .options(selectinload(Brand.kpis))
        )
        brands = result.scalars().all()

        return brands, total

    async def create(self, user_id: int, brand_data: dict) -> Brand:
        """Create new brand"""
        brand = Brand(user_id=user_id, **brand_data)
        self.db.add(brand)
        await self.db.commit()
        await self.db.refresh(brand)
        return brand

    async def update(self, brand_id: int, brand_data: dict) -> Optional[Brand]:
        """Update brand"""
        brand = await self.get_by_id(brand_id)
        if not brand:
            return None

        for key, value in brand_data.items():
            if value is not None:
                setattr(brand, key, value)

        brand.updated_at = datetime.utcnow()
        await self.db.commit()
        await self.db.refresh(brand)
        return brand

    async def delete(self, brand_id: int) -> bool:
        """Delete brand (cascade delete KPIs)"""
        brand = await self.get_by_id(brand_id)
        if not brand:
            return False

        await self.db.delete(brand)
        await self.db.commit()
        return True

    async def get_recent_brands(
        self, user_id: int, days: int = 7, limit: int = 5
    ) -> List[Brand]:
        """Get recently updated brands"""
        since = datetime.utcnow() - timedelta(days=days)
        result = await self.db.execute(
            select(Brand)
            .where(and_(Brand.user_id == user_id, Brand.updated_at >= since))
            .order_by(desc(Brand.updated_at))
            .limit(limit)
            .options(selectinload(Brand.kpis))
        )
        return result.scalars().all()

    async def get_with_latest_kpi(self, brand_id: int) -> Optional[Brand]:
        """Get brand with latest KPI"""
        result = await self.db.execute(
            select(Brand)
            .where(Brand.id == brand_id)
            .options(selectinload(Brand.kpis))
        )
        brand = result.scalar_one_or_none()

        if brand and brand.kpis:
            # Sort KPIs by measurement_date and get the latest
            latest_kpi = max(brand.kpis, key=lambda x: x.measurement_date)
            brand.latest_kpi = latest_kpi

        return brand
