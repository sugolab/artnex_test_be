"""API middleware for error handling and performance monitoring"""
import logging
import time
from typing import Callable

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware for global error handling"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request and handle errors"""
        try:
            response = await call_next(request)
            return response
        except Exception as e:
            logger.exception(f"Unhandled error in {request.method} {request.url.path}: {e}")
            return Response(
                content='{"success": false, "message": "Internal server error"}',
                status_code=500,
                media_type="application/json",
            )


class PerformanceMonitoringMiddleware(BaseHTTPMiddleware):
    """Middleware for monitoring API response times"""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Monitor request processing time"""
        start_time = time.time()

        response = await call_next(request)

        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)

        # Log slow requests (> 1 second)
        if process_time > 1.0:
            logger.warning(
                f"Slow request: {request.method} {request.url.path} took {process_time:.2f}s"
            )

        # Log all requests
        logger.debug(
            f"{request.method} {request.url.path} - Status: {response.status_code} - Time: {process_time:.2f}s"
        )

        return response
