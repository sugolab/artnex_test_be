"""API v1 router"""
from fastapi import APIRouter

from app.api.v1.endpoints import (
    auth,
    brands,
    dashboard,
    guides,
    activities,
    payments,
    tracking,
    brand_info,
    export,
    search,
    projects,
    contracts,
)

api_router = APIRouter(prefix="/api/v1", tags=["v1"])

# Include routers
api_router.include_router(auth.router)
api_router.include_router(dashboard.router)
api_router.include_router(brands.router)
api_router.include_router(guides.router)
api_router.include_router(activities.router)
api_router.include_router(payments.router)
api_router.include_router(tracking.router)
api_router.include_router(brand_info.router)
api_router.include_router(export.router)
api_router.include_router(search.router)
api_router.include_router(projects.router)
api_router.include_router(contracts.router)

# Health check endpoint
@api_router.get("/health")
async def health_check() -> dict:
    """Health check endpoint"""
    return {"status": "healthy"}
