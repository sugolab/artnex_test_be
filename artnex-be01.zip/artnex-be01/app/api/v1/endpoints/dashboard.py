"""Dashboard endpoints"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.schemas.brand import BrandSearchResponse, BrandShortcutResponse
from app.schemas.common import ApiResponse, PaginatedResponse
from app.schemas.dashboard import (
    BrandSearchListResponse,
    BrandSearchQuery,
    DashboardResponse,
)
from app.services.dashboard_service import DashboardService

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("", response_model=ApiResponse[DashboardResponse])
async def get_dashboard(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get main dashboard

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        Dashboard data
    """
    try:
        user_id = current_user.get("user_id")
        dashboard_service = DashboardService(db)
        dashboard_data = await dashboard_service.build_dashboard(user_id)

        return ApiResponse(
            success=True,
            message="Dashboard loaded successfully",
            data=dashboard_data,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to load dashboard",
        )


@router.get("/brands/shortcuts", response_model=ApiResponse[list[BrandShortcutResponse]])
async def get_brand_shortcuts(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    limit: int = Query(5, ge=1, le=20),
) -> dict:
    """
    Get brand shortcuts

    Args:
        current_user: Current authenticated user
        db: Database session
        limit: Maximum number of shortcuts

    Returns:
        List of brand shortcuts
    """
    try:
        user_id = current_user.get("user_id")
        dashboard_service = DashboardService(db)
        shortcuts = await dashboard_service.get_brand_shortcuts(user_id, limit=limit)

        return ApiResponse(
            success=True,
            message="Brand shortcuts retrieved",
            data=shortcuts,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve brand shortcuts",
        )


@router.post("/brands/search", response_model=ApiResponse[BrandSearchListResponse])
async def search_brands(
    search_query: BrandSearchQuery,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Search brands

    Args:
        search_query: Search query
        current_user: Current authenticated user
        db: Database session

    Returns:
        Search results
    """
    try:
        user_id = current_user.get("user_id")
        dashboard_service = DashboardService(db)

        results, total = await dashboard_service.search_brands(
            user_id=user_id,
            query=search_query.query,
            category=search_query.category,
            page=search_query.page,
            page_size=search_query.page_size,
        )

        pages = (total + search_query.page_size - 1) // search_query.page_size

        search_response = BrandSearchListResponse(
            total=total,
            page=search_query.page,
            page_size=search_query.page_size,
            results=results,
        )

        return ApiResponse(
            success=True,
            message="Brands searched successfully",
            data=search_response,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search brands",
        )


@router.get("/brands/recommended", response_model=ApiResponse[list[BrandSearchResponse]])
async def get_recommended_brands(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get AI recommended brands (mock - will be replaced with GPT)

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of recommended brands
    """
    try:
        dashboard_service = DashboardService(db)
        recommendations = dashboard_service.get_recommended_brands()

        return ApiResponse(
            success=True,
            message="Recommended brands retrieved",
            data=recommendations,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve recommendations",
        )


@router.get("/user/status")
async def get_user_status(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get user status (subscription, activity, etc.)

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        User status
    """
    try:
        user_id = current_user.get("user_id")
        dashboard_service = DashboardService(db)

        summary = await dashboard_service.get_dashboard_summary(user_id)
        activities = dashboard_service.get_recent_activities(user_id)

        return ApiResponse(
            success=True,
            message="User status retrieved",
            data={
                "summary": summary,
                "recent_activities": activities,
            },
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve user status",
        )
