"""Brand endpoints"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.schemas.brand import BrandCreate, BrandDetailResponse, BrandResponse, BrandUpdate
from app.schemas.common import ApiResponse, PaginatedResponse
from app.services.brand_service import BrandService

router = APIRouter(prefix="/brands", tags=["brands"])


@router.get("", response_model=ApiResponse[PaginatedResponse[BrandResponse]])
async def list_brands(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
) -> dict:
    """
    List user's brands

    Args:
        current_user: Current authenticated user
        db: Database session
        skip: Skip count
        limit: Limit

    Returns:
        Paginated brands
    """
    try:
        user_id = current_user.get("user_id")
        brand_service = BrandService(db)

        brands, total = await brand_service.get_user_brands(user_id, skip=skip, limit=limit)

        pages = (total + limit - 1) // limit
        page = (skip // limit) + 1

        brand_responses = [BrandResponse.from_orm(b) for b in brands]

        paginated = PaginatedResponse(
            success=True,
            message="Brands retrieved successfully",
            total=total,
            page=page,
            page_size=limit,
            pages=pages,
            data=brand_responses,
        )

        return ApiResponse(success=True, message="OK", data=paginated)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve brands",
        )


@router.post("", response_model=ApiResponse[BrandResponse])
async def create_brand(
    brand_data: BrandCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Create new brand

    Args:
        brand_data: Brand creation data
        current_user: Current authenticated user
        db: Database session

    Returns:
        Created brand
    """
    try:
        user_id = current_user.get("user_id")
        brand_service = BrandService(db)

        brand = await brand_service.create_brand(user_id, brand_data.dict())

        return ApiResponse(
            success=True,
            message="Brand created successfully",
            data=BrandResponse.from_orm(brand),
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create brand",
        )


@router.get("/{brand_id}", response_model=ApiResponse[BrandDetailResponse])
async def get_brand(
    brand_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get brand by ID

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session

    Returns:
        Brand detail
    """
    try:
        user_id = current_user.get("user_id")
        brand_service = BrandService(db)

        brand = await brand_service.get_brand(brand_id, user_id, include_kpis=True)

        if not brand:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Brand not found")

        brand_detail = BrandDetailResponse(
            **BrandResponse.from_orm(brand).dict(),
            kpis=[
                {
                    "id": kpi.id,
                    "brand_id": kpi.brand_id,
                    "kpi_type": kpi.kpi_type,
                    "value": kpi.value,
                    "measurement_date": kpi.measurement_date,
                }
                for kpi in brand.kpis
            ],
        )

        return ApiResponse(
            success=True,
            message="Brand retrieved successfully",
            data=brand_detail,
        )
    except PermissionError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to access this brand",
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve brand",
        )


@router.patch("/{brand_id}", response_model=ApiResponse[BrandResponse])
async def update_brand(
    brand_id: int,
    brand_data: BrandUpdate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Update brand

    Args:
        brand_id: Brand ID
        brand_data: Brand update data
        current_user: Current authenticated user
        db: Database session

    Returns:
        Updated brand
    """
    try:
        user_id = current_user.get("user_id")
        brand_service = BrandService(db)

        # Remove None values
        update_data = {k: v for k, v in brand_data.dict().items() if v is not None}

        if not update_data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No fields to update",
            )

        brand = await brand_service.update_brand(brand_id, user_id, update_data)

        if not brand:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Brand not found")

        return ApiResponse(
            success=True,
            message="Brand updated successfully",
            data=BrandResponse.from_orm(brand),
        )
    except PermissionError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this brand",
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update brand",
        )


@router.delete("/{brand_id}")
async def delete_brand(
    brand_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Delete brand

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session

    Returns:
        Success message
    """
    try:
        user_id = current_user.get("user_id")
        brand_service = BrandService(db)

        success = await brand_service.delete_brand(brand_id, user_id)

        if not success:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Brand not found")

        return ApiResponse(success=True, message="Brand deleted successfully")
    except PermissionError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to delete this brand",
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete brand",
        )


@router.get("/categories/all")
async def get_categories(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get available brand categories

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of categories
    """
    try:
        brand_service = BrandService(db)
        categories = await brand_service.get_brand_categories()

        return ApiResponse(
            success=True,
            message="Categories retrieved",
            data=categories,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve categories",
        )
