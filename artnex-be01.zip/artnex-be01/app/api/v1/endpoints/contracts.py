"""Contract management endpoints"""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.models.contract import Contract, ContractStatus
from app.schemas.common import ApiResponse
from app.utils.cache import RedisCache, get_redis_cache

router = APIRouter(prefix="/contracts", tags=["contracts"])


@router.get("", response_model=ApiResponse[list[dict]])
async def list_contracts(
    brand_id: int = Query(...),
    status: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get contracts for a brand"""
    try:
        query = select(Contract).where(Contract.brand_id == brand_id)

        if status:
            query = query.where(Contract.status == status)

        query = query.offset(skip).limit(limit).order_by(Contract.updated_at.desc())

        result = await db.execute(query)
        contracts = result.scalars().all()

        contract_data = [
            {
                "id": c.id,
                "brand_id": c.brand_id,
                "title": c.title,
                "contract_type": c.contract_type,
                "status": c.status,
                "party_name": c.party_name,
                "value": c.value,
                "start_date": c.start_date.isoformat() if c.start_date else None,
                "end_date": c.end_date.isoformat() if c.end_date else None,
                "signed_at": c.signed_at.isoformat() if c.signed_at else None,
                "created_at": c.created_at.isoformat(),
                "updated_at": c.updated_at.isoformat(),
            }
            for c in contracts
        ]

        return ApiResponse(success=True, message="Contracts retrieved", data=contract_data)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve contracts",
        )


@router.post("", response_model=ApiResponse[dict])
async def create_contract(
    brand_id: int = Query(...),
    title: str = Query(...),
    contract_type: Optional[str] = Query(None),
    description: Optional[str] = Query(None),
    party_name: Optional[str] = Query(None),
    party_email: Optional[str] = Query(None),
    value: float = Query(0.0, ge=0),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Create new contract"""
    try:
        contract = Contract(
            brand_id=brand_id,
            title=title,
            contract_type=contract_type,
            description=description,
            party_name=party_name,
            party_email=party_email,
            value=value,
            start_date=start_date,
            end_date=end_date,
            status=ContractStatus.DRAFT,
        )

        db.add(contract)
        await db.commit()
        await db.refresh(contract)

        # Invalidate cache
        if cache:
            await cache.delete(f"contracts:{brand_id}")

        return ApiResponse(
            success=True,
            message="Contract created",
            data={
                "id": contract.id,
                "title": contract.title,
                "status": contract.status,
            },
        )

    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create contract",
        )


@router.get("/{contract_id}", response_model=ApiResponse[dict])
async def get_contract(
    contract_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get contract details"""
    try:
        contract = await db.get(Contract, contract_id)

        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contract not found")

        return ApiResponse(
            success=True,
            message="Contract retrieved",
            data={
                "id": contract.id,
                "brand_id": contract.brand_id,
                "title": contract.title,
                "description": contract.description,
                "contract_type": contract.contract_type,
                "status": contract.status,
                "party_name": contract.party_name,
                "party_email": contract.party_email,
                "value": contract.value,
                "start_date": contract.start_date.isoformat() if contract.start_date else None,
                "end_date": contract.end_date.isoformat() if contract.end_date else None,
                "file_url": contract.file_url,
                "file_name": contract.file_name,
                "signed_at": contract.signed_at.isoformat() if contract.signed_at else None,
                "terms": contract.terms,
                "notes": contract.notes,
                "created_at": contract.created_at.isoformat(),
                "updated_at": contract.updated_at.isoformat(),
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve contract",
        )


@router.patch("/{contract_id}", response_model=ApiResponse[dict])
async def update_contract(
    contract_id: int,
    status: Optional[str] = Query(None),
    title: Optional[str] = Query(None),
    terms: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Update contract"""
    try:
        contract = await db.get(Contract, contract_id)

        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contract not found")

        if status:
            contract.status = status
        if title:
            contract.title = title
        if terms:
            contract.terms = terms

        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"contracts:{contract.brand_id}")

        return ApiResponse(
            success=True,
            message="Contract updated",
            data={"id": contract.id, "status": contract.status},
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update contract",
        )


@router.post("/{contract_id}/upload")
async def upload_contract_file(
    contract_id: int,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Upload contract file"""
    try:
        contract = await db.get(Contract, contract_id)

        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contract not found")

        # Mock file handling - in production, upload to S3
        contract.file_name = file.filename
        contract.file_url = f"s3://artnex-contracts/{contract_id}/{file.filename}"

        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"contracts:{contract.brand_id}")

        return ApiResponse(
            success=True,
            message="File uploaded",
            data={
                "id": contract.id,
                "file_name": contract.file_name,
                "file_url": contract.file_url,
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to upload file",
        )


@router.post("/{contract_id}/sign")
async def sign_contract(
    contract_id: int,
    signed_by: str = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Sign contract"""
    try:
        contract = await db.get(Contract, contract_id)

        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contract not found")

        contract.status = ContractStatus.SIGNED
        contract.signed_by = signed_by
        contract.signed_at = datetime.utcnow()

        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"contracts:{contract.brand_id}")

        return ApiResponse(
            success=True,
            message="Contract signed",
            data={
                "id": contract.id,
                "status": contract.status,
                "signed_at": contract.signed_at.isoformat(),
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to sign contract",
        )


@router.delete("/{contract_id}")
async def delete_contract(
    contract_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Delete contract"""
    try:
        contract = await db.get(Contract, contract_id)

        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contract not found")

        brand_id = contract.brand_id
        await db.delete(contract)
        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"contracts:{brand_id}")

        return ApiResponse(success=True, message="Contract deleted")

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete contract",
        )
