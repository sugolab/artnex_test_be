"""Export endpoints for content and reports"""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.schemas.common import ApiResponse
from app.services.export_service import ExportService

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/tracked-content/csv")
async def export_tracked_content_csv(
    brand_id: int = Query(...),
    platform: Optional[str] = Query(None),
    include_metrics: bool = Query(True),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Export tracked content to CSV format

    Args:
        brand_id: Brand ID
        platform: Optional platform filter
        include_metrics: Include KPI metrics in export
        current_user: Current authenticated user
        db: Database session

    Returns:
        CSV file as streaming response
    """
    try:
        service = ExportService(db)
        filename, csv_bytes = await service.export_to_csv(
            brand_id=brand_id,
            platform=platform,
            include_metrics=include_metrics,
        )

        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export to CSV",
        )


@router.get("/tracked-content/json")
async def export_tracked_content_json(
    brand_id: int = Query(...),
    platform: Optional[str] = Query(None),
    include_metrics: bool = Query(True),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Export tracked content to JSON format

    Args:
        brand_id: Brand ID
        platform: Optional platform filter
        include_metrics: Include KPI metrics in export
        current_user: Current authenticated user
        db: Database session

    Returns:
        JSON file as streaming response
    """
    try:
        service = ExportService(db)
        filename, json_string = await service.export_to_json(
            brand_id=brand_id,
            platform=platform,
            include_metrics=include_metrics,
        )

        return StreamingResponse(
            iter([json_string.encode("utf-8")]),
            media_type="application/json",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export to JSON",
        )


@router.get("/summary-report/csv")
async def export_summary_report_csv(
    brand_id: int = Query(...),
    platform: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Export summary report with aggregated statistics

    Args:
        brand_id: Brand ID
        platform: Optional platform filter
        current_user: Current authenticated user
        db: Database session

    Returns:
        Summary report CSV file
    """
    try:
        service = ExportService(db)
        filename, csv_bytes = await service.export_summary_report(
            brand_id=brand_id,
            platform=platform,
        )

        return StreamingResponse(
            iter([csv_bytes]),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export summary report",
        )


@router.get("/formats", response_model=ApiResponse[list])
async def get_export_formats(
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Get available export formats

    Args:
        current_user: Current authenticated user

    Returns:
        List of available export formats
    """
    formats = [
        {
            "format": "csv",
            "description": "Comma-separated values",
            "mime_type": "text/csv",
            "extension": ".csv",
        },
        {
            "format": "json",
            "description": "JSON format with metadata",
            "mime_type": "application/json",
            "extension": ".json",
        },
        {
            "format": "summary",
            "description": "Summary report with statistics",
            "mime_type": "text/csv",
            "extension": ".csv",
        },
    ]

    return ApiResponse(
        success=True,
        message="Available export formats",
        data=formats,
    )
