"""User activity endpoints"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.repositories.activity_repository import ActivityRepository
from app.schemas.common import ApiResponse
from app.schemas.dashboard import UserActivityResponse

router = APIRouter(prefix="/activities", tags=["activities"])


@router.get("", response_model=ApiResponse[list[UserActivityResponse]])
async def get_user_activities(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(10, ge=1, le=100),
) -> dict:
    """
    Get user's recent activities

    Args:
        current_user: Current authenticated user
        db: Database session
        days: Number of days to look back
        limit: Maximum number of activities

    Returns:
        List of user activities
    """
    try:
        user_id = current_user.get("user_id")
        activity_repo = ActivityRepository(db)

        activities = await activity_repo.get_user_activities(user_id, days=days, limit=limit)

        activity_responses = [
            UserActivityResponse(
                id=activity.id,
                activity_type=activity.activity_type,
                description=activity.description,
                timestamp=activity.created_at,
                metadata=activity.metadata,
            )
            for activity in activities
        ]

        return ApiResponse(
            success=True,
            message="User activities retrieved",
            data=activity_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve activities",
        )


@router.get("/by-type/{activity_type}", response_model=ApiResponse[list[UserActivityResponse]])
async def get_activities_by_type(
    activity_type: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    limit: int = Query(10, ge=1, le=100),
) -> dict:
    """
    Get user's activities by type

    Args:
        activity_type: Type of activity (e.g., 'brand_created', 'report_generated')
        current_user: Current authenticated user
        db: Database session
        limit: Maximum number of activities

    Returns:
        List of activities of the specified type
    """
    try:
        user_id = current_user.get("user_id")
        activity_repo = ActivityRepository(db)

        activities = await activity_repo.get_activities_by_type(user_id, activity_type, limit=limit)

        activity_responses = [
            UserActivityResponse(
                id=activity.id,
                activity_type=activity.activity_type,
                description=activity.description,
                timestamp=activity.created_at,
                metadata=activity.metadata,
            )
            for activity in activities
        ]

        return ApiResponse(
            success=True,
            message=f"Activities of type '{activity_type}' retrieved",
            data=activity_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve activities",
        )


@router.get("/count", response_model=ApiResponse[dict])
async def get_activity_count(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    days: int = Query(30, ge=1, le=365),
) -> dict:
    """
    Get count of user's activities in last N days

    Args:
        current_user: Current authenticated user
        db: Database session
        days: Number of days to look back

    Returns:
        Activity count
    """
    try:
        user_id = current_user.get("user_id")
        activity_repo = ActivityRepository(db)

        count = await activity_repo.get_activity_count(user_id, days=days)

        return ApiResponse(
            success=True,
            message="Activity count retrieved",
            data={"count": count, "days": days},
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve activity count",
        )
