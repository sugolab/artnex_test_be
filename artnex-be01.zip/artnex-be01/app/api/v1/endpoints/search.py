"""Advanced search endpoints"""
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.models.tracking import TrackedContent
from app.schemas.common import ApiResponse
from app.services.search_service import SearchService
from app.utils.cache import RedisCache, get_redis_cache

router = APIRouter(prefix="/search", tags=["search"])


@router.get("/semantic", response_model=ApiResponse[list])
async def semantic_search(
    brand_id: int = Query(...),
    query: str = Query(...),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Perform semantic search using keyword matching and relevance scoring

    Args:
        brand_id: Brand ID
        query: Search query (natural language)
        limit: Maximum results to return
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        List of matching contents with relevance scores
    """
    try:
        service = SearchService(db, cache)
        results = await service.semantic_search(
            brand_id=brand_id,
            query=query,
            limit=limit,
        )

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} matching contents",
            data=results,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to perform semantic search",
        )


@router.get("/hashtags", response_model=ApiResponse[list])
async def search_by_hashtags(
    brand_id: int = Query(...),
    hashtags: str = Query(...),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Search content by hashtags

    Args:
        brand_id: Brand ID
        hashtags: Comma-separated hashtags (e.g., "#makeup,#beauty,#tutorial")
        limit: Maximum results
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of matching contents
    """
    try:
        # Parse hashtags
        hashtag_list = [
            h.strip().lstrip("#").lower() for h in hashtags.split(",")
        ]

        service = SearchService(db)
        results = await service.search_by_hashtags(
            brand_id=brand_id,
            hashtags=hashtag_list,
            limit=limit,
        )

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} contents matching hashtags",
            data=results,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search by hashtags",
        )


@router.get("/trending-keywords", response_model=ApiResponse[list])
async def get_trending_keywords(
    brand_id: int = Query(...),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get trending keywords for a brand

    Args:
        brand_id: Brand ID
        limit: Number of keywords to return
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        List of trending keywords with frequency
    """
    try:
        service = SearchService(db, cache)
        keywords = await service.trending_keywords(
            brand_id=brand_id,
            limit=limit,
        )

        return ApiResponse(
            success=True,
            message="Trending keywords retrieved",
            data=keywords,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get trending keywords",
        )


@router.get("/related/{content_id}", response_model=ApiResponse[list])
async def find_related_content(
    content_id: int,
    brand_id: int = Query(...),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Find content related to a specific content item

    Args:
        brand_id: Brand ID
        content_id: Content ID to find related items for
        limit: Maximum results
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of related contents
    """
    try:
        service = SearchService(db)
        results = await service.related_search(
            brand_id=brand_id,
            content_id=content_id,
            limit=limit,
        )

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} related contents",
            data=results,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to find related content",
        )


@router.get("/suggestions", response_model=ApiResponse[dict])
async def get_search_suggestions(
    brand_id: int = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get search suggestions for a brand

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Dictionary with search suggestions
    """
    try:
        service = SearchService(db, cache)

        # Get trending keywords for suggestions
        trending = await service.trending_keywords(
            brand_id=brand_id,
            limit=10,
        )

        # Extract keyword strings
        keyword_suggestions = [item["keyword"] for item in trending]

        return ApiResponse(
            success=True,
            message="Search suggestions retrieved",
            data={
                "trending_keywords": keyword_suggestions,
                "suggestion_count": len(keyword_suggestions),
            },
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get search suggestions",
        )
