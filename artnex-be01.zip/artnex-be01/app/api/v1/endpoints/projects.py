"""Project and Task management endpoints"""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.models.project import Project, Task, ProjectStatus, TaskStatus
from app.schemas.common import ApiResponse
from app.utils.cache import RedisCache, get_redis_cache

router = APIRouter(prefix="/projects", tags=["projects"])


# ==================== Project Endpoints ====================

@router.get("", response_model=ApiResponse[list[dict]])
async def list_projects(
    brand_id: int = Query(...),
    status: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get projects for a brand"""
    try:
        query = select(Project).where(Project.brand_id == brand_id)

        if status:
            query = query.where(Project.status == status)

        query = query.offset(skip).limit(limit).order_by(Project.updated_at.desc())

        result = await db.execute(query)
        projects = result.scalars().all()

        project_data = [
            {
                "id": p.id,
                "brand_id": p.brand_id,
                "name": p.name,
                "description": p.description,
                "status": p.status,
                "priority": p.priority,
                "start_date": p.start_date.isoformat() if p.start_date else None,
                "end_date": p.end_date.isoformat() if p.end_date else None,
                "assigned_to": p.assigned_to,
                "budget": p.budget,
                "created_at": p.created_at.isoformat(),
                "updated_at": p.updated_at.isoformat(),
            }
            for p in projects
        ]

        return ApiResponse(success=True, message="Projects retrieved", data=project_data)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve projects",
        )


@router.post("", response_model=ApiResponse[dict])
async def create_project(
    brand_id: int = Query(...),
    name: str = Query(...),
    description: Optional[str] = Query(None),
    priority: int = Query(0, ge=0, le=3),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    budget: float = Query(0.0, ge=0),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Create new project"""
    try:
        project = Project(
            brand_id=brand_id,
            name=name,
            description=description,
            priority=priority,
            start_date=start_date,
            end_date=end_date,
            budget=budget,
            status=ProjectStatus.PLANNING,
        )

        db.add(project)
        await db.commit()
        await db.refresh(project)

        # Invalidate cache
        if cache:
            await cache.delete(f"projects:{brand_id}")

        return ApiResponse(
            success=True,
            message="Project created",
            data={
                "id": project.id,
                "name": project.name,
                "status": project.status,
            },
        )

    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create project",
        )


@router.get("/{project_id}", response_model=ApiResponse[dict])
async def get_project(
    project_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get project details with tasks"""
    try:
        project = await db.get(Project, project_id)

        if not project:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

        # Get tasks for project
        task_result = await db.execute(
            select(Task).where(Task.project_id == project_id).order_by(Task.due_date)
        )
        tasks = task_result.scalars().all()

        task_data = [
            {
                "id": t.id,
                "title": t.title,
                "status": t.status,
                "priority": t.priority,
                "due_date": t.due_date.isoformat() if t.due_date else None,
                "assigned_to": t.assigned_to,
            }
            for t in tasks
        ]

        return ApiResponse(
            success=True,
            message="Project retrieved",
            data={
                "id": project.id,
                "brand_id": project.brand_id,
                "name": project.name,
                "description": project.description,
                "status": project.status,
                "priority": project.priority,
                "start_date": project.start_date.isoformat() if project.start_date else None,
                "end_date": project.end_date.isoformat() if project.end_date else None,
                "budget": project.budget,
                "tasks": task_data,
                "created_at": project.created_at.isoformat(),
                "updated_at": project.updated_at.isoformat(),
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve project",
        )


@router.patch("/{project_id}", response_model=ApiResponse[dict])
async def update_project(
    project_id: int,
    name: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    priority: Optional[int] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Update project"""
    try:
        project = await db.get(Project, project_id)

        if not project:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

        if name:
            project.name = name
        if status:
            project.status = status
        if priority is not None:
            project.priority = priority

        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"projects:{project.brand_id}")

        return ApiResponse(
            success=True,
            message="Project updated",
            data={
                "id": project.id,
                "name": project.name,
                "status": project.status,
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update project",
        )


@router.delete("/{project_id}")
async def delete_project(
    project_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """Delete project"""
    try:
        project = await db.get(Project, project_id)

        if not project:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

        brand_id = project.brand_id
        await db.delete(project)
        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"projects:{brand_id}")

        return ApiResponse(success=True, message="Project deleted")

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete project",
        )


# ==================== Task Endpoints ====================

@router.get("/{project_id}/tasks", response_model=ApiResponse[list[dict]])
async def list_tasks(
    project_id: int,
    status: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get tasks for a project"""
    try:
        query = select(Task).where(Task.project_id == project_id)

        if status:
            query = query.where(Task.status == status)

        query = query.order_by(Task.due_date)

        result = await db.execute(query)
        tasks = result.scalars().all()

        task_data = [
            {
                "id": t.id,
                "title": t.title,
                "description": t.description,
                "status": t.status,
                "priority": t.priority,
                "assigned_to": t.assigned_to,
                "due_date": t.due_date.isoformat() if t.due_date else None,
                "completed_at": t.completed_at.isoformat() if t.completed_at else None,
            }
            for t in tasks
        ]

        return ApiResponse(success=True, message="Tasks retrieved", data=task_data)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve tasks",
        )


@router.post("/{project_id}/tasks", response_model=ApiResponse[dict])
async def create_task(
    project_id: int,
    title: str = Query(...),
    description: Optional[str] = Query(None),
    priority: int = Query(0, ge=0, le=3),
    due_date: Optional[datetime] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Create task in project"""
    try:
        # Get project to get brand_id
        project = await db.get(Project, project_id)

        if not project:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found")

        task = Task(
            project_id=project_id,
            brand_id=project.brand_id,
            title=title,
            description=description,
            priority=priority,
            due_date=due_date,
            status=TaskStatus.TODO,
        )

        db.add(task)
        await db.commit()
        await db.refresh(task)

        return ApiResponse(
            success=True,
            message="Task created",
            data={
                "id": task.id,
                "title": task.title,
                "status": task.status,
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create task",
        )


@router.patch("/task/{task_id}", response_model=ApiResponse[dict])
async def update_task(
    task_id: int,
    status: Optional[str] = Query(None),
    title: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Update task status"""
    try:
        task = await db.get(Task, task_id)

        if not task:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Task not found")

        if status:
            task.status = status
            if status == TaskStatus.DONE:
                task.completed_at = datetime.utcnow()
        if title:
            task.title = title

        await db.commit()

        return ApiResponse(
            success=True,
            message="Task updated",
            data={"id": task.id, "status": task.status},
        )

    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update task",
        )
