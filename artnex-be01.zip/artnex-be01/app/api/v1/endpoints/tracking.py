"""Content tracking endpoints"""
import io
import csv
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.models.tracking import TrackedContent
from app.repositories.tracking_repository import TrackedContentRepository
from app.schemas.common import ApiResponse
from app.schemas.tracking import ContentSearchQuery, ContentSearchResponse, TrackedContentResponse
from app.services.kpi_service import KPIService
from app.services.sns_service import SNSService
from app.services.tracking_service import TrackingService
from app.utils.cache import RedisCache, get_redis_cache

router = APIRouter(prefix="/tracking", tags=["tracking"])


@router.get("/search", response_model=ApiResponse[ContentSearchResponse])
async def search_content(
    brand_id: int = Query(...),
    query: str = Query(""),
    platform: Optional[str] = Query(None),
    min_views: int = Query(0, ge=0),
    max_views: Optional[int] = Query(None),
    min_engagement_rate: float = Query(0.0, ge=0.0, le=100.0),
    max_engagement_rate: float = Query(100.0, ge=0.0, le=100.0),
    min_popularity_index: float = Query(0.0, ge=0.0, le=100.0),
    max_popularity_index: float = Query(100.0, ge=0.0, le=100.0),
    is_influencer: Optional[bool] = Query(None),
    sort_by: str = Query("popularity_index", regex="^(views|engagement_rate|popularity_index|likes|comments|shares|published_at)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Advanced search for tracked content with comprehensive filtering

    Args:
        brand_id: Brand ID
        query: Search query (title/description)
        platform: Platform filter (youtube, tiktok, instagram, etc.)
        min_views: Minimum views
        max_views: Maximum views
        min_engagement_rate: Minimum engagement rate (0-100)
        max_engagement_rate: Maximum engagement rate (0-100)
        min_popularity_index: Minimum popularity index (0-100)
        max_popularity_index: Maximum popularity index (0-100)
        is_influencer: Filter by influencer status
        sort_by: Sort field (views, engagement_rate, popularity_index, etc.)
        sort_order: Sort order (asc, desc)
        page: Page number
        page_size: Items per page
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Search results with metadata
    """
    try:
        service = TrackingService(db, cache)
        skip = (page - 1) * page_size

        # Perform advanced search
        contents, total = await service.search_with_filters(
            brand_id=brand_id,
            query=query,
            platform=platform,
            min_views=min_views,
            max_views=max_views,
            min_engagement_rate=min_engagement_rate,
            max_engagement_rate=max_engagement_rate,
            min_popularity_index=min_popularity_index,
            max_popularity_index=max_popularity_index,
            is_influencer=is_influencer,
            sort_by=sort_by,
            sort_order=sort_order,
            skip=skip,
            limit=page_size,
        )

        content_responses = [TrackedContentResponse.from_orm(content) for content in contents]

        search_response = ContentSearchResponse(
            total=total,
            page=page,
            page_size=page_size,
            results=content_responses,
        )

        return ApiResponse(
            success=True,
            message="Content search completed",
            data=search_response,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search content",
        )


@router.get("/trending", response_model=ApiResponse[list[dict]])
async def get_trending_content(
    brand_id: int = Query(...),
    platform: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get trending content for a brand with detailed metrics

    Args:
        brand_id: Brand ID
        platform: Platform filter
        limit: Number of results
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Trending content list with metrics
    """
    try:
        service = TrackingService(db, cache)
        trending = await service.get_trending_with_metrics(brand_id, platform, limit)

        return ApiResponse(
            success=True,
            message="Trending content retrieved",
            data=trending,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve trending content",
        )


@router.get("/influencers", response_model=ApiResponse[list[dict]])
async def get_influencer_analysis(
    brand_id: int = Query(...),
    limit: int = Query(20, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get influencer analysis with metrics and reach

    Args:
        brand_id: Brand ID
        limit: Number of influencers to analyze
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Influencer analysis with reach and engagement metrics
    """
    try:
        service = TrackingService(db, cache)
        analysis = await service.get_influencer_analysis(brand_id, limit)

        return ApiResponse(
            success=True,
            message="Influencer analysis retrieved",
            data=analysis,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve influencer analysis",
        )


@router.get("/youtube/search")
async def search_youtube(
    keyword: str = Query(...),
    max_results: int = Query(20, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Search YouTube for content

    Args:
        keyword: Search keyword
        max_results: Maximum results
        current_user: Current authenticated user
        db: Database session

    Returns:
        YouTube search results
    """
    try:
        sns_service = SNSService()
        results = await sns_service.search_youtube_content(keyword, max_results)

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} YouTube videos",
            data=results,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search YouTube",
        )


@router.get("/metrics", response_model=ApiResponse[dict])
async def get_tracking_metrics(
    brand_id: int = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get comprehensive tracking metrics for a brand

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Performance metrics with aggregations
    """
    try:
        # Check cache first
        cache_key = f"metrics:{brand_id}"
        if cache:
            cached = await cache.get(cache_key)
            if cached:
                import json
                return ApiResponse(
                    success=True,
                    message="Metrics retrieved (cached)",
                    data=json.loads(cached),
                )

        kpi_service = KPIService(db)
        metrics = await kpi_service.get_brand_performance_metrics(brand_id)

        # Cache for 1 hour
        if cache:
            import json
            await cache.set(cache_key, json.dumps(metrics), ttl=3600)

        return ApiResponse(
            success=True,
            message="Metrics retrieved",
            data=metrics,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve metrics",
        )


@router.get("/trending-topics", response_model=ApiResponse[list])
async def get_trending_topics(
    brand_id: int = Query(...),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get trending topics for a brand

    Args:
        brand_id: Brand ID
        limit: Number of topics
        current_user: Current authenticated user
        db: Database session

    Returns:
        Trending topics
    """
    try:
        kpi_service = KPIService(db)
        topics = await kpi_service.detect_trending_topics(brand_id, limit)

        return ApiResponse(
            success=True,
            message="Trending topics detected",
            data=topics,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to detect trending topics",
        )


@router.post("/track", response_model=ApiResponse[dict])
async def track_new_content(
    brand_id: int = Query(...),
    platform: str = Query(...),
    content_id: str = Query(...),
    title: str = Query(...),
    url: str = Query(...),
    creator_name: Optional[str] = Query(None),
    creator_handle: Optional[str] = Query(None),
    views: int = Query(0, ge=0),
    likes: int = Query(0, ge=0),
    comments: int = Query(0, ge=0),
    shares: int = Query(0, ge=0),
    thumbnail_url: Optional[str] = Query(None),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Track new SNS content with automatic KPI calculation

    Args:
        brand_id: Brand ID
        platform: Platform (youtube, tiktok, instagram, etc.)
        content_id: Platform-specific content ID
        title: Content title
        url: Content URL
        creator_name: Creator name
        creator_handle: Creator handle
        views: View count
        likes: Like count
        comments: Comment count
        shares: Share count
        thumbnail_url: Thumbnail URL
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Created content with calculated KPIs
    """
    try:
        service = TrackingService(db, cache)
        content = await service.track_content(
            brand_id=brand_id,
            platform=platform,
            content_id=content_id,
            title=title,
            url=url,
            creator_name=creator_name,
            creator_handle=creator_handle,
            views=views,
            likes=likes,
            comments=comments,
            shares=shares,
            thumbnail_url=thumbnail_url,
            published_at=datetime.utcnow(),
        )

        if not content:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to track content",
            )

        return ApiResponse(
            success=True,
            message="Content tracked successfully",
            data={
                "id": content.id,
                "brand_id": content.brand_id,
                "platform": content.platform,
                "title": content.title,
                "views": content.views,
                "likes": content.likes,
                "comments": content.comments,
                "shares": content.shares,
                "engagement_rate": round(content.engagement_rate, 2),
                "popularity_index": round(content.popularity_index, 2),
                "is_influencer": content.is_influencer,
            },
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to track content",
        )


@router.get("/filters/options", response_model=ApiResponse[dict])
async def get_filter_options(
    brand_id: int = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get available filter options for a brand

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session

    Returns:
        Dictionary with available filters and their values
    """
    try:
        from sqlalchemy import select, func, distinct

        tracking_repo = TrackedContentRepository(db)

        # Get available platforms
        result = await db.execute(
            select(distinct(TrackedContent.platform)).where(
                TrackedContent.brand_id == brand_id
            )
        )
        platforms = [r[0] for r in result.fetchall() if r[0]]

        # Get engagement rate ranges
        contents = await tracking_repo.get_by_brand_id(brand_id, limit=1000)
        if contents:
            engagement_rates = [c.engagement_rate for c in contents]
            popularity_indices = [c.popularity_index for c in contents]

            return ApiResponse(
                success=True,
                message="Filter options retrieved",
                data={
                    "platforms": platforms,
                    "engagement_rate": {
                        "min": min(engagement_rates),
                        "max": max(engagement_rates),
                    },
                    "popularity_index": {
                        "min": min(popularity_indices),
                        "max": max(popularity_indices),
                    },
                    "views": {
                        "min": min(c.views for c in contents),
                        "max": max(c.views for c in contents),
                    },
                },
            )
        else:
            return ApiResponse(
                success=True,
                message="Filter options retrieved",
                data={
                    "platforms": [],
                    "engagement_rate": {"min": 0, "max": 100},
                    "popularity_index": {"min": 0, "max": 100},
                    "views": {"min": 0, "max": 0},
                },
            )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get filter options",
        )


@router.get("/statistics", response_model=ApiResponse[dict])
async def get_tracking_statistics(
    brand_id: int = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get comprehensive tracking statistics for a brand

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Comprehensive statistics including growth, trends, and platform breakdown
    """
    try:
        cache_key = f"statistics:{brand_id}"

        if cache:
            cached = await cache.get(cache_key)
            if cached:
                import json
                return ApiResponse(
                    success=True,
                    message="Statistics retrieved (cached)",
                    data=json.loads(cached),
                )

        kpi_service = KPIService(db)
        tracking_repo = TrackedContentRepository(db)

        # Get performance metrics
        metrics = await kpi_service.get_brand_performance_metrics(brand_id)

        # Get growth rate
        growth_rate = await kpi_service.calculate_growth_rate(brand_id)

        # Get platform breakdown
        contents = await tracking_repo.get_by_brand_id(brand_id, limit=10000)
        platform_breakdown = {}
        for content in contents:
            if content.platform not in platform_breakdown:
                platform_breakdown[content.platform] = {
                    "count": 0,
                    "total_views": 0,
                    "avg_engagement_rate": 0,
                }
            platform_breakdown[content.platform]["count"] += 1
            platform_breakdown[content.platform]["total_views"] += content.views
            platform_breakdown[content.platform]["avg_engagement_rate"] += content.engagement_rate

        # Calculate averages
        for platform in platform_breakdown:
            count = platform_breakdown[platform]["count"]
            if count > 0:
                platform_breakdown[platform]["avg_engagement_rate"] /= count

        statistics = {
            **metrics,
            "growth_rate": growth_rate,
            "platform_breakdown": platform_breakdown,
        }

        # Cache for 1 hour
        if cache:
            import json
            await cache.set(cache_key, json.dumps(statistics), ttl=3600)

        return ApiResponse(
            success=True,
            message="Statistics retrieved",
            data=statistics,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get statistics",
        )


# ==================== Day 4 Enhancements: Multi-Platform SNS APIs ====================


@router.get("/tiktok/search")
async def search_tiktok(
    keyword: str = Query(...),
    max_results: int = Query(20, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Search TikTok for content

    Args:
        keyword: Search keyword
        max_results: Maximum results
        current_user: Current authenticated user

    Returns:
        TikTok search results with metadata
    """
    try:
        sns_service = SNSService()
        results = await sns_service.search_tiktok_content(keyword, max_results)

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} TikTok videos",
            data=results,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search TikTok",
        )


@router.get("/instagram/search")
async def search_instagram(
    keyword: str = Query(...),
    max_results: int = Query(20, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Search Instagram for content

    Args:
        keyword: Search keyword
        max_results: Maximum results
        current_user: Current authenticated user

    Returns:
        Instagram search results with metadata
    """
    try:
        sns_service = SNSService()
        results = await sns_service.search_instagram_content(keyword, max_results)

        return ApiResponse(
            success=True,
            message=f"Found {len(results)} Instagram posts",
            data=results,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search Instagram",
        )


@router.get("/multi-platform/search")
async def search_multi_platform(
    keyword: str = Query(...),
    platforms: Optional[str] = Query(None),  # Comma-separated list
    max_results: int = Query(20, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Search across multiple social media platforms simultaneously

    Args:
        keyword: Search keyword
        platforms: Comma-separated list of platforms (youtube,tiktok,instagram). Default: all
        max_results: Maximum results per platform
        current_user: Current authenticated user

    Returns:
        Search results organized by platform
    """
    try:
        sns_service = SNSService()

        # Parse platforms
        platform_list = None
        if platforms:
            platform_list = [p.strip().lower() for p in platforms.split(",")]

        results = await sns_service.search_multi_platform(keyword, platform_list, max_results)

        # Calculate total results
        total_results = sum(len(v) for v in results.values())

        return ApiResponse(
            success=True,
            message=f"Found {total_results} results across {len(results)} platforms",
            data=results,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search multi-platform",
        )


@router.get("/platform-stats/{platform}/{content_id}")
async def get_platform_statistics(
    platform: str,
    content_id: str,
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Get detailed statistics for content on a specific platform

    Args:
        platform: Platform name (youtube, tiktok, instagram)
        content_id: Content ID on the platform
        current_user: Current authenticated user

    Returns:
        Platform-specific statistics
    """
    try:
        sns_service = SNSService()
        stats = await sns_service.get_platform_statistics(platform, content_id)

        if not stats:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Statistics not found for {platform}",
            )

        return ApiResponse(
            success=True,
            message=f"Statistics retrieved for {platform}",
            data=stats,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get platform statistics",
        )


@router.get("/content/{content_id}/trending-score")
async def get_trending_score(
    content_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Calculate trending score for specific content

    Args:
        content_id: Content ID
        current_user: Current authenticated user
        db: Database session

    Returns:
        Trending score and analysis
    """
    try:
        tracking_repo = TrackedContentRepository(db)
        content = await tracking_repo.get_by_id(content_id)

        if not content:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Content not found",
            )

        sns_service = SNSService()
        trending_score = sns_service.get_trending_algorithm(
            {
                "views": content.views,
                "likes": content.likes,
                "comments": content.comments,
                "shares": content.shares,
            }
        )

        return ApiResponse(
            success=True,
            message="Trending score calculated",
            data={
                "content_id": content_id,
                "title": content.title,
                "platform": content.platform,
                "trending_score": trending_score,
                "views": content.views,
                "likes": content.likes,
                "comments": content.comments,
                "shares": content.shares,
                "engagement_rate": round(content.engagement_rate, 2),
                "popularity_index": round(content.popularity_index, 2),
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to calculate trending score",
        )


@router.get("/platform/{platform}/trending")
async def get_platform_trending(
    platform: str,
    brand_id: int = Query(...),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Get trending content for a specific platform

    Args:
        platform: Platform name (youtube, tiktok, instagram)
        brand_id: Brand ID
        limit: Number of results
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Trending content for the platform
    """
    try:
        # Check cache first
        cache_key = f"trending:{platform}:{brand_id}:{limit}"
        if cache:
            cached = await cache.get(cache_key)
            if cached:
                import json
                return ApiResponse(
                    success=True,
                    message=f"Trending {platform} content (cached)",
                    data=json.loads(cached),
                )

        tracking_repo = TrackedContentRepository(db)
        from sqlalchemy import select, and_

        # Query for trending content on specific platform
        query = (
            select(TrackedContent)
            .where(
                and_(
                    TrackedContent.brand_id == brand_id,
                    TrackedContent.platform == platform.lower(),
                )
            )
            .order_by(TrackedContent.popularity_index.desc(), TrackedContent.published_at.desc())
            .limit(limit)
        )

        result = await db.execute(query)
        contents = result.scalars().all()

        # Convert to dict format
        trending_data = [
            {
                "id": c.id,
                "title": c.title,
                "platform": c.platform,
                "creator_name": c.creator_name,
                "views": c.views,
                "likes": c.likes,
                "comments": c.comments,
                "shares": c.shares,
                "engagement_rate": round(c.engagement_rate, 2),
                "popularity_index": round(c.popularity_index, 2),
                "published_at": c.published_at.isoformat() if c.published_at else None,
                "url": c.url,
            }
            for c in contents
        ]

        # Cache for 1 hour
        if cache:
            import json
            await cache.set(cache_key, json.dumps(trending_data), ttl=3600)

        return ApiResponse(
            success=True,
            message=f"Retrieved trending {platform} content",
            data=trending_data,
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get trending {platform} content",
        )


# ==================== Day 5: CSV Upload & Bulk Operations ====================


@router.post("/bulk/upload-csv")
async def upload_csv_content(
    brand_id: int = Query(...),
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Upload and process CSV file to track multiple contents at once

    CSV should have columns:
    - platform: youtube, tiktok, instagram, etc.
    - content_id: Platform-specific ID
    - title: Content title
    - url: Content URL
    - creator_name: Creator name
    - creator_handle: Creator handle
    - views: View count
    - likes: Like count
    - comments: Comment count
    - shares: Share count

    Args:
        brand_id: Brand ID
        file: CSV file
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Upload result with success/failure statistics
    """
    try:
        # Validate file type
        if not file.filename.endswith(".csv"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="File must be CSV format",
            )

        # Read CSV content
        content = await file.read()
        csv_reader = csv.DictReader(io.StringIO(content.decode("utf-8")))

        tracking_repo = TrackedContentRepository(db)
        tracking_service = TrackingService(db, cache)
        kpi_service = KPIService(db)

        success_count = 0
        error_count = 0
        errors = []

        for row_num, row in enumerate(csv_reader, start=2):  # Start from 2 (header is 1)
            try:
                # Validate required fields
                required_fields = ["platform", "content_id", "title", "url"]
                missing_fields = [f for f in required_fields if not row.get(f)]

                if missing_fields:
                    error_count += 1
                    errors.append(f"Row {row_num}: Missing fields {missing_fields}")
                    continue

                # Parse numeric fields
                try:
                    views = int(row.get("views", 0))
                    likes = int(row.get("likes", 0))
                    comments = int(row.get("comments", 0))
                    shares = int(row.get("shares", 0))
                except ValueError as e:
                    error_count += 1
                    errors.append(f"Row {row_num}: Invalid numeric values - {str(e)}")
                    continue

                # Check if content already exists
                existing = await tracking_repo.get_by_platform_id(row["content_id"])
                if existing:
                    # Update existing content
                    existing.views = views
                    existing.likes = likes
                    existing.comments = comments
                    existing.shares = shares

                    # Recalculate metrics
                    existing.engagement_rate = (
                        (likes + comments + shares) / views * 100 if views > 0 else 0
                    )

                    await db.flush()
                    success_count += 1
                else:
                    # Create new content
                    content_data = {
                        "brand_id": brand_id,
                        "platform": row["platform"].lower(),
                        "content_id": row["content_id"],
                        "title": row["title"],
                        "url": row["url"],
                        "creator_name": row.get("creator_name", "Unknown"),
                        "creator_handle": row.get("creator_handle"),
                        "views": views,
                        "likes": likes,
                        "comments": comments,
                        "shares": shares,
                        "thumbnail_url": row.get("thumbnail_url"),
                        "published_at": datetime.utcnow(),
                    }

                    await tracking_service.track_content(**content_data)
                    success_count += 1

            except Exception as e:
                error_count += 1
                errors.append(f"Row {row_num}: {str(e)}")

        # Commit all changes
        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"metrics:{brand_id}")
            await cache.delete(f"statistics:{brand_id}")

        return ApiResponse(
            success=True,
            message=f"CSV upload completed: {success_count} success, {error_count} errors",
            data={
                "total_rows_processed": success_count + error_count,
                "success_count": success_count,
                "error_count": error_count,
                "errors": errors[:10] if errors else [],  # Return first 10 errors
            },
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to process CSV: {str(e)}",
        )


@router.get("/creator/{creator_handle}/engagement-history")
async def get_creator_engagement_history(
    creator_handle: str,
    brand_id: int = Query(...),
    limit: int = Query(50, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get engagement history for a specific creator

    Args:
        brand_id: Brand ID
        creator_handle: Creator handle
        limit: Number of results
        current_user: Current authenticated user
        db: Database session

    Returns:
        Creator's engagement history and trends
    """
    try:
        tracking_repo = TrackedContentRepository(db)
        from sqlalchemy import select, and_

        # Query creator's content
        query = (
            select(TrackedContent)
            .where(
                and_(
                    TrackedContent.brand_id == brand_id,
                    TrackedContent.creator_handle == creator_handle,
                )
            )
            .order_by(TrackedContent.published_at.desc())
            .limit(limit)
        )

        result = await db.execute(query)
        contents = result.scalars().all()

        if not contents:
            return ApiResponse(
                success=True,
                message="No content found for creator",
                data={
                    "creator_handle": creator_handle,
                    "total_content": 0,
                    "contents": [],
                },
            )

        # Calculate engagement statistics
        total_views = sum(c.views for c in contents)
        total_engagement = sum(c.likes + c.comments + c.shares for c in contents)
        avg_engagement_rate = sum(c.engagement_rate for c in contents) / len(contents)

        # Convert to dict format
        content_data = [
            {
                "id": c.id,
                "title": c.title,
                "platform": c.platform,
                "views": c.views,
                "likes": c.likes,
                "comments": c.comments,
                "shares": c.shares,
                "engagement_rate": round(c.engagement_rate, 2),
                "published_at": c.published_at.isoformat() if c.published_at else None,
            }
            for c in contents
        ]

        return ApiResponse(
            success=True,
            message="Creator engagement history retrieved",
            data={
                "creator_handle": creator_handle,
                "total_content": len(contents),
                "total_views": total_views,
                "total_engagement": total_engagement,
                "avg_engagement_rate": round(avg_engagement_rate, 2),
                "contents": content_data,
            },
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get creator engagement history",
        )


@router.post("/bulk/update-engagement")
async def bulk_update_engagement(
    brand_id: int = Query(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    cache: RedisCache = Depends(get_redis_cache),
) -> dict:
    """
    Bulk update engagement metrics for all tracked content

    This endpoint recalculates engagement rates and popularity indices
    for all tracked content based on current metrics.

    Args:
        brand_id: Brand ID
        current_user: Current authenticated user
        db: Database session
        cache: Redis cache

    Returns:
        Update statistics
    """
    try:
        tracking_repo = TrackedContentRepository(db)
        kpi_service = KPIService(db)

        # Get all content for brand
        contents = await tracking_repo.get_by_brand_id(brand_id, limit=10000)

        update_count = 0

        for content in contents:
            # Recalculate engagement rate
            if content.views > 0:
                engagement_rate = (content.likes + content.comments + content.shares) / content.views * 100
            else:
                engagement_rate = 0

            # Recalculate popularity index
            views_norm = min(content.views / 100000, 1.0)
            likes_norm = min(content.likes / 5000, 1.0)
            comments_norm = min(content.comments / 500, 1.0)
            shares_norm = min(content.shares / 200, 1.0)

            popularity_index = (
                (views_norm * 0.4 + likes_norm * 0.3 + comments_norm * 0.2 + shares_norm * 0.1) * 100
            )

            # Update if changed
            if (
                content.engagement_rate != engagement_rate
                or content.popularity_index != popularity_index
            ):
                content.engagement_rate = engagement_rate
                content.popularity_index = popularity_index
                update_count += 1

        await db.commit()

        # Invalidate cache
        if cache:
            await cache.delete(f"metrics:{brand_id}")
            await cache.delete(f"statistics:{brand_id}")
            await cache.delete(f"trending:{brand_id}:*")

        return ApiResponse(
            success=True,
            message=f"Bulk engagement update completed",
            data={
                "total_content": len(contents),
                "updated_count": update_count,
                "unchanged_count": len(contents) - update_count,
            },
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to bulk update engagement",
        )
