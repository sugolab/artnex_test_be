"""Payment and subscription endpoints (Mock)"""
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.schemas.common import ApiResponse
from app.schemas.dashboard import UpgradeRequest, UpgradeResponse

router = APIRouter(prefix="/payments", tags=["payments"])


@router.post("/upgrade", response_model=ApiResponse[UpgradeResponse])
async def upgrade_subscription(
    request: UpgradeRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Upgrade user subscription (Mock - no real payment processing)

    Args:
        request: Upgrade request with subscription plan
        current_user: Current authenticated user
        db: Database session

    Returns:
        Upgrade response with transaction ID
    """
    try:
        user_id = current_user.get("user_id")

        # Validate subscription plan
        valid_plans = ["basic", "premium", "enterprise"]
        if request.subscription_plan not in valid_plans:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid subscription plan. Must be one of: {', '.join(valid_plans)}",
            )

        # Mock payment processing
        transaction_id = f"TXN_{uuid.uuid4().hex[:12].upper()}"

        # In a real application, this would:
        # 1. Call payment gateway (Stripe, PayPal, etc.)
        # 2. Create UserSubscription record
        # 3. Log Payment transaction
        # 4. Send confirmation email

        upgrade_response = UpgradeResponse(
            success=True,
            message=f"Successfully upgraded to {request.subscription_plan} plan",
            new_subscription_status=request.subscription_plan,
            transaction_id=transaction_id,
        )

        return ApiResponse(
            success=True,
            message="Subscription upgrade processed",
            data=upgrade_response,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process subscription upgrade",
        )


@router.get("/subscription/current")
async def get_current_subscription(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get user's current subscription details (Mock)

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        Current subscription details
    """
    try:
        user_id = current_user.get("user_id")

        # Mock subscription data
        subscription = {
            "plan": "premium",
            "status": "active",
            "started_at": "2025-10-23T00:00:00",
            "expires_at": "2026-10-23T00:00:00",
            "price_per_month": 29.99,
            "features": [
                "Unlimited brands",
                "AI-powered analytics",
                "Advanced reporting",
                "Priority support",
            ],
        }

        return ApiResponse(
            success=True,
            message="Current subscription retrieved",
            data=subscription,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve subscription",
        )


@router.get("/plans/all")
async def get_available_plans(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get all available subscription plans

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of subscription plans
    """
    try:
        plans = [
            {
                "name": "Free",
                "plan_id": "free",
                "price_per_month": 0.0,
                "description": "For individual users getting started",
                "features": [
                    "Up to 5 brands",
                    "Basic analytics",
                    "Email support",
                ],
            },
            {
                "name": "Basic",
                "plan_id": "basic",
                "price_per_month": 9.99,
                "description": "For small teams",
                "features": [
                    "Unlimited brands",
                    "Basic analytics",
                    "Up to 5 team members",
                    "Email support",
                ],
            },
            {
                "name": "Premium",
                "plan_id": "premium",
                "price_per_month": 29.99,
                "description": "For growing businesses",
                "features": [
                    "Unlimited brands",
                    "Advanced analytics",
                    "Up to 20 team members",
                    "AI-powered insights",
                    "Priority email support",
                ],
            },
            {
                "name": "Enterprise",
                "plan_id": "enterprise",
                "price_per_month": 99.99,
                "description": "For large organizations",
                "features": [
                    "Unlimited everything",
                    "Custom analytics",
                    "Unlimited team members",
                    "AI-powered insights",
                    "24/7 phone & email support",
                    "Dedicated account manager",
                    "Custom integrations",
                ],
            },
        ]

        return ApiResponse(
            success=True,
            message="Plans retrieved successfully",
            data=plans,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve plans",
        )
