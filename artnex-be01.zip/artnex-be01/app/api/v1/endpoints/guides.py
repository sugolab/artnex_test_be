"""Guide resource endpoints"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.repositories.activity_repository import GuideResourceRepository
from app.schemas.common import ApiResponse
from app.schemas.dashboard import GuideResource

router = APIRouter(prefix="/guides", tags=["guides"])


@router.get("", response_model=ApiResponse[list[GuideResource]])
async def get_all_guides(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get all available guide resources

    Args:
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of guide resources
    """
    try:
        guide_repo = GuideResourceRepository(db)
        guides = await guide_repo.get_all_active()

        guide_responses = [
            GuideResource(
                id=guide.id,
                title=guide.title,
                description=guide.description,
                resource_type=guide.resource_type,
                resource_url=guide.resource_url,
                category=guide.category,
                order=guide.order,
            )
            for guide in guides
        ]

        return ApiResponse(
            success=True,
            message="Guides retrieved successfully",
            data=guide_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve guides",
        )


@router.get("/category/{category}", response_model=ApiResponse[list[GuideResource]])
async def get_guides_by_category(
    category: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Get guide resources by category

    Args:
        category: Guide category
        current_user: Current authenticated user
        db: Database session

    Returns:
        List of guide resources for the category
    """
    try:
        guide_repo = GuideResourceRepository(db)
        guides = await guide_repo.get_by_category(category)

        guide_responses = [
            GuideResource(
                id=guide.id,
                title=guide.title,
                description=guide.description,
                resource_type=guide.resource_type,
                resource_url=guide.resource_url,
                category=guide.category,
                order=guide.order,
            )
            for guide in guides
        ]

        return ApiResponse(
            success=True,
            message=f"Guides for category '{category}' retrieved",
            data=guide_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve guides",
        )


@router.get("/onboarding/all", response_model=ApiResponse[list[GuideResource]])
async def get_onboarding_guides(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    limit: int = Query(5, ge=1, le=20),
) -> dict:
    """
    Get onboarding guides for new users

    Args:
        current_user: Current authenticated user
        db: Database session
        limit: Maximum number of guides

    Returns:
        List of onboarding guides
    """
    try:
        guide_repo = GuideResourceRepository(db)
        guides = await guide_repo.get_onboarding_guides(limit=limit)

        guide_responses = [
            GuideResource(
                id=guide.id,
                title=guide.title,
                description=guide.description,
                resource_type=guide.resource_type,
                resource_url=guide.resource_url,
                category=guide.category,
                order=guide.order,
            )
            for guide in guides
        ]

        return ApiResponse(
            success=True,
            message="Onboarding guides retrieved",
            data=guide_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve onboarding guides",
        )
