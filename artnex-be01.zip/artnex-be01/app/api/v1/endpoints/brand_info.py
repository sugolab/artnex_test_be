"""Brand info endpoints (personas, competitors, SKUs)"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user, get_db
from app.repositories.brand_info_repository import BrandPersonaRepository, CompetitorRepository
from app.repositories.sku_repository import SKURepository
from app.schemas.common import ApiResponse
from app.schemas.sku import (
    BrandPersonaCreate,
    BrandPersonaResponse,
    CompetitorCreate,
    CompetitorResponse,
    SKUCreate,
    SKUResponse,
    SKUUpdate,
)

router = APIRouter(tags=["brand-info"])


# ==================== SKU Endpoints ====================
@router.get("/brands/{brand_id}/skus", response_model=ApiResponse[list[SKUResponse]])
async def get_brand_skus(
    brand_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get SKUs for a brand"""
    try:
        sku_repo = SKURepository(db)
        skus = await sku_repo.get_by_brand_id(brand_id, skip=skip, limit=limit)

        sku_responses = [SKUResponse.from_orm(sku) for sku in skus]

        return ApiResponse(
            success=True,
            message="SKUs retrieved",
            data=sku_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve SKUs",
        )


@router.post("/brands/{brand_id}/skus", response_model=ApiResponse[SKUResponse])
async def create_sku(
    brand_id: int,
    sku_data: SKUCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Create new SKU"""
    try:
        sku_repo = SKURepository(db)
        sku = await sku_repo.create(brand_id, sku_data.dict())

        return ApiResponse(
            success=True,
            message="SKU created",
            data=SKUResponse.from_orm(sku),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create SKU",
        )


@router.patch("/skus/{sku_id}", response_model=ApiResponse[SKUResponse])
async def update_sku(
    sku_id: int,
    sku_data: SKUUpdate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Update SKU"""
    try:
        sku_repo = SKURepository(db)
        update_data = {k: v for k, v in sku_data.dict().items() if v is not None}

        if not update_data:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No fields to update")

        sku = await sku_repo.update(sku_id, update_data)
        if not sku:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="SKU not found")

        return ApiResponse(
            success=True,
            message="SKU updated",
            data=SKUResponse.from_orm(sku),
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update SKU",
        )


# ==================== Brand Persona Endpoints ====================
@router.get("/brands/{brand_id}/personas", response_model=ApiResponse[list[BrandPersonaResponse]])
async def get_brand_personas(
    brand_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get personas for a brand"""
    try:
        persona_repo = BrandPersonaRepository(db)
        personas = await persona_repo.get_by_brand_id(brand_id)

        persona_responses = [BrandPersonaResponse.from_orm(persona) for persona in personas]

        return ApiResponse(
            success=True,
            message="Personas retrieved",
            data=persona_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve personas",
        )


@router.post("/brands/{brand_id}/personas", response_model=ApiResponse[BrandPersonaResponse])
async def create_persona(
    brand_id: int,
    persona_data: BrandPersonaCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Create brand persona"""
    try:
        persona_repo = BrandPersonaRepository(db)
        persona = await persona_repo.create(brand_id, persona_data.dict())

        return ApiResponse(
            success=True,
            message="Persona created",
            data=BrandPersonaResponse.from_orm(persona),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create persona",
        )


# ==================== Competitor Endpoints ====================
@router.get("/brands/{brand_id}/competitors", response_model=ApiResponse[list[CompetitorResponse]])
async def get_competitors(
    brand_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Get competitors for a brand"""
    try:
        competitor_repo = CompetitorRepository(db)
        competitors = await competitor_repo.get_by_brand_id(brand_id)

        competitor_responses = [CompetitorResponse.from_orm(comp) for comp in competitors]

        return ApiResponse(
            success=True,
            message="Competitors retrieved",
            data=competitor_responses,
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve competitors",
        )


@router.post("/brands/{brand_id}/competitors", response_model=ApiResponse[CompetitorResponse])
async def create_competitor(
    brand_id: int,
    competitor_data: CompetitorCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """Create competitor"""
    try:
        competitor_repo = CompetitorRepository(db)
        competitor = await competitor_repo.create(brand_id, competitor_data.dict())

        return ApiResponse(
            success=True,
            message="Competitor created",
            data=CompetitorResponse.from_orm(competitor),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create competitor",
        )
