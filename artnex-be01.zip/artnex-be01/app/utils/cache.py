"""Redis caching utilities"""
import json
import logging
from typing import Any, Optional

import redis.asyncio as aioredis

from app.core.config import settings

logger = logging.getLogger(__name__)


class RedisCache:
    """Redis cache client wrapper"""

    def __init__(self):
        self.redis_url = settings.REDIS_URL
        self._client: Optional[aioredis.Redis] = None

    async def connect(self):
        """Connect to Redis"""
        try:
            self._client = await aioredis.from_url(self.redis_url, decode_responses=True)
            await self._client.ping()
            logger.info("Connected to Redis")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self._client = None

    async def disconnect(self):
        """Disconnect from Redis"""
        if self._client:
            await self._client.close()
            logger.info("Disconnected from Redis")

    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            if not self._client:
                return None

            value = await self._client.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Error getting from cache: {e}")
            return None

    async def set(self, key: str, value: Any, ttl: int = 3600) -> bool:
        """Set value in cache with TTL (default 1 hour)"""
        try:
            if not self._client:
                return False

            serialized = json.dumps(value)
            await self._client.setex(key, ttl, serialized)
            return True
        except Exception as e:
            logger.error(f"Error setting cache: {e}")
            return False

    async def delete(self, key: str) -> bool:
        """Delete key from cache"""
        try:
            if not self._client:
                return False

            await self._client.delete(key)
            return True
        except Exception as e:
            logger.error(f"Error deleting from cache: {e}")
            return False

    async def clear(self, pattern: str = "*") -> int:
        """Clear cache by pattern"""
        try:
            if not self._client:
                return 0

            keys = await self._client.keys(pattern)
            if keys:
                return await self._client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
            return 0

    async def exists(self, key: str) -> bool:
        """Check if key exists"""
        try:
            if not self._client:
                return False

            return await self._client.exists(key) > 0
        except Exception as e:
            logger.error(f"Error checking cache existence: {e}")
            return False

    async def increment(self, key: str, amount: int = 1) -> int:
        """Increment counter"""
        try:
            if not self._client:
                return 0

            return await self._client.incrby(key, amount)
        except Exception as e:
            logger.error(f"Error incrementing counter: {e}")
            return 0


# Global cache instance
cache = RedisCache()


# Cache key generators
def make_key(*parts: str) -> str:
    """Generate cache key from parts"""
    return ":".join(parts)


def get_dashboard_cache_key(user_id: int) -> str:
    """Get dashboard cache key"""
    return make_key("dashboard", str(user_id))


def get_brand_cache_key(brand_id: int) -> str:
    """Get brand cache key"""
    return make_key("brand", str(brand_id))


def get_user_brands_cache_key(user_id: int) -> str:
    """Get user brands cache key"""
    return make_key("user_brands", str(user_id))


def get_guides_cache_key() -> str:
    """Get guides cache key"""
    return make_key("guides", "all")


def get_recommended_brands_cache_key() -> str:
    """Get recommended brands cache key"""
    return make_key("recommendations", "brands")


# FastAPI dependency injection
def get_redis_cache() -> RedisCache:
    """Get Redis cache instance for dependency injection"""
    return cache
