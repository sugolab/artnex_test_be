"""Add performance optimization indexes

Revision ID: 002
Revises: 001
Create Date: 2025-10-27

This migration adds composite and specialized indexes for query optimization.
"""
from alembic import op

# revision identifiers, used by Alembic.
revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create performance optimization indexes"""

    # Composite indexes for common query patterns

    # Brands: frequently filtered by user_id and sorted by created_at
    op.create_index(
        'ix_brands_user_id_created_at',
        'brands',
        ['user_id', 'created_at'],
        unique=False
    )

    # Tracked contents: frequently filtered by brand_id and platform, sorted by created_at
    op.create_index(
        'ix_tracked_contents_brand_id_created_at',
        'tracked_contents',
        ['brand_id', 'created_at'],
        unique=False
    )

    op.create_index(
        'ix_tracked_contents_platform_created_at',
        'tracked_contents',
        ['platform', 'created_at'],
        unique=False
    )

    # Projects: status-based queries
    op.create_index(
        'ix_projects_brand_id_status',
        'projects',
        ['brand_id', 'status'],
        unique=False
    )

    # Tasks: status-based queries
    op.create_index(
        'ix_tasks_project_id_status',
        'tasks',
        ['project_id', 'status'],
        unique=False
    )

    # Contracts: frequently filtered by brand_id and status
    op.create_index(
        'ix_contracts_brand_id_status',
        'contracts',
        ['brand_id', 'status'],
        unique=False
    )

    # Brand KPIs: measurement_date lookups
    op.create_index(
        'ix_brand_kpis_brand_id_measurement_date',
        'brand_kpis',
        ['brand_id', 'measurement_date'],
        unique=False
    )

    # User subscriptions: active subscriptions lookup
    op.create_index(
        'ix_user_subscriptions_user_id_is_active',
        'user_subscriptions',
        ['user_id', 'is_active'],
        unique=False
    )

    # Payments: user payment history
    op.create_index(
        'ix_payments_user_id_created_at',
        'payments',
        ['user_id', 'created_at'],
        unique=False
    )

    # Brand reports: recent reports lookup
    op.create_index(
        'ix_brand_reports_brand_id_created_at_desc',
        'brand_reports',
        ['brand_id', 'created_at'],
        unique=False
    )

    # Content keywords: keyword frequency analysis
    op.create_index(
        'ix_content_keywords_brand_id_keyword',
        'content_keywords',
        ['brand_id', 'keyword'],
        unique=False
    )

    # Tracked contents: influencer discovery
    op.create_index(
        'ix_tracked_contents_is_influencer_popularity',
        'tracked_contents',
        ['is_influencer', 'popularity_index'],
        unique=False
    )

    # Guide resources: featured content
    op.create_index(
        'ix_guide_resources_is_featured_order',
        'guide_resources',
        ['is_featured', 'order'],
        unique=False
    )

    # User activities: activity timeline
    op.create_index(
        'ix_user_activities_user_id_created_at',
        'user_activities',
        ['user_id', 'created_at'],
        unique=False
    )

    # SKUs: inventory lookup
    op.create_index(
        'ix_skus_brand_id_sku_code',
        'skus',
        ['brand_id', 'sku_code'],
        unique=False
    )

    # Brand personas: brand profiling
    op.create_index(
        'ix_brand_personas_brand_id_persona_name',
        'brand_personas',
        ['brand_id', 'persona_name'],
        unique=False
    )


def downgrade() -> None:
    """Drop performance optimization indexes"""

    op.drop_index('ix_brand_personas_brand_id_persona_name', table_name='brand_personas')
    op.drop_index('ix_skus_brand_id_sku_code', table_name='skus')
    op.drop_index('ix_user_activities_user_id_created_at', table_name='user_activities')
    op.drop_index('ix_guide_resources_is_featured_order', table_name='guide_resources')
    op.drop_index('ix_tracked_contents_is_influencer_popularity', table_name='tracked_contents')
    op.drop_index('ix_content_keywords_brand_id_keyword', table_name='content_keywords')
    op.drop_index('ix_brand_reports_brand_id_created_at_desc', table_name='brand_reports')
    op.drop_index('ix_payments_user_id_created_at', table_name='payments')
    op.drop_index('ix_user_subscriptions_user_id_is_active', table_name='user_subscriptions')
    op.drop_index('ix_brand_kpis_brand_id_measurement_date', table_name='brand_kpis')
    op.drop_index('ix_contracts_brand_id_status', table_name='contracts')
    op.drop_index('ix_tasks_project_id_status', table_name='tasks')
    op.drop_index('ix_projects_brand_id_status', table_name='projects')
    op.drop_index('ix_tracked_contents_platform_created_at', table_name='tracked_contents')
    op.drop_index('ix_tracked_contents_brand_id_created_at', table_name='tracked_contents')
    op.drop_index('ix_brands_user_id_created_at', table_name='brands')
